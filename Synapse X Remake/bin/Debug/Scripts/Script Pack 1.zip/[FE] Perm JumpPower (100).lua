while true do
    game.Players.LocalPlayer.Character.Humanoid.JumpPower = 100
wait()
end