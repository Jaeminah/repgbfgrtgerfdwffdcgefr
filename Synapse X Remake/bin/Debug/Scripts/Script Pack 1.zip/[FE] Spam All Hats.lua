if child.ClassName == "Hat" or child.ClassName == "Accessory" then
if child.Handle:FindFirstChild("Mesh") then
child.Handle.Mesh.Parent = nil
child.Parent = game.Workspace
wait(0.25)
game.Workspace.Hats:FireServer("Acheo's Pot", 0)
wait(0.5)
for index, child in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
if child.ClassName == "Hat" or child.ClassName == "Accessory" then
if child.Handle:FindFirstChild("Mesh") then
child.Handle.Mesh.Parent = nil
child.Parent = game.Workspace
wait(0.25)
game.Workspace.Hats:FireServer("Golden Headphones", 0)
wait(0.5)
for index, child in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
if child.ClassName == "Hat" or child.ClassName == "Accessory" then
if child.Handle:FindFirstChild("Mesh") then
child.Handle.Mesh.Parent = nil
child.Parent = game.Workspace
wait(0.25)
game.Workspace.Hats:FireServer("Black Fedora", 0)
wait(0.5)
for index, child in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
if child.ClassName == "Hat" or child.ClassName == "Accessory" then
if child.Handle:FindFirstChild("Mesh") then
child.Handle.Mesh.Parent = nil
child.Parent = game.Workspace
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end
end