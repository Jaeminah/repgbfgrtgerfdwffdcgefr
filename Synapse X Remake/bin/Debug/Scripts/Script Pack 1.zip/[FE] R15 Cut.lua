game.Players.LocalPlayer.Character.UpperTorso.Waist:Destroy()
end)