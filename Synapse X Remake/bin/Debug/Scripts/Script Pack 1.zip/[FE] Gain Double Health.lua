game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(56,3.5,124.5)
wait()
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-130,3.5,30)