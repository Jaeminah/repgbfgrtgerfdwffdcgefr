--Made by N3xul.
local titan =
{
["assets"] =
{
[1] =
{
["drotation"] =
{
["y"] = 90,
["x"] = 90,
["z"] = 90
},
["dposition"] =
{
["y"] = 200,
["x"] = 200,
["z"] = 200
},
["scale"] =
{
["y"] = 100,
["x"] = 100,
["z"] = 100
},
["dscale"] =
{
["y"] = 500,
["x"] = 500,
["z"] = 500
},
["vscale"] =
{
["y"] = 1,
["x"] = 1,
["z"] = 1
},
["rotation"] =
{
["y"] = 0,
["x"] = 0,
["z"] = 0
},
["assetId"] = 616980142,
["changedFX"] = false,
["position"] =
{
["y"] = 0,
["x"] = 0,
["z"] = 0
},
["fx"] =
{
[1] = true,
[2] = true,
[3] = true,
[4] = true,
[5] = true
},
["vrotation"] =
{
["y"] = 0,
["x"] = 0,
["z"] = 0
},
["vposition"] =
{
["y"] = 0,
["x"] = -0,
["z"] = -0
}
},
[2] =
{
["drotation"] =
{
["y"] = 90,
["x"] = 90,
["z"] = 90
},
["dposition"] =
{
["y"] = 200,
["x"] = 200,
["z"] = 200
},
["scale"] =
{
["y"] = 100,
["x"] = 100,
["z"] = 100
},
["dscale"] =
{
["y"] = 500,
["x"] = 500,
["z"] = 500
},
["vscale"] =
{
["y"] = 1,
["x"] = 1,
["z"] = 1
},
["rotation"] =
{
["y"] = 0,
["x"] = 0,
["z"] = 0
},
["assetId"] = 602599987,
["changedFX"] = false,
["position"] =
{
["y"] = 0,
["x"] = 0,
["z"] = 0
},
["fx"] =
{
[1] = true,
[2] = true,
[3] = true,
[4] = true,
[5] = true
},
["vrotation"] =
{
["y"] = 0,
["x"] = 0,
["z"] = 0
},
["vposition"] =
{
["y"] = 0,
["x"] = -0,
["z"] = -0
}
},
[3] =
{
["drotation"] =
{
["y"] = 180,
["x"] = 90,
["z"] = 90
},
["dposition"] =
{
["y"] = 100,
["x"] = 200,
["z"] = 200
},
["scale"] =
{
["y"] = 100,
["x"] = 100,
["z"] = 100
},
["dscale"] =
{
["y"] = 500,
["x"] = 500,
["z"] = 500
},
["vscale"] =
{
["y"] = 1,
["x"] = 1,
["z"] = 1
},
["rotation"] =
{
["y"] = 0,
["x"] = 0,
["z"] = 0
},
["assetId"] = 244159819,
["changedFX"] = false,
["position"] =
{
["y"] = 0,
["x"] = 0,
["z"] = 0
},
["fx"] =
{
[1] = true,
[2] = true,
[3] = true,
[4] = true,
[5] = true
},
["vrotation"] =
{
["y"] = 0,
["x"] = 0,
["z"] = 0
},
["vposition"] =
{
["y"] = 0,
["x"] = -0,
["z"] = -0
}
},
[4] =
{
["drotation"] =
{
["y"] = 90,
["x"] = 90,
["z"] = 90
},
["dposition"] =
{
["y"] = 200,
["x"] = 200,
["z"] = 200
},
["scale"] =
{
["y"] = 100,
["x"] = 100,
["z"] = 100
},
["dscale"] =
{
["y"] = 500,
["x"] = 500,
["z"] = 500
},
["vscale"] =
{
["y"] = 1,
["x"] = 1,
["z"] = 1
},
["rotation"] =
{
["y"] = 0,
["x"] = 0,
["z"] = 0
},
["assetId"] = 7075502,
["changedFX"] = false,
["position"] =
{
["y"] = 0,
["x"] = 0,
["z"] = 0
},
["fx"] =
{
[1] = true,
[2] = true,
[3] = true,
[4] = true,
[5] = true
},
["vrotation"] =
{
["y"] = 0,
["x"] = 0,
["z"] = 0
},
["vposition"] =
{
["y"] = 0,
["x"] = -0,
["z"] = -0
}
},
[5] =
{
["drotation"] =
{
["y"] = 90,
["x"] = 90,
["z"] = 90
},
["dposition"] =
{
["y"] = 200,
["x"] = 200,
["z"] = 200
},
["scale"] =
{
["y"] = 100,
["x"] = 100,
["z"] = 100
},
["dscale"] =
{
["y"] = 500,
["x"] = 500,
["z"] = 500
},
["vscale"] =
{
["y"] = 1,
["x"] = 1,
["z"] = 1
},
["rotation"] =
{
["y"] = 0,
["x"] = 0,
["z"] = 0
},
["assetId"] = 916733101,
["changedFX"] = false,
["position"] =
{
["y"] = 0,
["x"] = 0,
["z"] = 0
},
["fx"] =
{
[1] = true,
[2] = true,
[3] = true,
[4] = true,
[5] = true
},
["vrotation"] =
{
["y"] = 0,
["x"] = 0,
["z"] = 0
},
["vposition"] =
{
["y"] = 0,
["x"] = -0,
["z"] = -0
}
}
},
["description"] = "",
["createdDate"] = 1000,
["lowerDesc"] = "",
["bodyColors"] =
{
["HeadColor"] = Color3.new(1, 0, 0),
["TorsoColor"] = Color3.new(0.0666667, 0.0666667, 0.0666667),
["LeftArmColor"] = Color3.new(0.0666667, 0.0666667, 0.0666667),
["RightLegColor"] = Color3.new(0.0666667, 0.0666667, 0.0666667),
["RightArmColor"] = Color3.new(1, 0, 0),
["LeftLegColor"] = Color3.new(1, 0, 0)
},
["scales"] =
{
["LowerLegHeight"] = 2e9,
["UpperTorsoWidth"] = 2e9,
["UpperArmHeight"] = 2e9,
["HandHeight"] = 2e9,
["UpperLegWidth"] = 2e9,
["LowerArmWidth"] = 2e9,
["FootWidth"] = 2e9,
["LowerArmHeight"] = 2e9,
["UpperArmWidth"] = 2e9,
["FootHeight"] = 2e9,
["LowerTorsoWidth"] = 2e9,
["UpperTorsoHeight"] = 2e9,
["HandWidth"] = 2e9,
["HeadScale"] = 2e9,
["UpperLegHeight"] = 2e9,
["LowerTorsoHeight"] = 2e9,
["LowerLegWidth"] = 2e9
},
["name"] = "",
["outfitId"] = 1,
["isOutfit"] = true,
["collageSeed"] = 0,
["lowerName"] = ""
}
local Event = game:GetService("ReplicatedStorage").AvatarEditor.Remote.CommitCharacterAppearance
Event:FireServer(titan)