getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 MewVIP
pushnumber 1
setfield -2 Value
getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 OtherLegendary
pushnumber 1
setfield -2 Value
getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 EeveeVIP
pushnumber 1
setfield -2 Value
getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 RunVIP
pushnumber 1
setfield -2 Value
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 JohtoVIP
pushnumber 1
setfield -2 Value
getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 KantoStarterVIP
pushnumber 1
setfield -2 Value
getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 LegendaryVIP
pushnumber 1
setfield -2 Value
getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 ShinyVIP
pushnumber 1
setfield -2 Value
getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 MoonVIP
pushnumber 1
setfield -2 Value
getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 MoreneyVIP
pushnumber 1
setfield -2 Value