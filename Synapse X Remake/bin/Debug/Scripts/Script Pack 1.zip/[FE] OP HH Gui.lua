--All credits to someone#8337 on discord.
--[[ 
	Leak if you want, I don't care about past projects.
	Next up is either Frappe or Dunkin Donuts.
	Thanks.
--]]

local plrc = game.Players.LocalPlayer.Character
local plr = game.Players.LocalPlayer

local HiltoN = Instance.new("ScreenGui")
local Base = Instance.new("Frame")
local Name = Instance.new("TextLabel")
local R304 = Instance.new("TextButton")
local Line = Instance.new("Frame")
local GBT = Instance.new("TextBox")
local R404 = Instance.new("TextButton")
local R504 = Instance.new("TextButton")
local R601 = Instance.new("TextButton")
local F7 = Instance.new("TextButton")
local R704 = Instance.new("TextButton")
local SF7 = Instance.new("TextButton")
local SR700 = Instance.new("TextButton")
local More = Instance.new("TextButton")
local SodaMachine = Instance.new("TextButton")
local R201 = Instance.new("TextButton")
local R202 = Instance.new("TextButton")
local R203 = Instance.new("TextButton")
local R204 = Instance.new("TextButton")
local R301 = Instance.new("TextButton")
local R302 = Instance.new("TextButton")
local R303 = Instance.new("TextButton")
local R401 = Instance.new("TextButton")
local R402 = Instance.new("TextButton")
local R403 = Instance.new("TextButton")
local R501 = Instance.new("TextButton")
local R502 = Instance.new("TextButton")
local R503 = Instance.new("TextButton")
local R604 = Instance.new("TextButton")
local R603 = Instance.new("TextButton")
local R602 = Instance.new("TextButton")
local R701 = Instance.new("TextButton")
local R702 = Instance.new("TextButton")
local R703 = Instance.new("TextButton")
local F2 = Instance.new("TextButton")
local F3 = Instance.new("TextButton")
local F4 = Instance.new("TextButton")
local F5 = Instance.new("TextButton")
local F6 = Instance.new("TextButton")
local Entrance = Instance.new("TextButton")
local Bar = Instance.new("TextButton")
local BackOffice = Instance.new("TextButton")
local Arcade = Instance.new("TextButton")
local Elevators = Instance.new("TextButton")
local Pool = Instance.new("TextButton")
local RegLine1 = Instance.new("TextButton")
local RegLine2 = Instance.new("TextButton")
local FitnessRoom = Instance.new("TextButton")
local ClickTP = Instance.new("TextButton")
local Reception = Instance.new("TextButton")
local Meals = Instance.new("TextButton")
local Drinks = Instance.new("TextButton")
local BackRoom = Instance.new("TextButton")
local Fly = Instance.new("TextButton")
local SpaSalon = Instance.new("TextButton")
local SuiteLine = Instance.new("TextButton")
local FastLine = Instance.new("TextButton")
local VIPLounge = Instance.new("TextButton")
local RGD = Instance.new("TextButton")
local GB = Instance.new("TextButton")
local RID = Instance.new("TextButton")
local RRRD = Instance.new("TextButton")
local RSRD = Instance.new("TextButton")
local Line_2 = Instance.new("Frame")
local Line_3 = Instance.new("Frame")
local Line_4 = Instance.new("Frame")
local SF2 = Instance.new("TextButton")
local SF3 = Instance.new("TextButton")
local SF4 = Instance.new("TextButton")
local SF5 = Instance.new("TextButton")
local SF6 = Instance.new("TextButton")
local SR200 = Instance.new("TextButton")
local SR300 = Instance.new("TextButton")
local SR400 = Instance.new("TextButton")
local SR500 = Instance.new("TextButton")
local SR600 = Instance.new("TextButton")

print("Loaded Instances.")

HiltoN.Name = "HiltoN"
HiltoN.Parent = game.Players.LocalPlayer.PlayerGui
HiltoN.ResetOnSpawn = false

Base.Name = "Base"
Base.Parent = game.Players.LocalPlayer.PlayerGui.HiltoN
Base.Active = true
Base.BackgroundColor3 = Color3.new(1, 0, 0)
Base.BackgroundTransparency = 0.40000000596046
Base.BorderSizePixel = 4
Base.ClipsDescendants = true
Base.Draggable = true
Base.Position = UDim2.new(0, 510, 0, 180)
Base.Size = UDim2.new(0, 375, 0, 370)

Name.Name = "Name"
Name.Parent = Base
Name.BackgroundColor3 = Color3.new(1, 1, 1)
Name.BackgroundTransparency = 1
Name.Size = UDim2.new(0, 375, 0, 50)
Name.Font = Enum.Font.ArialBold
Name.FontSize = Enum.FontSize.Size14
Name.Text = "HiltoN"
Name.TextColor3 = Color3.new(1, 1, 1)
Name.TextScaled = true
Name.TextSize = 14
Name.TextWrapped = true

R304.Name = "R304"
R304.Parent = Base
R304.BackgroundColor3 = Color3.new(1, 0, 0)
R304.BackgroundTransparency = 0.5
R304.BorderSizePixel = 4
R304.Position = UDim2.new(0, 335, 0, 154)
R304.Size = UDim2.new(0, 35, 0, 35)
R304.AutoButtonColor = false
R304.Font = Enum.Font.ArialBold
R304.FontSize = Enum.FontSize.Size14
R304.Text = "Room 304"
R304.TextColor3 = Color3.new(1, 1, 1)
R304.TextScaled = true
R304.TextSize = 14
R304.TextWrapped = true

Line.Name = "Line"
Line.Parent = Base
Line.BackgroundColor3 = Color3.new(0, 0, 0)
Line.Position = UDim2.new(0, 382, 0, 373)
Line.Size = UDim2.new(0, 0, 0, -326)

GBT.Name = "GBT"
GBT.Parent = Base
GBT.BackgroundColor3 = Color3.new(1, 0, 0)
GBT.BackgroundTransparency = 0.5
GBT.BorderSizePixel = 5
GBT.Position = UDim2.new(0, 485, 0, 56)
GBT.Size = UDim2.new(0, 184, 0, 33)
GBT.Font = Enum.Font.ArialBold
GBT.FontSize = Enum.FontSize.Size14
GBT.Text = "Beverage"
GBT.TextColor3 = Color3.new(1, 1, 1)
GBT.TextSize = 14

R404.Name = "R404"
R404.Parent = Base
R404.BackgroundColor3 = Color3.new(1, 0, 0)
R404.BackgroundTransparency = 0.5
R404.BorderSizePixel = 4
R404.Position = UDim2.new(0, 335, 0, 198)
R404.Size = UDim2.new(0, 35, 0, 35)
R404.AutoButtonColor = false
R404.Font = Enum.Font.ArialBold
R404.FontSize = Enum.FontSize.Size14
R404.Text = "Room 404"
R404.TextColor3 = Color3.new(1, 1, 1)
R404.TextScaled = true
R404.TextSize = 14
R404.TextWrapped = true

R504.Name = "R504"
R504.Parent = Base
R504.BackgroundColor3 = Color3.new(1, 0, 0)
R504.BackgroundTransparency = 0.5
R504.BorderSizePixel = 4
R504.Position = UDim2.new(0, 335, 0, 242)
R504.Size = UDim2.new(0, 35, 0, 35)
R504.AutoButtonColor = false
R504.Font = Enum.Font.ArialBold
R504.FontSize = Enum.FontSize.Size14
R504.Text = "Room 504"
R504.TextColor3 = Color3.new(1, 1, 1)
R504.TextScaled = true
R504.TextSize = 14
R504.TextWrapped = true

R601.Name = "R601"
R601.Parent = Base
R601.BackgroundColor3 = Color3.new(1, 0, 0)
R601.BackgroundTransparency = 0.5
R601.BorderSizePixel = 4
R601.Position = UDim2.new(0, 195, 0, 286)
R601.Size = UDim2.new(0, 40, 0, 35)
R601.AutoButtonColor = false
R601.Font = Enum.Font.ArialBold
R601.FontSize = Enum.FontSize.Size14
R601.Text = "Room 601"
R601.TextColor3 = Color3.new(1, 1, 1)
R601.TextScaled = true
R601.TextSize = 14
R601.TextWrapped = true

F7.Name = "F7"
F7.Parent = Base
F7.BackgroundColor3 = Color3.new(1, 0, 0)
F7.BackgroundTransparency = 0.5
F7.BorderSizePixel = 4
F7.Position = UDim2.new(0, 139, 0, 330)
F7.Size = UDim2.new(0, 40, 0, 35)
F7.AutoButtonColor = false
F7.Font = Enum.Font.ArialBold
F7.FontSize = Enum.FontSize.Size14
F7.Text = "Floor 7"
F7.TextColor3 = Color3.new(1, 1, 1)
F7.TextScaled = true
F7.TextSize = 14
F7.TextWrapped = true

R704.Name = "R704"
R704.Parent = Base
R704.BackgroundColor3 = Color3.new(1, 0, 0)
R704.BackgroundTransparency = 0.5
R704.BorderSizePixel = 4
R704.Position = UDim2.new(0, 335, 0, 330)
R704.Size = UDim2.new(0, 35, 0, 35)
R704.AutoButtonColor = false
R704.Font = Enum.Font.ArialBold
R704.FontSize = Enum.FontSize.Size14
R704.Text = "Room 704"
R704.TextColor3 = Color3.new(1, 1, 1)
R704.TextScaled = true
R704.TextSize = 14
R704.TextWrapped = true

SF7.Name = "SF7"
SF7.Parent = Base
SF7.BackgroundColor3 = Color3.new(1, 0, 0)
SF7.BackgroundTransparency = 0.5
SF7.BorderSizePixel = 4
SF7.Position = UDim2.new(0, 89, 0, 330)
SF7.Size = UDim2.new(0, 40, 0, 35)
SF7.AutoButtonColor = false
SF7.Font = Enum.Font.ArialBold
SF7.FontSize = Enum.FontSize.Size14
SF7.Text = "Suite Floor 7"
SF7.TextColor3 = Color3.new(1, 1, 1)
SF7.TextScaled = true
SF7.TextSize = 14
SF7.TextWrapped = true

SR700.Name = "SR700"
SR700.Parent = Base
SR700.BackgroundColor3 = Color3.new(1, 0, 0)
SR700.BackgroundTransparency = 0.5
SR700.BorderSizePixel = 4
SR700.Position = UDim2.new(0, 5, 0, 330)
SR700.Size = UDim2.new(0, 74, 0, 35)
SR700.AutoButtonColor = false
SR700.Font = Enum.Font.ArialBold
SR700.FontSize = Enum.FontSize.Size14
SR700.Text = "Suite Room 700"
SR700.TextColor3 = Color3.new(1, 1, 1)
SR700.TextScaled = true
SR700.TextSize = 14
SR700.TextWrapped = true

More.Name = "More"
More.Parent = Base
More.BackgroundColor3 = Color3.new(1, 0, 0)
More.BackgroundTransparency = 0.40000000596046
More.BorderSizePixel = 4
More.Position = UDim2.new(0, 274, 0, 0)
More.Size = UDim2.new(0, 72, 0, 26)
More.AutoButtonColor = false
More.Font = Enum.Font.ArialBold
More.FontSize = Enum.FontSize.Size24
More.Text = "More"
More.TextColor3 = Color3.new(1, 1, 1)
More.TextSize = 22
More.TextWrapped = true

SodaMachine.Name = "SodaMachine"
SodaMachine.Parent = Base
SodaMachine.BackgroundColor3 = Color3.new(1, 0, 0)
SodaMachine.BackgroundTransparency = 0.5
SodaMachine.BorderSizePixel = 4
SodaMachine.Position = UDim2.new(0, 395, 0, 286)
SodaMachine.Size = UDim2.new(0, 80, 0, 79)
SodaMachine.AutoButtonColor = false
SodaMachine.Font = Enum.Font.ArialBold
SodaMachine.FontSize = Enum.FontSize.Size14
SodaMachine.Text = "Soda Machine"
SodaMachine.TextColor3 = Color3.new(1, 1, 1)
SodaMachine.TextSize = 14
SodaMachine.TextWrapped = true

R201.Name = "R201"
R201.Parent = Base
R201.BackgroundColor3 = Color3.new(1, 0, 0)
R201.BackgroundTransparency = 0.5
R201.BorderSizePixel = 4
R201.Position = UDim2.new(0, 195, 0, 110)
R201.Size = UDim2.new(0, 40, 0, 35)
R201.AutoButtonColor = false
R201.Font = Enum.Font.ArialBold
R201.FontSize = Enum.FontSize.Size14
R201.Text = "Room 201"
R201.TextColor3 = Color3.new(1, 1, 1)
R201.TextScaled = true
R201.TextSize = 14
R201.TextWrapped = true

R202.Name = "R202"
R202.Parent = Base
R202.BackgroundColor3 = Color3.new(1, 0, 0)
R202.BackgroundTransparency = 0.5
R202.BorderSizePixel = 4
R202.Position = UDim2.new(0, 245, 0, 110)
R202.Size = UDim2.new(0, 35, 0, 35)
R202.AutoButtonColor = false
R202.Font = Enum.Font.ArialBold
R202.FontSize = Enum.FontSize.Size14
R202.Text = "Room 202"
R202.TextColor3 = Color3.new(1, 1, 1)
R202.TextScaled = true
R202.TextSize = 14
R202.TextWrapped = true

R203.Name = "R203"
R203.Parent = Base
R203.BackgroundColor3 = Color3.new(1, 0, 0)
R203.BackgroundTransparency = 0.5
R203.BorderSizePixel = 4
R203.Position = UDim2.new(0, 290, 0, 110)
R203.Size = UDim2.new(0, 35, 0, 35)
R203.AutoButtonColor = false
R203.Font = Enum.Font.ArialBold
R203.FontSize = Enum.FontSize.Size14
R203.Text = "Room 203"
R203.TextColor3 = Color3.new(1, 1, 1)
R203.TextScaled = true
R203.TextSize = 14
R203.TextWrapped = true

R204.Name = "R204"
R204.Parent = Base
R204.BackgroundColor3 = Color3.new(1, 0, 0)
R204.BackgroundTransparency = 0.5
R204.BorderSizePixel = 4
R204.Position = UDim2.new(0, 335, 0, 110)
R204.Size = UDim2.new(0, 35, 0, 35)
R204.AutoButtonColor = false
R204.Font = Enum.Font.ArialBold
R204.FontSize = Enum.FontSize.Size14
R204.Text = "Room 204"
R204.TextColor3 = Color3.new(1, 1, 1)
R204.TextScaled = true
R204.TextSize = 14
R204.TextWrapped = true

R301.Name = "R301"
R301.Parent = Base
R301.BackgroundColor3 = Color3.new(1, 0, 0)
R301.BackgroundTransparency = 0.5
R301.BorderSizePixel = 4
R301.Position = UDim2.new(0, 195, 0, 154)
R301.Size = UDim2.new(0, 40, 0, 35)
R301.AutoButtonColor = false
R301.Font = Enum.Font.ArialBold
R301.FontSize = Enum.FontSize.Size14
R301.Text = "Room 301"
R301.TextColor3 = Color3.new(1, 1, 1)
R301.TextScaled = true
R301.TextSize = 14
R301.TextWrapped = true

R302.Name = "R302"
R302.Parent = Base
R302.BackgroundColor3 = Color3.new(1, 0, 0)
R302.BackgroundTransparency = 0.5
R302.BorderSizePixel = 4
R302.Position = UDim2.new(0, 245, 0, 154)
R302.Size = UDim2.new(0, 35, 0, 35)
R302.AutoButtonColor = false
R302.Font = Enum.Font.ArialBold
R302.FontSize = Enum.FontSize.Size14
R302.Text = "Room 302"
R302.TextColor3 = Color3.new(1, 1, 1)
R302.TextScaled = true
R302.TextSize = 14
R302.TextWrapped = true

R303.Name = "R303"
R303.Parent = Base
R303.BackgroundColor3 = Color3.new(1, 0, 0)
R303.BackgroundTransparency = 0.5
R303.BorderSizePixel = 4
R303.Position = UDim2.new(0, 290, 0, 154)
R303.Size = UDim2.new(0, 35, 0, 35)
R303.AutoButtonColor = false
R303.Font = Enum.Font.ArialBold
R303.FontSize = Enum.FontSize.Size14
R303.Text = "Room 303"
R303.TextColor3 = Color3.new(1, 1, 1)
R303.TextScaled = true
R303.TextSize = 14
R303.TextWrapped = true

R401.Name = "R401"
R401.Parent = Base
R401.BackgroundColor3 = Color3.new(1, 0, 0)
R401.BackgroundTransparency = 0.5
R401.BorderSizePixel = 4
R401.Position = UDim2.new(0, 195, 0, 198)
R401.Size = UDim2.new(0, 40, 0, 35)
R401.AutoButtonColor = false
R401.Font = Enum.Font.ArialBold
R401.FontSize = Enum.FontSize.Size14
R401.Text = "Room 401"
R401.TextColor3 = Color3.new(1, 1, 1)
R401.TextScaled = true
R401.TextSize = 14
R401.TextWrapped = true

R402.Name = "R402"
R402.Parent = Base
R402.BackgroundColor3 = Color3.new(1, 0, 0)
R402.BackgroundTransparency = 0.5
R402.BorderSizePixel = 4
R402.Position = UDim2.new(0, 245, 0, 198)
R402.Size = UDim2.new(0, 35, 0, 35)
R402.AutoButtonColor = false
R402.Font = Enum.Font.ArialBold
R402.FontSize = Enum.FontSize.Size14
R402.Text = "Room 402"
R402.TextColor3 = Color3.new(1, 1, 1)
R402.TextScaled = true
R402.TextSize = 14
R402.TextWrapped = true

R403.Name = "R403"
R403.Parent = Base
R403.BackgroundColor3 = Color3.new(1, 0, 0)
R403.BackgroundTransparency = 0.5
R403.BorderSizePixel = 4
R403.Position = UDim2.new(0, 290, 0, 198)
R403.Size = UDim2.new(0, 35, 0, 35)
R403.AutoButtonColor = false
R403.Font = Enum.Font.ArialBold
R403.FontSize = Enum.FontSize.Size14
R403.Text = "Room 403"
R403.TextColor3 = Color3.new(1, 1, 1)
R403.TextScaled = true
R403.TextSize = 14
R403.TextWrapped = true

R501.Name = "R501"
R501.Parent = Base
R501.BackgroundColor3 = Color3.new(1, 0, 0)
R501.BackgroundTransparency = 0.5
R501.BorderSizePixel = 4
R501.Position = UDim2.new(0, 195, 0, 242)
R501.Size = UDim2.new(0, 40, 0, 35)
R501.AutoButtonColor = false
R501.Font = Enum.Font.ArialBold
R501.FontSize = Enum.FontSize.Size14
R501.Text = "Room 501"
R501.TextColor3 = Color3.new(1, 1, 1)
R501.TextScaled = true
R501.TextSize = 14
R501.TextWrapped = true

R502.Name = "R502"
R502.Parent = Base
R502.BackgroundColor3 = Color3.new(1, 0, 0)
R502.BackgroundTransparency = 0.5
R502.BorderSizePixel = 4
R502.Position = UDim2.new(0, 245, 0, 242)
R502.Size = UDim2.new(0, 35, 0, 35)
R502.AutoButtonColor = false
R502.Font = Enum.Font.ArialBold
R502.FontSize = Enum.FontSize.Size14
R502.Text = "Room 503"
R502.TextColor3 = Color3.new(1, 1, 1)
R502.TextScaled = true
R502.TextSize = 14
R502.TextWrapped = true

R503.Name = "R503"
R503.Parent = Base
R503.BackgroundColor3 = Color3.new(1, 0, 0)
R503.BackgroundTransparency = 0.5
R503.BorderSizePixel = 4
R503.Position = UDim2.new(0, 290, 0, 242)
R503.Size = UDim2.new(0, 35, 0, 35)
R503.AutoButtonColor = false
R503.Font = Enum.Font.ArialBold
R503.FontSize = Enum.FontSize.Size14
R503.Text = "Room 503"
R503.TextColor3 = Color3.new(1, 1, 1)
R503.TextScaled = true
R503.TextSize = 14
R503.TextWrapped = true

R604.Name = "R604"
R604.Parent = Base
R604.BackgroundColor3 = Color3.new(1, 0, 0)
R604.BackgroundTransparency = 0.5
R604.BorderSizePixel = 4
R604.Position = UDim2.new(0, 335, 0, 286)
R604.Size = UDim2.new(0, 35, 0, 35)
R604.AutoButtonColor = false
R604.Font = Enum.Font.ArialBold
R604.FontSize = Enum.FontSize.Size14
R604.Text = "Room 604"
R604.TextColor3 = Color3.new(1, 1, 1)
R604.TextScaled = true
R604.TextSize = 14
R604.TextWrapped = true

R603.Name = "R603"
R603.Parent = Base
R603.BackgroundColor3 = Color3.new(1, 0, 0)
R603.BackgroundTransparency = 0.5
R603.BorderSizePixel = 4
R603.Position = UDim2.new(0, 290, 0, 286)
R603.Size = UDim2.new(0, 35, 0, 35)
R603.AutoButtonColor = false
R603.Font = Enum.Font.ArialBold
R603.FontSize = Enum.FontSize.Size14
R603.Text = "Room 603"
R603.TextColor3 = Color3.new(1, 1, 1)
R603.TextScaled = true
R603.TextSize = 14
R603.TextWrapped = true

R602.Name = "R602"
R602.Parent = Base
R602.BackgroundColor3 = Color3.new(1, 0, 0)
R602.BackgroundTransparency = 0.5
R602.BorderSizePixel = 4
R602.Position = UDim2.new(0, 245, 0, 286)
R602.Size = UDim2.new(0, 35, 0, 35)
R602.AutoButtonColor = false
R602.Font = Enum.Font.ArialBold
R602.FontSize = Enum.FontSize.Size14
R602.Text = "Room 602"
R602.TextColor3 = Color3.new(1, 1, 1)
R602.TextScaled = true
R602.TextSize = 14
R602.TextWrapped = true

R701.Name = "R701"
R701.Parent = Base
R701.BackgroundColor3 = Color3.new(1, 0, 0)
R701.BackgroundTransparency = 0.5
R701.BorderSizePixel = 4
R701.Position = UDim2.new(0, 195, 0, 330)
R701.Size = UDim2.new(0, 40, 0, 35)
R701.AutoButtonColor = false
R701.Font = Enum.Font.ArialBold
R701.FontSize = Enum.FontSize.Size14
R701.Text = "Room 701"
R701.TextColor3 = Color3.new(1, 1, 1)
R701.TextScaled = true
R701.TextSize = 14
R701.TextWrapped = true

R702.Name = "R702"
R702.Parent = Base
R702.BackgroundColor3 = Color3.new(1, 0, 0)
R702.BackgroundTransparency = 0.5
R702.BorderSizePixel = 4
R702.Position = UDim2.new(0, 245, 0, 330)
R702.Size = UDim2.new(0, 35, 0, 35)
R702.AutoButtonColor = false
R702.Font = Enum.Font.ArialBold
R702.FontSize = Enum.FontSize.Size14
R702.Text = "Room 702"
R702.TextColor3 = Color3.new(1, 1, 1)
R702.TextScaled = true
R702.TextSize = 14
R702.TextWrapped = true

R703.Name = "R703"
R703.Parent = Base
R703.BackgroundColor3 = Color3.new(1, 0, 0)
R703.BackgroundTransparency = 0.5
R703.BorderSizePixel = 4
R703.Position = UDim2.new(0, 290, 0, 330)
R703.Size = UDim2.new(0, 35, 0, 35)
R703.AutoButtonColor = false
R703.Font = Enum.Font.ArialBold
R703.FontSize = Enum.FontSize.Size14
R703.Text = "Room 703"
R703.TextColor3 = Color3.new(1, 1, 1)
R703.TextScaled = true
R703.TextSize = 14
R703.TextWrapped = true

F2.Name = "F2"
F2.Parent = Base
F2.BackgroundColor3 = Color3.new(1, 0, 0)
F2.BackgroundTransparency = 0.5
F2.BorderSizePixel = 4
F2.Position = UDim2.new(0, 139, 0, 110)
F2.Size = UDim2.new(0, 40, 0, 35)
F2.AutoButtonColor = false
F2.Font = Enum.Font.ArialBold
F2.FontSize = Enum.FontSize.Size14
F2.Text = "Floor 2"
F2.TextColor3 = Color3.new(1, 1, 1)
F2.TextScaled = true
F2.TextSize = 14
F2.TextWrapped = true

F3.Name = "F3"
F3.Parent = Base
F3.BackgroundColor3 = Color3.new(1, 0, 0)
F3.BackgroundTransparency = 0.5
F3.BorderSizePixel = 4
F3.Position = UDim2.new(0, 139, 0, 154)
F3.Size = UDim2.new(0, 40, 0, 35)
F3.AutoButtonColor = false
F3.Font = Enum.Font.ArialBold
F3.FontSize = Enum.FontSize.Size14
F3.Text = "Floor 3"
F3.TextColor3 = Color3.new(1, 1, 1)
F3.TextScaled = true
F3.TextSize = 14
F3.TextWrapped = true

F4.Name = "F4"
F4.Parent = Base
F4.BackgroundColor3 = Color3.new(1, 0, 0)
F4.BackgroundTransparency = 0.5
F4.BorderSizePixel = 4
F4.Position = UDim2.new(0, 139, 0, 198)
F4.Size = UDim2.new(0, 40, 0, 35)
F4.AutoButtonColor = false
F4.Font = Enum.Font.ArialBold
F4.FontSize = Enum.FontSize.Size14
F4.Text = "Floor 4"
F4.TextColor3 = Color3.new(1, 1, 1)
F4.TextScaled = true
F4.TextSize = 14
F4.TextWrapped = true

F5.Name = "F5"
F5.Parent = Base
F5.BackgroundColor3 = Color3.new(1, 0, 0)
F5.BackgroundTransparency = 0.5
F5.BorderSizePixel = 4
F5.Position = UDim2.new(0, 139, 0, 242)
F5.Size = UDim2.new(0, 40, 0, 35)
F5.AutoButtonColor = false
F5.Font = Enum.Font.ArialBold
F5.FontSize = Enum.FontSize.Size14
F5.Text = "Floor 5"
F5.TextColor3 = Color3.new(1, 1, 1)
F5.TextScaled = true
F5.TextSize = 14
F5.TextWrapped = true

F6.Name = "F6"
F6.Parent = Base
F6.BackgroundColor3 = Color3.new(1, 0, 0)
F6.BackgroundTransparency = 0.5
F6.BorderSizePixel = 4
F6.Position = UDim2.new(0, 139, 0, 286)
F6.Size = UDim2.new(0, 40, 0, 35)
F6.AutoButtonColor = false
F6.Font = Enum.Font.ArialBold
F6.FontSize = Enum.FontSize.Size14
F6.Text = "Floor 6"
F6.TextColor3 = Color3.new(1, 1, 1)
F6.TextScaled = true
F6.TextSize = 14
F6.TextWrapped = true

Entrance.Name = "Entrance"
Entrance.Parent = Base
Entrance.BackgroundColor3 = Color3.new(1, 0, 0)
Entrance.BackgroundTransparency = 0.5
Entrance.BorderSizePixel = 4
Entrance.Position = UDim2.new(0, 485, 0, 154)
Entrance.Size = UDim2.new(0, 90, 0, 35)
Entrance.AutoButtonColor = false
Entrance.Font = Enum.Font.ArialBold
Entrance.FontSize = Enum.FontSize.Size10
Entrance.Text = "Entrance"
Entrance.TextColor3 = Color3.new(1, 1, 1)
Entrance.TextScaled = true
Entrance.TextSize = 10
Entrance.TextWrapped = true

Bar.Name = "Bar"
Bar.Parent = Base
Bar.BackgroundColor3 = Color3.new(1, 0, 0)
Bar.BackgroundTransparency = 0.5
Bar.BorderSizePixel = 4
Bar.Position = UDim2.new(0, 395, 0, 110)
Bar.Size = UDim2.new(0, 35, 0, 35)
Bar.AutoButtonColor = false
Bar.Font = Enum.Font.ArialBold
Bar.FontSize = Enum.FontSize.Size18
Bar.Text = "Bar"
Bar.TextColor3 = Color3.new(1, 1, 1)
Bar.TextSize = 18
Bar.TextWrapped = true

BackOffice.Name = "BackOffice"
BackOffice.Parent = Base
BackOffice.BackgroundColor3 = Color3.new(1, 0, 0)
BackOffice.BackgroundTransparency = 0.5
BackOffice.BorderSizePixel = 4
BackOffice.Position = UDim2.new(0, 395, 0, 198)
BackOffice.Size = UDim2.new(0, 35, 0, 35)
BackOffice.AutoButtonColor = false
BackOffice.Font = Enum.Font.ArialBold
BackOffice.FontSize = Enum.FontSize.Size11
BackOffice.Text = "Back Office"
BackOffice.TextColor3 = Color3.new(1, 1, 1)
BackOffice.TextSize = 11
BackOffice.TextWrapped = true

Arcade.Name = "Arcade"
Arcade.Parent = Base
Arcade.BackgroundColor3 = Color3.new(1, 0, 0)
Arcade.BackgroundTransparency = 0.5
Arcade.BorderSizePixel = 4
Arcade.Position = UDim2.new(0, 440, 0, 242)
Arcade.Size = UDim2.new(0, 35, 0, 35)
Arcade.AutoButtonColor = false
Arcade.Font = Enum.Font.ArialBold
Arcade.FontSize = Enum.FontSize.Size10
Arcade.Text = "Arcade"
Arcade.TextColor3 = Color3.new(1, 1, 1)
Arcade.TextSize = 10
Arcade.TextWrapped = true

Elevators.Name = "Elevators"
Elevators.Parent = Base
Elevators.BackgroundColor3 = Color3.new(1, 0, 0)
Elevators.BackgroundTransparency = 0.5
Elevators.BorderSizePixel = 4
Elevators.Position = UDim2.new(0, 485, 0, 110)
Elevators.Size = UDim2.new(0, 90, 0, 35)
Elevators.AutoButtonColor = false
Elevators.Font = Enum.Font.ArialBold
Elevators.Text = "Elevators"
Elevators.TextColor3 = Color3.new(1, 1, 1)
Elevators.TextScaled = true
Elevators.TextWrapped = true

Pool.Name = "Pool"
Pool.Parent = Base
Pool.BackgroundColor3 = Color3.new(1, 0, 0)
Pool.BackgroundTransparency = 0.5
Pool.BorderSizePixel = 4
Pool.Position = UDim2.new(0, 585, 0, 110)
Pool.Size = UDim2.new(0, 85, 0, 35)
Pool.AutoButtonColor = false
Pool.Font = Enum.Font.ArialBold
Pool.FontSize = Enum.FontSize.Size10
Pool.Text = "Pool"
Pool.TextColor3 = Color3.new(1, 1, 1)
Pool.TextScaled = true
Pool.TextSize = 10
Pool.TextWrapped = true

RegLine1.Name = "RegLine1"
RegLine1.Parent = Base
RegLine1.BackgroundColor3 = Color3.new(1, 0, 0)
RegLine1.BackgroundTransparency = 0.5
RegLine1.BorderSizePixel = 4
RegLine1.Position = UDim2.new(0, 580, 0, 198)
RegLine1.Size = UDim2.new(0, 40, 0, 35)
RegLine1.AutoButtonColor = false
RegLine1.Font = Enum.Font.ArialBold
RegLine1.FontSize = Enum.FontSize.Size10
RegLine1.Text = "\nRegular Line 1"
RegLine1.TextColor3 = Color3.new(1, 1, 1)
RegLine1.TextSize = 10
RegLine1.TextWrapped = true

RegLine2.Name = "RegLine2"
RegLine2.Parent = Base
RegLine2.BackgroundColor3 = Color3.new(1, 0, 0)
RegLine2.BackgroundTransparency = 0.5
RegLine2.BorderSizePixel = 4
RegLine2.Position = UDim2.new(0, 530, 0, 198)
RegLine2.Size = UDim2.new(0, 40, 0, 35)
RegLine2.AutoButtonColor = false
RegLine2.Font = Enum.Font.ArialBold
RegLine2.FontSize = Enum.FontSize.Size10
RegLine2.Text = "\nRegular Line 2"
RegLine2.TextColor3 = Color3.new(1, 1, 1)
RegLine2.TextSize = 10
RegLine2.TextWrapped = true

FitnessRoom.Name = "FitnessRoom"
FitnessRoom.Parent = Base
FitnessRoom.BackgroundColor3 = Color3.new(1, 0, 0)
FitnessRoom.BackgroundTransparency = 0.5
FitnessRoom.BorderSizePixel = 4
FitnessRoom.Position = UDim2.new(0, 629, 0, 198)
FitnessRoom.Size = UDim2.new(0, 40, 0, 35)
FitnessRoom.AutoButtonColor = false
FitnessRoom.Font = Enum.Font.ArialBold
FitnessRoom.Text = "Fitness Room"
FitnessRoom.TextColor3 = Color3.new(1, 1, 1)
FitnessRoom.TextScaled = true
FitnessRoom.TextSize = 7
FitnessRoom.TextWrapped = true

ClickTP.Name = "ClickTP"
ClickTP.Parent = Base
ClickTP.BackgroundColor3 = Color3.new(1, 0, 0)
ClickTP.BackgroundTransparency = 0.5
ClickTP.BorderSizePixel = 4
ClickTP.Position = UDim2.new(0, 575, 0, 286)
ClickTP.Size = UDim2.new(0, 95, 0, 79)
ClickTP.AutoButtonColor = false
ClickTP.Font = Enum.Font.ArialBold
ClickTP.FontSize = Enum.FontSize.Size14
ClickTP.Text = "ClickTP"
ClickTP.TextColor3 = Color3.new(1, 1, 1)
ClickTP.TextSize = 14
ClickTP.TextWrapped = true

Reception.Name = "Reception"
Reception.Parent = Base
Reception.BackgroundColor3 = Color3.new(1, 0, 0)
Reception.BackgroundTransparency = 0.5
Reception.BorderSizePixel = 4
Reception.Position = UDim2.new(0, 440, 0, 198)
Reception.Size = UDim2.new(0, 80, 0, 35)
Reception.AutoButtonColor = false
Reception.Font = Enum.Font.ArialBold
Reception.Text = "Reception"
Reception.TextColor3 = Color3.new(1, 1, 1)
Reception.TextScaled = true
Reception.TextSize = 7
Reception.TextWrapped = true

Meals.Name = "Meals"
Meals.Parent = Base
Meals.BackgroundColor3 = Color3.new(1, 0, 0)
Meals.BackgroundTransparency = 0.5
Meals.BorderSizePixel = 4
Meals.Position = UDim2.new(0, 440, 0, 110)
Meals.Size = UDim2.new(0, 35, 0, 35)
Meals.AutoButtonColor = false
Meals.Font = Enum.Font.ArialBold
Meals.FontSize = Enum.FontSize.Size12
Meals.Text = "Meals"
Meals.TextColor3 = Color3.new(1, 1, 1)
Meals.TextSize = 12
Meals.TextWrapped = true

Drinks.Name = "Drinks"
Drinks.Parent = Base
Drinks.BackgroundColor3 = Color3.new(1, 0, 0)
Drinks.BackgroundTransparency = 0.5
Drinks.BorderSizePixel = 4
Drinks.Position = UDim2.new(0, 395, 0, 154)
Drinks.Size = UDim2.new(0, 35, 0, 35)
Drinks.AutoButtonColor = false
Drinks.Font = Enum.Font.ArialBold
Drinks.FontSize = Enum.FontSize.Size11
Drinks.Text = "Drinks"
Drinks.TextColor3 = Color3.new(1, 1, 1)
Drinks.TextSize = 11
Drinks.TextWrapped = true

BackRoom.Name = "BackRoom"
BackRoom.Parent = Base
BackRoom.BackgroundColor3 = Color3.new(1, 0, 0)
BackRoom.BackgroundTransparency = 0.5
BackRoom.BorderSizePixel = 4
BackRoom.Position = UDim2.new(0, 395, 0, 242)
BackRoom.Size = UDim2.new(0, 35, 0, 35)
BackRoom.AutoButtonColor = false
BackRoom.Font = Enum.Font.ArialBold
BackRoom.Text = "Back Room"
BackRoom.TextColor3 = Color3.new(1, 1, 1)
BackRoom.TextScaled = true
BackRoom.TextSize = 7
BackRoom.TextWrapped = true

Fly.Name = "Fly"
Fly.Parent = Base
Fly.BackgroundColor3 = Color3.new(1, 0, 0)
Fly.BackgroundTransparency = 0.5
Fly.BorderSizePixel = 4
Fly.Position = UDim2.new(0, 485, 0, 286)
Fly.Size = UDim2.new(0, 80, 0, 79)
Fly.AutoButtonColor = false
Fly.Font = Enum.Font.ArialBold
Fly.FontSize = Enum.FontSize.Size14
Fly.Text = "Fly"
Fly.TextColor3 = Color3.new(1, 1, 1)
Fly.TextSize = 14
Fly.TextWrapped = true

SpaSalon.Name = "SpaSalon"
SpaSalon.Parent = Base
SpaSalon.BackgroundColor3 = Color3.new(1, 0, 0)
SpaSalon.BackgroundTransparency = 0.5
SpaSalon.BorderSizePixel = 4
SpaSalon.Position = UDim2.new(0, 440, 0, 154)
SpaSalon.Size = UDim2.new(0, 35, 0, 35)
SpaSalon.AutoButtonColor = false
SpaSalon.Font = Enum.Font.ArialBold
SpaSalon.FontSize = Enum.FontSize.Size11
SpaSalon.Text = "Spa&Salon"
SpaSalon.TextColor3 = Color3.new(1, 1, 1)
SpaSalon.TextScaled = true
SpaSalon.TextSize = 11
SpaSalon.TextWrapped = true

SuiteLine.Name = "SuiteLine"
SuiteLine.Parent = Base
SuiteLine.BackgroundColor3 = Color3.new(1, 0, 0)
SuiteLine.BackgroundTransparency = 0.5
SuiteLine.BorderSizePixel = 4
SuiteLine.Position = UDim2.new(0, 485, 0, 242)
SuiteLine.Size = UDim2.new(0, 80, 0, 35)
SuiteLine.AutoButtonColor = false
SuiteLine.Font = Enum.Font.ArialBold
SuiteLine.FontSize = Enum.FontSize.Size14
SuiteLine.Text = "Suite Line"
SuiteLine.TextColor3 = Color3.new(1, 1, 1)
SuiteLine.TextSize = 14
SuiteLine.TextWrapped = true

FastLine.Name = "FastLine"
FastLine.Parent = Base
FastLine.BackgroundColor3 = Color3.new(1, 0, 0)
FastLine.BackgroundTransparency = 0.5
FastLine.BorderSizePixel = 4
FastLine.Position = UDim2.new(0, 575, 0, 242)
FastLine.Size = UDim2.new(0, 95, 0, 35)
FastLine.AutoButtonColor = false
FastLine.Font = Enum.Font.ArialBold
FastLine.FontSize = Enum.FontSize.Size14
FastLine.Text = "Fast Line"
FastLine.TextColor3 = Color3.new(1, 1, 1)
FastLine.TextSize = 14
FastLine.TextWrapped = true

VIPLounge.Name = "VIPLounge"
VIPLounge.Parent = Base
VIPLounge.BackgroundColor3 = Color3.new(1, 0, 0)
VIPLounge.BackgroundTransparency = 0.5
VIPLounge.BorderSizePixel = 4
VIPLounge.Position = UDim2.new(0, 585, 0, 154)
VIPLounge.Size = UDim2.new(0, 85, 0, 35)
VIPLounge.AutoButtonColor = false
VIPLounge.Font = Enum.Font.ArialBold
VIPLounge.Text = "VIP Lounge"
VIPLounge.TextColor3 = Color3.new(1, 1, 1)
VIPLounge.TextScaled = true
VIPLounge.TextSize = 7
VIPLounge.TextWrapped = true

RGD.Name = "RGD"
RGD.Parent = Base
RGD.BackgroundColor3 = Color3.new(1, 0, 0)
RGD.BackgroundTransparency = 0.5
RGD.BorderSizePixel = 4
RGD.Position = UDim2.new(0, 290, 0, 55)
RGD.Size = UDim2.new(0, 80, 0, 35)
RGD.AutoButtonColor = false
RGD.Font = Enum.Font.ArialBold
RGD.FontSize = Enum.FontSize.Size14
RGD.Text = "Remove Gamepass Doors"
RGD.TextColor3 = Color3.new(1, 1, 1)
RGD.TextScaled = true
RGD.TextSize = 14
RGD.TextWrapped = true

GB.Name = "GB"
GB.Parent = Base
GB.BackgroundColor3 = Color3.new(1, 0, 0)
GB.BackgroundTransparency = 0.5
GB.BorderSizePixel = 4
GB.Position = UDim2.new(0, 395, 0, 55)
GB.Size = UDim2.new(0, 79, 0, 35)
GB.AutoButtonColor = false
GB.Font = Enum.Font.ArialBold
GB.FontSize = Enum.FontSize.Size14
GB.Text = "Give Beverage"
GB.TextColor3 = Color3.new(1, 1, 1)
GB.TextScaled = true
GB.TextSize = 14
GB.TextWrapped = true

RID.Name = "RID"
RID.Parent = Base
RID.BackgroundColor3 = Color3.new(1, 0, 0)
RID.BackgroundTransparency = 0.5
RID.BorderSizePixel = 4
RID.Position = UDim2.new(0, 200, 0, 55)
RID.Size = UDim2.new(0, 80, 0, 35)
RID.AutoButtonColor = false
RID.Font = Enum.Font.ArialBold
RID.FontSize = Enum.FontSize.Size14
RID.Text = "Remove Invisible Walls"
RID.TextColor3 = Color3.new(1, 1, 1)
RID.TextScaled = true
RID.TextSize = 14
RID.TextWrapped = true

RRRD.Name = "RRRD"
RRRD.Parent = Base
RRRD.BackgroundColor3 = Color3.new(1, 0, 0)
RRRD.BackgroundTransparency = 0.5
RRRD.BorderSizePixel = 4
RRRD.Position = UDim2.new(0, 95, 0, 55)
RRRD.Size = UDim2.new(0, 80, 0, 35)
RRRD.AutoButtonColor = false
RRRD.Font = Enum.Font.ArialBold
RRRD.FontSize = Enum.FontSize.Size14
RRRD.Text = "Remove Regular Room Doors"
RRRD.TextColor3 = Color3.new(1, 1, 1)
RRRD.TextScaled = true
RRRD.TextSize = 14
RRRD.TextWrapped = true

RSRD.Name = "RSRD"
RSRD.Parent = Base
RSRD.BackgroundColor3 = Color3.new(1, 0, 0)
RSRD.BackgroundTransparency = 0.5
RSRD.BorderSizePixel = 4
RSRD.Position = UDim2.new(0, 5, 0, 55)
RSRD.Size = UDim2.new(0, 80, 0, 35)
RSRD.AutoButtonColor = false
RSRD.Font = Enum.Font.ArialBold
RSRD.FontSize = Enum.FontSize.Size14
RSRD.Text = "Remove Suite Room Doors"
RSRD.TextColor3 = Color3.new(1, 1, 1)
RSRD.TextScaled = true
RSRD.TextSize = 14
RSRD.TextWrapped = true

Line_2.Name = "Line"
Line_2.Parent = Base
Line_2.BackgroundColor3 = Color3.new(0, 0, 0)
Line_2.Position = UDim2.new(0, 187, 0, 373)
Line_2.Size = UDim2.new(0, 0, 0, -326)

Line_3.Name = "Line"
Line_3.Parent = Base
Line_3.BackgroundColor3 = Color3.new(1, 1, 1)
Line_3.Position = UDim2.new(0, 0, 0, 100)
Line_3.Size = UDim2.new(0, 674, 0, 0)

Line_4.Name = "Line"
Line_4.Parent = Base
Line_4.BackgroundColor3 = Color3.new(1, 1, 1)
Line_4.Position = UDim2.new(0, 0, 0, 45)
Line_4.Size = UDim2.new(0, 674, 0, 0)

SF2.Name = "SF2"
SF2.Parent = Base
SF2.BackgroundColor3 = Color3.new(1, 0, 0)
SF2.BackgroundTransparency = 0.5
SF2.BorderSizePixel = 4
SF2.Position = UDim2.new(0, 89, 0, 110)
SF2.Size = UDim2.new(0, 40, 0, 35)
SF2.AutoButtonColor = false
SF2.Font = Enum.Font.ArialBold
SF2.FontSize = Enum.FontSize.Size14
SF2.Text = "Suite Floor 2"
SF2.TextColor3 = Color3.new(1, 1, 1)
SF2.TextScaled = true
SF2.TextSize = 14
SF2.TextWrapped = true

SF3.Name = "SF3"
SF3.Parent = Base
SF3.BackgroundColor3 = Color3.new(1, 0, 0)
SF3.BackgroundTransparency = 0.5
SF3.BorderSizePixel = 4
SF3.Position = UDim2.new(0, 89, 0, 154)
SF3.Size = UDim2.new(0, 40, 0, 35)
SF3.AutoButtonColor = false
SF3.Font = Enum.Font.ArialBold
SF3.FontSize = Enum.FontSize.Size14
SF3.Text = "Suite Floor 3"
SF3.TextColor3 = Color3.new(1, 1, 1)
SF3.TextScaled = true
SF3.TextSize = 14
SF3.TextWrapped = true

SF4.Name = "SF4"
SF4.Parent = Base
SF4.BackgroundColor3 = Color3.new(1, 0, 0)
SF4.BackgroundTransparency = 0.5
SF4.BorderSizePixel = 4
SF4.Position = UDim2.new(0, 89, 0, 198)
SF4.Size = UDim2.new(0, 40, 0, 35)
SF4.AutoButtonColor = false
SF4.Font = Enum.Font.ArialBold
SF4.FontSize = Enum.FontSize.Size14
SF4.Text = "Suite Floor 4"
SF4.TextColor3 = Color3.new(1, 1, 1)
SF4.TextScaled = true
SF4.TextSize = 14
SF4.TextWrapped = true

SF5.Name = "SF5"
SF5.Parent = Base
SF5.BackgroundColor3 = Color3.new(1, 0, 0)
SF5.BackgroundTransparency = 0.5
SF5.BorderSizePixel = 4
SF5.Position = UDim2.new(0, 89, 0, 242)
SF5.Size = UDim2.new(0, 40, 0, 35)
SF5.AutoButtonColor = false
SF5.Font = Enum.Font.ArialBold
SF5.FontSize = Enum.FontSize.Size14
SF5.Text = "Suite Floor 5"
SF5.TextColor3 = Color3.new(1, 1, 1)
SF5.TextScaled = true
SF5.TextSize = 14
SF5.TextWrapped = true

SF6.Name = "SF6"
SF6.Parent = Base
SF6.BackgroundColor3 = Color3.new(1, 0, 0)
SF6.BackgroundTransparency = 0.5
SF6.BorderSizePixel = 4
SF6.Position = UDim2.new(0, 89, 0, 286)
SF6.Size = UDim2.new(0, 40, 0, 35)
SF6.AutoButtonColor = false
SF6.Font = Enum.Font.ArialBold
SF6.FontSize = Enum.FontSize.Size14
SF6.Text = "Suite Floor 6"
SF6.TextColor3 = Color3.new(1, 1, 1)
SF6.TextScaled = true
SF6.TextSize = 14
SF6.TextWrapped = true

SR200.Name = "SR200"
SR200.Parent = Base
SR200.BackgroundColor3 = Color3.new(1, 0, 0)
SR200.BackgroundTransparency = 0.5
SR200.BorderSizePixel = 4
SR200.Position = UDim2.new(0, 5, 0, 110)
SR200.Size = UDim2.new(0, 74, 0, 35)
SR200.AutoButtonColor = false
SR200.Font = Enum.Font.ArialBold
SR200.FontSize = Enum.FontSize.Size14
SR200.Text = "Suite Room 200"
SR200.TextColor3 = Color3.new(1, 1, 1)
SR200.TextScaled = true
SR200.TextSize = 14
SR200.TextWrapped = true

SR300.Name = "SR300"
SR300.Parent = Base
SR300.BackgroundColor3 = Color3.new(1, 0, 0)
SR300.BackgroundTransparency = 0.5
SR300.BorderSizePixel = 4
SR300.Position = UDim2.new(0, 5, 0, 154)
SR300.Size = UDim2.new(0, 74, 0, 35)
SR300.AutoButtonColor = false
SR300.Font = Enum.Font.ArialBold
SR300.FontSize = Enum.FontSize.Size14
SR300.Text = "Suite Room 300"
SR300.TextColor3 = Color3.new(1, 1, 1)
SR300.TextScaled = true
SR300.TextSize = 14
SR300.TextWrapped = true

SR400.Name = "SR400"
SR400.Parent = Base
SR400.BackgroundColor3 = Color3.new(1, 0, 0)
SR400.BackgroundTransparency = 0.5
SR400.BorderSizePixel = 4
SR400.Position = UDim2.new(0, 5, 0, 198)
SR400.Size = UDim2.new(0, 74, 0, 35)
SR400.AutoButtonColor = false
SR400.Font = Enum.Font.ArialBold
SR400.FontSize = Enum.FontSize.Size14
SR400.Text = "Suite Room 300"
SR400.TextColor3 = Color3.new(1, 1, 1)
SR400.TextScaled = true
SR400.TextSize = 14
SR400.TextWrapped = true

SR500.Name = "SR500"
SR500.Parent = Base
SR500.BackgroundColor3 = Color3.new(1, 0, 0)
SR500.BackgroundTransparency = 0.5
SR500.BorderSizePixel = 4
SR500.Position = UDim2.new(0, 5, 0, 242)
SR500.Size = UDim2.new(0, 74, 0, 35)
SR500.AutoButtonColor = false
SR500.Font = Enum.Font.ArialBold
SR500.FontSize = Enum.FontSize.Size14
SR500.Text = "Suite Room 400"
SR500.TextColor3 = Color3.new(1, 1, 1)
SR500.TextScaled = true
SR500.TextSize = 14
SR500.TextWrapped = true

SR600.Name = "SR600"
SR600.Parent = Base
SR600.BackgroundColor3 = Color3.new(1, 0, 0)
SR600.BackgroundTransparency = 0.5
SR600.BorderSizePixel = 4
SR600.Position = UDim2.new(0, 5, 0, 286)
SR600.Size = UDim2.new(0, 74, 0, 35)
SR600.AutoButtonColor = false
SR600.Font = Enum.Font.ArialBold
SR600.FontSize = Enum.FontSize.Size14
SR600.Text = "Suite Room 500"
SR600.TextColor3 = Color3.new(1, 1, 1)
SR600.TextScaled = true
SR600.TextSize = 14
SR600.TextWrapped = true

local hiltonbase = plr.PlayerGui.HiltoN.Base

local MoreBtn = function()
	if hiltonbase.Size == UDim2.new(0, 375, 0, 370) then
		hiltonbase:TweenSize(UDim2.new(0, 675, 0, 370), "Out", "Back", 0.7)
		hiltonbase.More.Text = "Less"
		print("Opening")
	elseif hiltonbase.Size == UDim2.new(0, 675, 0, 370) then
        hiltonbase:TweenSize(UDim2.new(0, 375, 0, 370), "In", "Back", 0.7)
        hiltonbase.More.Text = "More"
        print("Closing!")
	end
end
More.MouseButton1Click:connect(MoreBtn)

local Room201 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-49, 63, 203)
end
R201.MouseButton1Down:connect(Room201)

local Room202 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-47, 63, 251)
end
R202.MouseButton1Down:connect(Room202)

local Room203 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-94, 63, 264)
end
R203.MouseButton1Down:connect(Room203)

local Room204 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-94, 63, 217)
end
R204.MouseButton1Down:connect(Room204)

local Room301 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-47, 76, 204)
end
R301.MouseButton1Down:connect(Room301)


local Room302 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-47, 76, 251)
end
R302.MouseButton1Down:connect(Room302)


local Room303 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-94, 76, 265)
end
R303.MouseButton1Down:connect(Room303)


local Room304 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-94, 76, 217)
end
R304.MouseButton1Down:connect(Room304)


local Room401 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-47, 90, 203)
end
R401.MouseButton1Down:connect(Room401)


local Room402 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-46, 90, 251)
end
R402.MouseButton1Down:connect(Room402)


local Room403 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-95, 90, 264)
end
R403.MouseButton1Down:connect(Room403)

local Room404 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-94, 90, 217)
end
R404.MouseButton1Down:connect(Room404)


local Room501 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-47, 103, 203)
end
R501.MouseButton1Down:connect(Room501)


local Room502 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-47, 103, 252)
end
R502.MouseButton1Down:connect(Room502)


local Room503 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-94, 103, 264)
end
R503.MouseButton1Down:connect(Room503)

local Room504 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-95, 103, 217)
end
R504.MouseButton1Down:connect(Room504)

local Room601 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-45, 117, 204)
end
R601.MouseButton1Down:connect(Room601)

local Room602 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-46, 117, 251)
end
R602.MouseButton1Down:connect(Room602)

local Room603 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-96, 117, 263)
end
R603.MouseButton1Down:connect(Room603)

local Room604 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-94, 117, 217)
end
R604.MouseButton1Down:connect(Room604)


local Room701 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-46, 130, 204)
end
R701.MouseButton1Down:connect(Room701)


local Room702 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-48, 130, 251)
end
R702.MouseButton1Down:connect(Room702)


local Room703 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-94, 130, 264)
end
R703.MouseButton1Down:connect(Room703)


local Room704 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-95, 130, 217)
end
R704.MouseButton1Down:connect(Room704)

local RArcade = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-111, 46, 245)
end
Arcade.MouseButton1Down:connect(RArcade)

local SM = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-59, 32, 149)
end
SodaMachine.MouseButton1Down:connect(SM)

local M = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-87, 32, 166)
end
Meals.MouseButton1Down:connect(M)

local RDrinks = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-100, 32, 166)
end
Drinks.MouseButton1Down:connect(RDrinks)

local RPool = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-180, 32, 173)
end
Pool.MouseButton1Down:connect(RPool)

local RBar = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-83, 32, 148)
end
Bar.MouseButton1Down:connect(RBar)

local RBackRoom = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-84, 32, 199)
end
BackRoom.MouseButton1Down:connect(RBackRoom)

local RBackOffice = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-86, 32, 227)
end
BackOffice.MouseButton1Down:connect(RBackOffice)

local RReception = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-73, 32, 203)
end
Reception.MouseButton1Down:connect(RReception)

local REntrance = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(1, 32, 194)
end
Entrance.MouseButton1Down:connect(REntrance)

local RVipLounge = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-40, 46, 178)
end
VIPLounge.MouseButton1Down:connect(RVipLounge)

local RSF7 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-36, 134, 172)
end
SF7.MouseButton1Down:connect(RSF7)

local RSF6 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-36, 120, 172)
end
SF6.MouseButton1Down:connect(RSF6)

local RSF5 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-35, 106, 172)
end
SF5.MouseButton1Down:connect(RSF5)

local RSF4 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-35, 91, 172)
end
SF4.MouseButton1Down:connect(RSF4)

local RSF3 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-35, 77, 172)
end
SF3.MouseButton1Down:connect(RSF3)

local RSF2 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-35, 63, 172)
end
SF2.MouseButton1Down:connect(RSF2)


local RSuiteLine = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-58, 32, 197)
end
SuiteLine.MouseButton1Down:connect(RSuiteLine)

local RFitnessRoom = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-28, 46, 225)
end
FitnessRoom.MouseButton1Down:connect(RFitnessRoom)


local RFastLine = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-58, 32, 183)
end
FastLine.MouseButton1Down:connect(RFastLine)

local RRegLine1 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-28, 32, 211)
end
RegLine1.MouseButton1Down:connect(RRegLine1)

local RRegLine2 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-58, 32, 227)
end
RegLine2.MouseButton1Down:connect(RRegLine2)

local S2 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-58, 63, 154)
end
SR200.MouseButton1Down:connect(S2)

local S3 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-58, 77, 154)
end
SR300.MouseButton1Down:connect(S3)

local S4 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-58, 91, 154)
end
SR400.MouseButton1Down:connect(S4)

local S5 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-58, 106, 154)
end
SR500.MouseButton1Down:connect(S5)

local S6 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-58, 120, 154)
end
SR600.MouseButton1Down:connect(S6)


local S7 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-58, 134, 154)
end
SR700.MouseButton1Down:connect(S7)

local RF1E = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-16, 32, 259)
end
Elevators.MouseButton1Down:connect(RF1E)

local RF2 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-105, 63, 234)
end
F2.MouseButton1Down:connect(RF2)

local RF3 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-105, 76, 234)
end
F3.MouseButton1Down:connect(RF3)

local RF4 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-108, 90, 234)
end
F4.MouseButton1Down:connect(RF4)


local RF5 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-108, 103, 234)
end
F5.MouseButton1Down:connect(RF5)

local RF6 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-108, 117, 234)
end
F6.MouseButton1Down:connect(RF6)

local RF7 = function()
    plrc.HumanoidRootPart.CFrame = CFrame.new(-108, 131, 234)
end
F7.MouseButton1Down:connect(RF7)



local RClickTP = function()
local Tool = Instance.new("HopperBin", game.Players.LocalPlayer.Backpack)
Tool.Name = "Teleport"
local Mouse = game.Players.LocalPlayer:GetMouse()

Mouse.Button1Down:connect(function()
if Tool.Active == true then
game.Players.LocalPlayer.Character.Torso.CFrame = Mouse.Hit
end
end)
end
ClickTP.MouseButton1Click:connect(RClickTP)

local lul = function()
	for i,v in pairs(game.Workspace:GetChildren()) do
	if v.Name == "Room" then
		for a,b in pairs(v:GetChildren()) do
			if b.Name == "RoomDoor" then
				b:Destroy()
			end
		end
	end
end

end

RRRD.MouseButton1Click:connect(lul)

local RRSRD = function()
	for i,v in pairs(game.Workspace:GetChildren()) do
	if v.Name == "SuiteRoom" then
		for a,b in pairs(v:GetChildren()) do
			if b.Name == "RoomDoor" then
				b:Destroy()
			end
		end
	end
end
end
RSRD.MouseButton1Click:connect(RRSRD)

local RRIW = function()
	for i,v in pairs(game.Workspace:GetChildren()) do
	if v.Name == "GroupDoorArea" then
		v:Destroy()
	end
end
end
RGD.MouseButton1Click:connect(RRIW)

local RGB = function()
	game.ReplicatedStorage.GiveBeverage:InvokeServer(GBT.Text)
end
GB.MouseButton1Click:connect(RGB)

local RRGD = function()
while true do
wait()
game.Workspace.GamepassDoorArea:Destroy()
end
end
RGD.MouseButton1Down:connect(RRGD)

local RFly = function()
	repeat wait()
    until game.Players.LocalPlayer and game.Players.LocalPlayer.Character and game.Players.LocalPlayer.Character:findFirstChild("Torso") and game.Players.LocalPlayer.Character:findFirstChild("Humanoid")
local mouse = game.Players.LocalPlayer:GetMouse()
repeat wait() until mouse
local plr = game.Players.LocalPlayer
local torso = plr.Character.Torso
local flying = true
local deb = true
local ctrl = {f = 0, b = 0, l = 0, r = 0}
local lastctrl = {f = 0, b = 0, l = 0, r = 0}
local maxspeed = 50
local speed = 0
 
function Fly()
local bg = Instance.new("BodyGyro", torso)
bg.P = 9e4
bg.maxTorque = Vector3.new(9e9, 9e9, 9e9)
bg.cframe = torso.CFrame
local bv = Instance.new("BodyVelocity", torso)
bv.velocity = Vector3.new(0,0.1,0)
bv.maxForce = Vector3.new(9e9, 9e9, 9e9)
repeat wait()
plr.Character.Humanoid.PlatformStand = true
if ctrl.l + ctrl.r ~= 0 or ctrl.f + ctrl.b ~= 0 then
speed = speed+.5+(speed/maxspeed)
if speed > maxspeed then
speed = maxspeed
end
elseif not (ctrl.l + ctrl.r ~= 0 or ctrl.f + ctrl.b ~= 0) and speed ~= 0 then
speed = speed-1
if speed < 0 then
speed = 0
end
end
if (ctrl.l + ctrl.r) ~= 0 or (ctrl.f + ctrl.b) ~= 0 then
bv.velocity = ((game.Workspace.CurrentCamera.CoordinateFrame.lookVector * (ctrl.f+ctrl.b)) + ((game.Workspace.CurrentCamera.CoordinateFrame * CFrame.new(ctrl.l+ctrl.r,(ctrl.f+ctrl.b)*.2,0).p) - game.Workspace.CurrentCamera.CoordinateFrame.p))*speed
lastctrl = {f = ctrl.f, b = ctrl.b, l = ctrl.l, r = ctrl.r}
elseif (ctrl.l + ctrl.r) == 0 and (ctrl.f + ctrl.b) == 0 and speed ~= 0 then
bv.velocity = ((game.Workspace.CurrentCamera.CoordinateFrame.lookVector * (lastctrl.f+lastctrl.b)) + ((game.Workspace.CurrentCamera.CoordinateFrame * CFrame.new(lastctrl.l+lastctrl.r,(lastctrl.f+lastctrl.b)*.2,0).p) - game.Workspace.CurrentCamera.CoordinateFrame.p))*speed
else
bv.velocity = Vector3.new(0,0.1,0)
end
bg.cframe = game.Workspace.CurrentCamera.CoordinateFrame * CFrame.Angles(-math.rad((ctrl.f+ctrl.b)*50*speed/maxspeed),0,0)
until not flying
ctrl = {f = 0, b = 0, l = 0, r = 0}
lastctrl = {f = 0, b = 0, l = 0, r = 0}
speed = 0
bg:Destroy()
bv:Destroy()
plr.Character.Humanoid.PlatformStand = false
end
mouse.KeyDown:connect(function(key)
if key:lower() == "e" then
if flying then flying = false
else
flying = true
Fly()
end
elseif key:lower() == "w" then
ctrl.f = 1
elseif key:lower() == "s" then
ctrl.b = -1
elseif key:lower() == "a" then
ctrl.l = -1
elseif key:lower() == "d" then
ctrl.r = 1
end
end)
mouse.KeyUp:connect(function(key)
if key:lower() == "w" then
ctrl.f = 0
elseif key:lower() == "s" then
ctrl.b = 0
elseif key:lower() == "a" then
ctrl.l = 0
elseif key:lower() == "d" then
ctrl.r = 0
end
end)
Fly()
end
Fly.MouseButton1Click:connect(RFly)