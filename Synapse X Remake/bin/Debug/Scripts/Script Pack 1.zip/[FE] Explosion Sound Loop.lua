while true do
game.StarterPack.RocketLauncher.Explosion.Playing = true
wait(0.1)
end