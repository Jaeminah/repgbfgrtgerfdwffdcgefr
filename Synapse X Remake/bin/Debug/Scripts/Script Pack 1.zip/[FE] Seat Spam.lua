game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-10,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-15,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-20,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-25,7.5,54)
wait(0.05)
game.Players.LocalPlayer.Character.Humanoid.Sit            = false
wait(0.05)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-30,7.5,54)
wait(0.05)