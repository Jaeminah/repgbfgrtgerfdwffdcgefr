local A_1 = "Sandwich"
local A_2 = -10000000
local Event = game:GetService("ReplicatedStorage").Events.PurchaseFood
Event:FireServer(A_1, A_2)