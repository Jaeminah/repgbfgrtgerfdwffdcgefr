game.StarterGui:SetCoreGuiEnabled(2, true)

