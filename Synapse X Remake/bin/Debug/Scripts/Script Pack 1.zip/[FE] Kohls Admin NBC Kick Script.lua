-- Get Admin and chat ":btools me" before executing

user = "username"

remote = game.Players.LocalPlayer.Backpack.Delete.delete
remote:FireServer(game.Players[user])