getglobal game
getfield -1 ReplicatedStorage
getfield -1 removeDebris
getfield -1 FireServer
pushvalue -2
pushnumber 30
pcall 2 1 0