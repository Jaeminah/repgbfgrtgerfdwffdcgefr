while true do
    game.Workspace.BasicCommand:FireServer(7, "Shutting down server...", 5.5, 1.5, true, "Pizza")
wait()
end