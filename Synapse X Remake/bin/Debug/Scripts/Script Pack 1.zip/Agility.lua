getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Agility
pushstring 500
setfield -2 Value
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Agility
pushstring true
setfield -2 RobloxLocked