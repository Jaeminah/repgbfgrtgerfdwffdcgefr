game.ReplicatedStorage.GiveTool:FireServer("Water")
--[[
Change water with any drink.

Drink List

Water
Cola
Fanta
Sparky
Surgic
Charge
Mtn Dew
You dont get charged!

--]]