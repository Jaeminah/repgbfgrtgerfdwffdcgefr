while wait() do
game.Workspace.YourNameHere.YourGunNameHere.CSEngine.FireSound:FireServer(Workspace.YourNameHere.YourGunNameHere.Handle.Shoot)
end