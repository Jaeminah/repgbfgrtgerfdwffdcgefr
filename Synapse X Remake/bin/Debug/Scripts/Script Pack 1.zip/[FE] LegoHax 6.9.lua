-- Objects

local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local Frame_2 = Instance.new("Frame")
local Frame_3 = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")
local page = Instance.new("Frame")
local Username = Instance.new("TextBox")
local Thicc = Instance.new("TextButton")
local Kill = Instance.new("TextButton")
local Rocky2U = Instance.new("TextButton")
local ClearWS = Instance.new("TextButton")
local Punish = Instance.new("TextButton")
local Character = Instance.new("TextButton")
local Punish_All = Instance.new("TextButton")

-- Properties

ScreenGui.Parent = game.CoreGui

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.new(1, 1, 1)
Frame.BackgroundTransparency = 1
Frame.Position = UDim2.new(0.153488368, 0, 0.326530635, 0)
Frame.Size = UDim2.new(0, 311, 0, 226)
Frame.Active = true
Frame.Draggable = true

Frame_2.Parent = Frame
Frame_2.BackgroundColor3 = Color3.new(0.160784, 0.501961, 0.72549)
Frame_2.BorderSizePixel = 0
Frame_2.Size = UDim2.new(1.0018605, 0, 0.0578998066, 0)

Frame_3.Parent = Frame
Frame_3.BackgroundColor3 = Color3.new(0.203922, 0.596078, 0.858824)
Frame_3.BorderSizePixel = 0
Frame_3.Position = UDim2.new(0, 0, 0.0578998066, 0)
Frame_3.Size = UDim2.new(1.0018605, 0, 0.115799613, 0)

TextLabel.Parent = Frame_3
TextLabel.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel.BackgroundTransparency = 1
TextLabel.Size = UDim2.new(1.0018605, 0, 0.927469134, 0)
TextLabel.Font = Enum.Font.SourceSansLight
TextLabel.FontSize = Enum.FontSize.Size28
TextLabel.Text = "legohax 69"
TextLabel.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
TextLabel.TextSize = 25

page.Name = "page"
page.Parent = Frame
page.BackgroundColor3 = Color3.new(0.92549, 0.941177, 0.945098)
page.BorderSizePixel = 0
page.Position = UDim2.new(0, 0, 0.173699424, 0)
page.Size = UDim2.new(1.0018605, 0, 0.831170201, 0)

Username.Name = "Username"
Username.Parent = page
Username.BackgroundColor3 = Color3.new(0.498039, 0.54902, 0.552941)
Username.BorderSizePixel = 0
Username.Position = UDim2.new(0.11559929, 0, 0.0351461992, 0)
Username.Size = UDim2.new(0.770661891, 0, 0.102735043, 0)
Username.Font = Enum.Font.SourceSans
Username.FontSize = Enum.FontSize.Size14
Username.Text = "Username"
Username.TextColor3 = Color3.new(0.941177, 0.941177, 0.941177)
Username.TextScaled = true
Username.TextSize = 14
Username.TextWrapped = true

Thicc.Name = "Thicc"
Thicc.Parent = page
Thicc.BackgroundColor3 = Color3.new(0.172549, 0.243137, 0.313726)
Thicc.BorderSizePixel = 0
Thicc.Position = UDim2.new(0.0385330915, 0, 0.205470085, 0)
Thicc.Size = UDim2.new(0.443130583, 0, 0.154102564, 0)
Thicc.Font = Enum.Font.SourceSans
Thicc.FontSize = Enum.FontSize.Size28
Thicc.Text = "Thicc"
Thicc.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Thicc.TextSize = 26

Kill.Name = "Kill"
Kill.Parent = page
Kill.BackgroundColor3 = Color3.new(0.172549, 0.243137, 0.313726)
Kill.BorderSizePixel = 0
Kill.Position = UDim2.new(0.520196795, 0, 0.205470085, 0)
Kill.Size = UDim2.new(0.443130583, 0, 0.154102564, 0)
Kill.Font = Enum.Font.SourceSans
Kill.FontSize = Enum.FontSize.Size28
Kill.Text = "Kill"
Kill.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Kill.TextSize = 26

Rocky2U.Name = "FE Rocky2U"
Rocky2U.Parent = page
Rocky2U.BackgroundColor3 = Color3.new(0.172549, 0.243137, 0.313726)
Rocky2U.BorderSizePixel = 0
Rocky2U.Position = UDim2.new(0.0385330915, 0, 0.462307692, 0)
Rocky2U.Size = UDim2.new(0.443130583, 0, 0.154102564, 0)
Rocky2U.Font = Enum.Font.SourceSans
Rocky2U.FontSize = Enum.FontSize.Size28
Rocky2U.Text = "FE Rocky2U"
Rocky2U.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Rocky2U.TextSize = 26

ClearWS.Name = "ClearWS"
ClearWS.Parent = page
ClearWS.BackgroundColor3 = Color3.new(0.172549, 0.243137, 0.313726)
ClearWS.BorderSizePixel = 0
ClearWS.Position = UDim2.new(0.520196795, 0, 0.462307692, 0)
ClearWS.Size = UDim2.new(0.443130583, 0, 0.154102564, 0)
ClearWS.Font = Enum.Font.SourceSans
ClearWS.FontSize = Enum.FontSize.Size28
ClearWS.Text = "Clear WS"
ClearWS.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
ClearWS.TextSize = 26

Punish.Name = "Punish"
Punish.Parent = page
Punish.BackgroundColor3 = Color3.new(0.172549, 0.243137, 0.313726)
Punish.BorderSizePixel = 0
Punish.Position = UDim2.new(0.0385330915, 0, 0.719145298, 0)
Punish.Size = UDim2.new(0.443130583, 0, 0.154102564, 0)
Punish.Font = Enum.Font.SourceSans
Punish.FontSize = Enum.FontSize.Size28
Punish.Text = "Punish"
Punish.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Punish.TextSize = 26

Punish_All.Name = "Clear Humanoid"
Punish_All.Parent = page
Punish_All.BackgroundColor3 = Color3.new(0.172549, 0.243137, 0.313726)
Punish_All.BorderSizePixel = 0
Punish_All.Position = UDim2.new(0.520196795, 0, 0.719145298, 0)
Punish_All.Size = UDim2.new(0.443130583, 0, 0.154102564, 0)
Punish_All.Font = Enum.Font.SourceSans
Punish_All.FontSize = Enum.FontSize.Size28
Punish_All.Text = "Clear Humanoid"
Punish_All.TextColor3 = Color3.new(0.92549, 0.941177, 0.945098)
Punish_All.TextSize = 26

function GetPlayer(String)
    local Found = {}
    local strl = String:lower()
    if strl == "all" then
        for i,v in pairs(game.Players:GetPlayers()) do
            table.insert(Found,v)
        end
    elseif strl == "others" then
        for i,v in pairs(game.Players:GetPlayers()) do
            if v.Name ~= game.Players.LocalPlayer.Name then
                table.insert(Found,v)
            end
        end    
    else
        for i,v in pairs(game.Players:GetPlayers()) do
            if v.Name:lower():sub(1, #String) == String:lower() then
                table.insert(Found,v)
            end
        end    
    end
    return Found    
end

--for i,v in pairs(GetPlayer(Username.Text))do

Kill.MouseButton1Click:connect(function()
	if workspace:FindFirstChild("GiveSystem") then
	e = workspace.GiveSystem.GiveItem
	elseif workspace:FindFirstChild("HandToCentre") then
	e = workspace.HandToCentre.GiveItem
	else
	warn("MODEL NOT FOUND")
	end
	for i,v in pairs(GetPlayer(Username.Text))do
		local blacklist = {
		["HandToCentre"] = true;
		["GiveSystem"] = true;
		}
		local randomperson = {}
		ypcall(function() e:FireServer(workspace, game:GetService"Players"[v.Name].Character.Head) end)
	end
end)

Rocky2U.MouseButton1Click:connect(function()
	--[[
  ____            _          ____        _        ____ __  __ ____      
 |  _ \ ___   ___| | ___   _|___ \ _   _( )___   / ___|  \/  |  _ \ ___ 
 | |_) / _ \ / __| |/ / | | | __) | | | |// __| | |   | |\/| | | | / __|
 |  _ < (_) | (__|   <| |_| |/ __/| |_| | \__ \ | |___| |  | | |_| \__ \
 |_| \_\___/ \___|_|\_\\__, |_____|\__,_| |___/  \____|_|  |_|____/|___/
                       |___/                                            

Want to keep this admin command updated?
Join our Discord! https://discord.me/rainbow2u

--]]


if workspace:FindFirstChild'GiveSystem' then
if workspace.GiveSystem:FindFirstChild'GiveItem' then
maind = workspace.GiveSystem.GiveItem

elseif workspace:FindFirstChild'HandToCentre' then
if workspace.HandToCentre:FindFirstChild'SendItem' then
maind = workspace.HandToCentre.SendItem
 end end end

local ADMINS = {}
local BANS = {}

function _G.ADD_ADMIN(ID) table.insert(ADMINS, ID) end
function _G.ADD_BAN(ID) table.insert(BANS, ID) end

local VERSION = 'unOfficial 1.8.1'
local UPDATED = '2017/10/05'
local CHANGELOG = {
	' - Removed Patched Properties',
	' - Removed Guest Support',
	' - Removed Broken Shutdown Command'
}

local CREDITS = [[
 Rocky2u - lol
 veinyrox - ;crash
 Harkinian - half of the message function
 Moon - cmd bar addon idea
 N3xul - Fixing stuff because of Roblox Update
]]

local _CORE = game.Players.LocalPlayer.PlayerGui
local _LIGHTING = game:GetService('Lighting')
local _NETWORK = game:GetService('NetworkClient')
local _PLAYERS = game:GetService('Players')

local LP = _PLAYERS.LocalPlayer
local MOUSE = LP:GetMouse()

local SERVER_LOCKED = false
local SHOWING_MESSAGE = false

local SERVICES = {}
SERVICES.EVENTS = {}

local COMMANDS = {}
local STD = {}
local JAILED = {}
local KICKS = {}
local LOOPED_H = {}
local LOOPED_K = {}

local C_PREFIX = ';'
local SPLIT = ' '

local NEW = LoadLibrary('RbxUtility').Create

function UPDATE_CHAT(PLAYER) local C = PLAYER.Chatted:connect(function(M) if CHECK_ADMIN(PLAYER) then DEXECUTE(M, PLAYER) end end) table.insert(SERVICES.EVENTS, C) end
function STD.TABLE(T, V) if not T then return false end for i,v in pairs(T) do if v == V then return true end end return false end
function STD.ENDAT(S, V) local SF = S:find(V) if SF then return S:sub(0, SF - string.len(V)), true else return S, false end end
function CHECK_ADMIN(PLAYER) if FIND_IN_TABLE(ADMINS, PLAYER.userId) then return true elseif PLAYER.userId == LP.userId then return true end end
function FCOMMAND(COMMAND) for i,v in pairs(COMMANDS) do if v.N:lower() == COMMAND:lower() or STD.TABLE(v.A, COMMAND:lower()) then return v end end end
function GCOMMAND(M) local CMD, HS = STD.ENDAT(M:lower(), SPLIT) if HS then return {CMD, true} else return {CMD, false} end end
function GPREFIX(STRING) if STRING:sub(1, string.len(C_PREFIX)) == C_PREFIX then return {'COMMAND', string.len(C_PREFIX) + 1} end return end
function GARGS(STRING) local A = {} local NA = nil local HS = nil local S = STRING repeat NA, HS = STD.ENDAT(S:lower(), SPLIT) if NA ~= '' then table.insert(A, NA) S = S:sub(string.len(NA) + string.len(SPLIT) + 1) end until not HS return A end
function GCAPARGS(STRING) local A = {} local NA = nil local HS = nil local S = STRING repeat NA, HS = STD.ENDAT(S, SPLIT) if NA ~= '' then table.insert(A, NA) S = S:sub(string.len(NA) + string.len(SPLIT) + 1) end until not HS return A end
function ECOMMAND(STRING, SPEAKER) repeat if STRING:find('  ') then STRING = STRING:gsub('  ', ' ') end until not STRING:find('  ') local SCMD, A, CMD SCMD = GCOMMAND(STRING) CMD = FCOMMAND(SCMD[1]) if not CMD then return end A = STRING:sub(string.len(SCMD[1]) + string.len(SPLIT) + 1) local ARGS = GARGS(A) CA = GCAPARGS(A) pcall(function() CMD.F(ARGS, SPEAKER) end) end
function DEXECUTE(STRING, SPEAKER) if not CHECK_ADMIN(SPEAKER) then return end STRING = STRING:gsub('/e ', '') local GP = GPREFIX(STRING) if not GP then return end STRING = STRING:sub(GP[2]) if GP[1] == 'COMMAND' then ECOMMAND(STRING, SPEAKER) end end

function GLS(LOWER, START) local AA = '' for i,v in pairs(CA) do if i > START then if AA ~= '' then AA = AA .. ' ' .. v else AA = AA .. v end end end if not LOWER then return AA else return string.lower(AA) end end
function C3(R, G, B) return Color3.new(R/255, G/255, B/255) end
function GET_MASS(A, B) B = 0 for i,v in pairs(A:GetChildren()) do if v:IsA('BasePart') then B = B + v:GetMass() end GET_MASS(v) end return B end

local STUFF = '[ Rocky2u\'s CMDs ] : '
local NOCLIP, JESUSFLY, SWIM = false, false, false

_PLAYERS.PlayerAdded:connect(function(PLAYER)
	if SERVER_LOCKED then PLAYER.CharacterAdded:connect(function() table.insert(KICKS, PLAYER) return end) end
	if FIND_IN_TABLE(BANS, PLAYER.userId) then PLAYER.CharacterAdded:connect(function() table.insert(KICKS, PLAYER) return end) end
	UPDATE_CHAT(PLAYER)
	if CHECK_ADMIN(PLAYER) then PLAYER.CharacterAdded:connect(function() game.Chat:Chat(PLAYER.Character.Head, STUFF .. 'Welcome, you\'re an admin!') end) end
end)

game:GetService('RunService').Stepped:connect(function()
	for i,v in pairs(_PLAYERS:GetPlayers()) do
		if FIND_IN_TABLE(KICKS, v) then KICK(v) end
		if FIND_IN_TABLE(LOOPED_H, v.Name) then
			v.Character.Humanoid.Health = v.Character.Humanoid.MaxHealth
		end
		if FIND_IN_TABLE(LOOPED_K, v.Name) then
			maind:FireServer(workspace,v.Character.Torso.Neck)
		end
	end
	if NOCLIP then
		if LP.Character:FindFirstChild('Humanoid') then LP.Character.Humanoid:ChangeState(11) end
	elseif JESUSFLY then
		if LP.Character:FindFirstChild('Humanoid') then LP.Character.Humanoid:ChangeState(12) end
	elseif SWIM then
		if LP.Character:FindFirstChild('Humanoid') then LP.Character.Humanoid:ChangeState(4) end
	end
end)

function ADD_COMMAND(N, D, A, F) table.insert(COMMANDS, {N = N, D = D, A = A, F = F}) end

function GET_PLAYER(NAME, SPEAKER)
	local NAME_TABLE = {}
	NAME = NAME:lower()
	if NAME == 'me' then
		table.insert(NAME_TABLE, SPEAKER.Name)
	elseif NAME == 'others' then
		for i,v in pairs(_PLAYERS:GetPlayers()) do if v.Name ~= SPEAKER.Name then table.insert(NAME_TABLE, v.Name) end end
	elseif NAME == 'all' then
		for i,v in pairs(_PLAYERS:GetPlayers()) do table.insert(NAME_TABLE, v.Name) end
	elseif NAME == 'random' then
		table.insert(NAME_TABLE, _PLAYERS:GetPlayers()[math.random(1, #_PLAYERS:GetPlayers())].Name)
	elseif NAME == 'team' then
		for i,v in pairs(_PLAYERS:GetPlayers()) do if v.TeamColor == SPEAKER.TeamColor then table.insert(NAME_TABLE, v.Name) end end
	elseif NAME == 'nonadmins' then
		for i,v in pairs(_PLAYERS:GetPlayers()) do if not CHECK_ADMIN(v) then table.insert(NAME_TABLE, v.Name) end end
	elseif NAME == 'admins' then
		for i,v in pairs(_PLAYERS:GetPlayers()) do if CHECK_ADMIN(v) then table.insert(NAME_TABLE, v.Name) end end
	elseif NAME == 'nonfriends' then
		for i,v in pairs(_PLAYERS:GetPlayers()) do if not v:IsFriendsWith(SPEAKER.userId) then table.insert(NAME_TABLE, v.Name) end end
	elseif NAME == 'friends' then
		for i,v in pairs(_PLAYERS:GetPlayers()) do if v ~= SPEAKER and v:IsFriendsWith(SPEAKER.userId) then table.insert(NAME_TABLE, v.Name) end end
	elseif NAME == 'nbcs' then
		for i,v in pairs(_PLAYERS:GetPlayers()) do if v.MembershipType == Enum.MembershipType.None then table.insert(NAME_TABLE, v.Name) end end
	elseif NAME == 'bcs' then
		for i,v in pairs(_PLAYERS:GetPlayers()) do if v.MembershipType == Enum.MembershipType.BuildersClub then table.insert(NAME_TABLE, v.Name) end end
	elseif NAME == 'tbcs' then
		for i,v in pairs(_PLAYERS:GetPlayers()) do if v.MembershipType == Enum.MembershipType.TurboBuildersClub then table.insert(NAME_TABLE, v.Name) end end
	elseif NAME == 'obcs' then
		for i,v in pairs(_PLAYERS:GetPlayers()) do if v.MembershipType == Enum.MembershipType.OutrageousBuildersClub then table.insert(NAME_TABLE, v.Name) end end
	else
		for i,v in pairs(_PLAYERS:GetPlayers()) do local L_NAME = v.Name:lower() local F = L_NAME:find(NAME) if F == 1 then table.insert(NAME_TABLE, v.Name) end end
	end
	return NAME_TABLE
end

local SI = 'rbxasset://textures/blackBkg_square.png'

function LOAD_DATA()
	local DATA = Instance.new('Folder')
	
	GUIS = Instance.new('Folder', DATA)
	HUMANOIDS = Instance.new('Folder', DATA)
	OTHER = Instance.new('Folder', DATA)
	
	MAIN_GUI = Instance.new('ScreenGui', GUIS)
        MAIN_GUI.ResetOnSpawn = false
	MAIN_GUI.Name = 'seth_main'
	NEW'TextLabel'{Name = 'main', Active = true, BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.25, BorderSizePixel = 0, Position = UDim2.new(0.5, -200, 0.4, 0), Size = UDim2.new(0, 400, 0, 25), Draggable = true, Font = 'SourceSansBold', Text = ' Control Center', TextColor3 = C3(255, 255, 255), TextSize = 20, TextXAlignment = 'Left', Parent = MAIN_GUI}
		NEW'Frame'{Name = 'holder', BackgroundColor3 = C3(255, 255, 255), BackgroundTransparency = 0.25, BorderSizePixel = 0, Position = UDim2.new(0, 0, 1, 0), Size = UDim2.new(1, 25, 12, 0), Parent = MAIN_GUI.main}
			local BUTTONS = Instance.new('Folder', MAIN_GUI.main.holder) BUTTONS.Name = 'buttons'
				NEW'TextButton'{Name = 'server', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.25, BorderSizePixel = 0, Position = UDim2.new(0, 5, 0, 5), Size = UDim2.new(0, 100, 0, 30), ClipsDescendants = true, Font = 'SourceSansBold', Text = 'server info', TextColor3 = C3(255, 255, 255), TextSize = 20, Parent = BUTTONS}
				NEW'TextButton'{Name = 'admins', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.25, BorderSizePixel = 0, Position = UDim2.new(0, 110, 0, 5), Size = UDim2.new(0, 100, 0, 30), ClipsDescendants = true, Font = 'SourceSansBold', Text = 'admins', TextColor3 = C3(255, 255, 255), TextSize = 20, Parent = BUTTONS}
				NEW'TextButton'{Name = 'bans', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.25, BorderSizePixel = 0, Position = UDim2.new(0, 215, 0, 5), Size = UDim2.new(0, 100, 0, 30), ClipsDescendants = true, Font = 'SourceSansBold', Text = 'bans', TextColor3 = C3(255, 255, 255), TextSize = 20, Parent = BUTTONS}
				NEW'TextButton'{Name = 'cmds', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.25, BorderSizePixel = 0, Position = UDim2.new(0, 320, 0, 5), Size = UDim2.new(0, 100, 0, 30), ClipsDescendants = true, Font = 'SourceSansBold', Text = 'commands', TextColor3 = C3(255, 255, 255), TextSize = 20, Parent = BUTTONS}
				NEW'TextButton'{Name = 'fun', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.25, BorderSizePixel = 0, Position = UDim2.new(0, 50, 0, 40), Size = UDim2.new(0, 105, 0, 30), ClipsDescendants = true, Font = 'SourceSansBold', Text = 'fun', TextColor3 = C3(255, 255, 255), TextSize = 20, Parent = BUTTONS}
				NEW'TextButton'{Name = 'changelog', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.25, BorderSizePixel = 0, Position = UDim2.new(0, 160, 0, 40), Size = UDim2.new(0, 105, 0, 30), ClipsDescendants = true, Font = 'SourceSansBold', Text = 'changelog', TextColor3 = C3(255, 255, 255), TextSize = 20, Parent = BUTTONS}
				NEW'TextButton'{Name = 'credits', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.25, BorderSizePixel = 0, Position = UDim2.new(0, 270, 0, 40), Size = UDim2.new(0, 105, 0, 30), ClipsDescendants = true, Font = 'SourceSansBold', Text = 'credits', TextColor3 = C3(255, 255, 255), TextSize = 20, Parent = BUTTONS}
				
			local HOLDERS = Instance.new('Folder', MAIN_GUI.main.holder) HOLDERS.Name = 'holders'
				NEW'Frame'{Name = 'server', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.8, BorderSizePixel = 0, Position = UDim2.new(0, 5, 0, 85), Size = UDim2.new(1, -10, 0, 210), Parent = HOLDERS}
					NEW'TextLabel'{Name = 'fe', BackgroundColor3 = C3(255, 255, 255), BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0, 30), Font = 'SourceSansBold', Text = ' FilteringEnabled | ', TextColor3 = C3(0, 0, 0), TextSize = 24, TextTransparency = 0.25, TextXAlignment = 'Left', Parent = HOLDERS.server}
					NEW'TextLabel'{Name = 'place_id', BackgroundColor3 = C3(255, 255, 255), BackgroundTransparency = 1, Position = UDim2.new(0, 0, 0, 90), Size = UDim2.new(1, 0, 0, 30), Font = 'SourceSansBold', Text = ' Place ID | ', TextColor3 = C3(0, 0, 0), TextSize = 24, TextTransparency = 0.25, TextXAlignment = 'Left', Parent = HOLDERS.server}
					NEW'TextLabel'{Name = 'players', BackgroundColor3 = C3(255, 255, 255), BackgroundTransparency = 1, Position = UDim2.new(0, 0, 0, 120), Size = UDim2.new(1, 0, 0, 30), Font = 'SourceSansBold', Text = ' Players | ', TextColor3 = C3(0, 0, 0), TextSize = 24, TextTransparency = 0.25, TextXAlignment = 'Left', Parent = HOLDERS.server}
					NEW'TextLabel'{Name = 'time', BackgroundColor3 = C3(255, 255, 255), BackgroundTransparency = 1, Position = UDim2.new(0, 0, 0, 60), Size = UDim2.new(1, 0, 0, 30), Font = 'SourceSansBold', Text = ' Time | ', TextColor3 = C3(0, 0, 0), TextSize = 24, TextTransparency = 0.25, TextXAlignment = 'Left', Parent = HOLDERS.server}
					NEW'TextLabel'{Name = 'gravity', BackgroundColor3 = C3(255, 255, 255), BackgroundTransparency = 1, Position = UDim2.new(0, 0, 0, 30), Size = UDim2.new(1, 0, 0, 30), Font = 'SourceSansBold', Text = ' Gravity | ', TextColor3 = C3(0, 0, 0), TextSize = 24, TextTransparency = 0.25, TextXAlignment = 'Left', Parent = HOLDERS.server}
				NEW'ScrollingFrame'{Name = 'admins', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.8, BorderSizePixel = 0, Position = UDim2.new(0, 5, 0, 85), Size = UDim2.new(1, -10, 0, 210), Visible = false, CanvasSize = UDim2.new(0, 0, 0, 0), ScrollBarThickness = 5, TopImage = SI, MidImage = SI, BottomImage = SI, Parent = HOLDERS}
				NEW'ScrollingFrame'{Name = 'bans', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.8, BorderSizePixel = 0, Position = UDim2.new(0, 5, 0, 85), Size = UDim2.new(1, -10, 0, 210), Visible = false, CanvasSize = UDim2.new(0, 0, 0, 0), ScrollBarThickness = 5, TopImage = SI, MidImage = SI, BottomImage = SI, Parent = HOLDERS}
				NEW'ScrollingFrame'{Name = 'cmds', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.8, BorderSizePixel = 0, Position = UDim2.new(0, 5, 0, 115), Size = UDim2.new(1, -10, 0, 210), Visible = false, CanvasSize = UDim2.new(0, 0, 0, 0), ScrollBarThickness = 5, TopImage = SI, MidImage = SI, BottomImage = SI, Parent = HOLDERS}
				NEW'ScrollingFrame'{Name = 'fun', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.8, BorderSizePixel = 0, Position = UDim2.new(0, 5, 0, 85), Size = UDim2.new(1, -10, 0, 210), Visible = false, CanvasSize = UDim2.new(0, 0, 0, 0), ScrollBarThickness = 5, TopImage = SI, MidImage = SI, BottomImage = SI, Parent = HOLDERS}
				NEW'ScrollingFrame'{Name = 'changelog', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.8, BorderSizePixel = 0, Position = UDim2.new(0, 5, 0, 85), Size = UDim2.new(1, -10, 0, 210), Visible = false, CanvasSize = UDim2.new(0, 0, 0, 0), ScrollBarThickness = 5, TopImage = SI, MidImage = SI, BottomImage = SI, Parent = HOLDERS}
					local Y_CHANGES = 0
					for i,v in pairs(CHANGELOG) do
						NEW'TextLabel'{Name = '', BackgroundColor3 = C3(255, 255, 255), BackgroundTransparency = 1, Position = UDim2.new(0, 0, 0, Y_CHANGES), Size = UDim2.new(1, 0, 0, 30), Font = 'SourceSansBold', Text = v, TextColor3 = C3(0, 0, 0), TextSize = 24, TextTransparency = 0.25, TextXAlignment = 'Left', Parent = HOLDERS.changelog}
						HOLDERS.changelog.CanvasSize = HOLDERS.changelog.CanvasSize + UDim2.new(0, 0, 0, 30)
						Y_CHANGES = Y_CHANGES + 30
					end
				NEW'Frame'{Name = 'credits', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.8, BorderSizePixel = 0, Position = UDim2.new(0, 5, 0, 85), Size = UDim2.new(1, -10, 0, 210), Visible = false, Parent = HOLDERS}
					NEW'TextLabel'{Name = 'text', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 1, BorderSizePixel = 0, Size = UDim2.new(1, 0, 1, 0), Font = 'SourceSansBold', Text = CREDITS, TextColor3 = C3(0, 0, 0), TextSize = 24, TextTransparency = 0.25, TextXAlignment = 'Left', TextYAlignment = 'Top', Parent = HOLDERS.credits}
				NEW'TextBox'{Name = 'search', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.25, BorderSizePixel = 0, Position = UDim2.new(0.25, 0, 0, 85), Size = UDim2.new(0.5, 0, 0, 25), Visible = false, Font = 'SourceSansBold', Text = 'search commands', TextColor3 = C3(255, 255, 255), TextSize = 20, Parent = HOLDERS}
				
			NEW'Frame'{Name = 'line', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.25, BorderSizePixel = 0, Position = UDim2.new(0, 5, 0, 75), Size = UDim2.new(1, -10, 0, 5), Parent = MAIN_GUI.main.holder}
		NEW'TextButton'{Name = 'close', BackgroundColor3 = C3(255, 50, 50), BackgroundTransparency = 0.25, BorderSizePixel = 0, Position = UDim2.new(1, 0, 0, 0), Size = UDim2.new(0, 25, 0, 25), Text = '', Parent = MAIN_GUI.main}
		
	CMD_BAR_H = Instance.new('ScreenGui', GUIS)
        CMD_BAR_H.ResetOnSpawn = false
	CMD_BAR_H.Name = 'cmdbar_seth'
		NEW'TextBox'{Name = 'bar', BackgroundColor3 = C3(0, 0, 0), BackgroundTransparency = 0.5, BorderSizePixel = 0, Position = UDim2.new(0, -200, 1, -50), Size = UDim2.new(0, 225, 0, 25), Font = 'SourceSansItalic', Text = 'press ; to execute a command', TextColor3 = C3(255, 255, 255), TextSize = 20, Parent = CMD_BAR_H}
			NEW'ScrollingFrame'{Name = 'commands', BackgroundColor3 = C3(50, 50, 50), BackgroundTransparency = 0.5, BorderSizePixel = 0, Position = UDim2.new(0, 0, 1, -25), Size = UDim2.new(1, 0, 0, 0), Visible = false, CanvasSize = UDim2.new(0, 0, 0, 0), ScrollBarThickness = 6, ScrollingEnabled = true, BottomImage = SI, MidImage = SI, TopImage = SI, Parent = CMD_BAR_H.bar}
			NEW'TextLabel'{Name = 'commands_ex', BackgroundTransparency = 1, BorderSizePixel = 0, Size = UDim2.new(0, 200, 0, 20), Visible = false, Font = 'SourceSansBold', TextColor3 = C3(255, 255, 255), TextSize = 18, TextXAlignment = 'Left', Parent = CMD_BAR_H.bar}
			
	local NOTIFY_H = Instance.new('ScreenGui', GUIS)
        NOTIFY_H.ResetOnSpawn = false
	NOTIFY_H.Name = 'notify_seth'
		local N = Instance.new('Frame', NOTIFY_H)
		N.Name = 'notify'
		N.BackgroundColor3 = C3(0, 0, 0)
		N.BackgroundTransparency = 0.5
		N.BorderSizePixel = 0
		N.Position = UDim2.new(0, -225, 0.6, 0)
		N.Size = UDim2.new(0, 225, 0, 30)
			local BAR = Instance.new('Frame', N)
			BAR.Name = ''
			BAR.BackgroundColor3 = C3(255, 255, 255)
			BAR.BackgroundTransparency = 0.5
			BAR.BorderSizePixel = 0
			BAR.Position = UDim2.new(0, 0, 1, 0)
			BAR.Size = UDim2.new(1, 0, 0, 5)
			local TEXT = Instance.new('TextLabel', N)
			TEXT.Name = 'text'
			TEXT.BackgroundTransparency = 1
			TEXT.BorderSizePixel = 0
			TEXT.Size = UDim2.new(1, 0, 1, 0)
			TEXT.Font = 'SourceSansBold'
			TEXT.TextColor3 = C3(255, 255, 255)
			TEXT.TextSize = 18
			TEXT.TextXAlignment = 'Left'
			
	PAPER_MESH = Instance.new('BlockMesh', OTHER)
	PAPER_MESH.Scale = Vector3.new(1, 1, 0.1)
	
	JAIL = Instance.new('Model', OTHER)
	JAIL.Name = 'JAIL'
		local B = Instance.new('Part', JAIL)
		B.Name = 'BUTTOM'
		B.BrickColor = BrickColor.new('Black')
		B.Transparency = 0.5
		B.Anchored = true
		B.Locked = true
		B.Size = Vector3.new(6, 1, 6)
		B.TopSurface = 'Smooth'
		B.BottomSurface = 'Smooth'
		local M = Instance.new('Part', JAIL)
		M.Name = 'MAIN'
		M.BrickColor = BrickColor.new('Black')
		M.Transparency = 1
		M.Anchored = true
		M.CanCollide = false
		M.Locked = true
		M.Position = B.Position + Vector3.new(0, 3, 0)
		M.Size = Vector3.new(1, 1, 1)
		local P1 = Instance.new('Part', JAIL)
		P1.BrickColor = BrickColor.new('Black')
		P1.Transparency = 1
		P1.Position = B.Position + Vector3.new(0, 3.5, -2.5)
		P1.Rotation = Vector3.new(0, 90, 0)
		P1.Anchored = true
		P1.Locked = true
		P1.Size = Vector3.new(1, 6, 6)
		local P2 = Instance.new('Part', JAIL)
		P2.BrickColor = BrickColor.new('Black')
		P2.Transparency = 1
		P2.Position = B.Position + Vector3.new(-2.5, 3.5, 0)
		P2.Rotation = Vector3.new(-180, 0, -180)
		P2.Anchored = true
		P2.Locked = true
		P2.Size = Vector3.new(1, 6, 4)
		local P3 = Instance.new('Part', JAIL)
		P3.BrickColor = BrickColor.new('Black')
		P3.Transparency = 1
		P3.Position = B.Position + Vector3.new(2.5, 3.5, 0)
		P3.Rotation = Vector3.new(0, 0, 0)
		P3.Anchored = true
		P3.Locked = true
		P3.Size = Vector3.new(1, 6, 4)
		local P4 = Instance.new('Part', JAIL)
		P4.BrickColor = BrickColor.new('Black')
		P4.Transparency = 1
		P4.Position = B.Position + Vector3.new(0, 3.5, 2.5)
		P4.Rotation = Vector3.new(0, 90, 0)
		P4.Anchored = true
		P4.Locked = true
		P4.Size = Vector3.new(1, 6, 4)
		local TOP = Instance.new('Part', JAIL)
		TOP.BrickColor = BrickColor.new('Black')
		TOP.Transparency = 0.5
		TOP.Position = B.Position + Vector3.new(0, 7, 0)
		TOP.Rotation = Vector3.new(0, 0, 0)
		TOP.Anchored = true
		TOP.Locked = true
		TOP.Size = Vector3.new(6, 1, 6)
		TOP.TopSurface = 'Smooth'
		TOP.BottomSurface = 'Smooth'
		
	ROCKET = Instance.new('Part', OTHER)
	ROCKET.Name = 'rocket_seth'
	ROCKET.CanCollide = false
	ROCKET.Size = Vector3.new(2, 5, 2) 
		Instance.new('CylinderMesh', ROCKET)
		local F = Instance.new('Part', ROCKET)
		F.BrickColor = BrickColor.new('Black')
		F.CanCollide = false
		F.Size = Vector3.new(2, 0.2, 2)
			Instance.new('CylinderMesh', F)
			local PE = Instance.new('ParticleEmitter', F)
			PE.Color = ColorSequence.new(C3(236, 139, 70), C3(236, 139, 70))
			PE.Size = NumberSequence.new(0.2)
			PE.Texture = 'rbxassetid://17238048'
			PE.LockedToPart = true
			PE.Lifetime = NumberRange.new(0.2)
			PE.Rate = 50
			PE.Speed = NumberRange.new(-20)
		local TOP = Instance.new('Part', ROCKET)
		TOP.CanCollide = false
		TOP.Shape = 'Ball'
		TOP.Size = Vector3.new(2, 2, 2)
		TOP.TopSurface = 'Smooth'
		TOP.BottomSurface = 'Smooth'
		local BF = Instance.new('BodyForce', ROCKET)
		BF.Name = 'force'
		BF.Force = Vector3.new(0, 0, 0)
		local W1 = Instance.new('Weld', ROCKET)
		W1.Part0 = ROCKET
		W1.Part1 = F
		W1.C1 = CFrame.new(0, 2.6, 0)
		local W2 = Instance.new('Weld', ROCKET)
		W2.Part0 = ROCKET
		W2.Part1 = TOP
		W2.C1 = CFrame.new(0, -2.6, 0)
		
	ALIEN_H = Instance.new('Accessory', OTHER)
		local H = Instance.new('Part', ALIEN_H)
		H.Name = 'Handle'
		H.Size = Vector3.new(2, 2.4, 2)
			local HA = Instance.new('Attachment', H)
			HA.Name = 'HatAttachment'
			HA.Position = Vector3.new(0, 0.15, 0)
			local SM = Instance.new('SpecialMesh', H)
			SM.MeshId = 'rbxassetid://13827689'
			SM.MeshType = 'FileMesh'
			SM.Scale = Vector3.new(1, 1.02, 1)
			SM.TextureId = 'rbxassetid://13827796'
			
	local S = Instance.new('Model', OTHER) S.Name = 'swastika'
		NEW'Part'{BrickColor = BrickColor.new('Really red'), Material = 'Plastic', Anchored = true, CanCollide = false, Size = Vector3.new(2, 2, 2), BottomSurface = 'Smooth', TopSurface = 'Smooth', Parent = S}
		NEW'Part'{BrickColor = BrickColor.new('Really red'), Material = 'Plastic', Position = Vector3.new(0, 3, 0), Anchored = true, CanCollide = false, Size = Vector3.new(2, 4, 2), BottomSurface = 'Smooth', TopSurface = 'Smooth', Parent = S}
		NEW'Part'{BrickColor = BrickColor.new('Really red'), Material = 'Plastic', Position = Vector3.new(3, 0, 0), Anchored = true, CanCollide = false, Size = Vector3.new(4, 2, 2), BottomSurface = 'Smooth', TopSurface = 'Smooth', Parent = S}
		NEW'Part'{BrickColor = BrickColor.new('Really red'), Material = 'Plastic', Position = Vector3.new(0, -3, 0), Anchored = true, CanCollide = false, Size = Vector3.new(2, 4, 2), BottomSurface = 'Smooth', TopSurface = 'Smooth', Parent = S}
		NEW'Part'{BrickColor = BrickColor.new('Really red'), Material = 'Plastic', Position = Vector3.new(-3, 0, 0), Anchored = true, CanCollide = false, Size = Vector3.new(4, 2, 2), BottomSurface = 'Smooth', TopSurface = 'Smooth', Parent = S}
		NEW'Part'{BrickColor = BrickColor.new('Really red'), Material = 'Plastic', Position = Vector3.new(3, 4, 0), Anchored = true, CanCollide = false, Size = Vector3.new(4, 2, 2), BottomSurface = 'Smooth', TopSurface = 'Smooth', Parent = S}
		NEW'Part'{BrickColor = BrickColor.new('Really red'), Material = 'Plastic', Position = Vector3.new(4, -3, 0), Anchored = true, CanCollide = false, Size = Vector3.new(2, 4, 2), BottomSurface = 'Smooth', TopSurface = 'Smooth', Parent = S}
		NEW'Part'{BrickColor = BrickColor.new('Really red'), Material = 'Plastic', Position = Vector3.new(-3, -4, 0), Anchored = true, CanCollide = false, Size = Vector3.new(4, 2, 2), BottomSurface = 'Smooth', TopSurface = 'Smooth', Parent = S}
		NEW'Part'{BrickColor = BrickColor.new('Really red'), Material = 'Plastic', Position = Vector3.new(-4, 3, 0), Anchored = true, CanCollide = false, Size = Vector3.new(2, 4, 2), BottomSurface = 'Smooth', TopSurface = 'Smooth', Parent = S}
	
	CMD_BAR_H.Parent = _CORE
end

local RS = game:GetService('RunService').RenderStepped

function OPEN_MAIN()
	SETH_MAIN = MAIN_GUI:Clone()
	
	local BUTTONS = SETH_MAIN.main.holder.buttons
	local HOLDERS = SETH_MAIN.main.holder.holders
	
	for i,v in pairs(SETH_MAIN.main.holder.buttons:GetChildren()) do
		v.MouseButton1Down:connect(function(X, Y)
			OPEN_TAB(v.Name)
			if not v:FindFirstChild('circle') then
				local C = Instance.new('ImageLabel', v)
				C.BackgroundTransparency = 1
				C.Position = UDim2.new(0, X - 0, 0, Y - 35) - UDim2.new(0, v.AbsolutePosition.X, 0, v.AbsolutePosition.Y)
				C.Size = UDim2.new(0, 0, 0, 0)
				C.ZIndex = v.ZIndex
				C.Image = 'rbxassetid://200182847'
				C.ImageColor3 = C3(0, 100, 255)
				C.Name = 'circle'
				C:TweenSizeAndPosition(UDim2.new(0, 500, 0, 500), C.Position - UDim2.new(0, 250, 0, 250), 'Out', 'Quart', 2.5)
				for i = 0, 1, 0.03 do
					C.ImageTransparency = i
					RS:wait()
				end
				C:destroy()
			end
		end)
	end
	
	HOLDERS.server.place_id.Text = ' Place ID | ' .. game.PlaceId
	game:GetService('RunService').Stepped:connect(function()
		if SETH_MAIN:FindFirstChild('main') and HOLDERS:FindFirstChild('server') then
			if not workspace.FilteringEnabled then
				HOLDERS.server.fe.Text = ' FilteringEnabled | false'
			else
				HOLDERS.server.fe.Text = ' FilteringEnabled | true'
			end
			HOLDERS.server.players.Text = ' Players | ' .. _PLAYERS.NumPlayers .. '/' .. _PLAYERS.MaxPlayers
			HOLDERS.server.time.Text = ' Time | ' .. _LIGHTING.TimeOfDay
			HOLDERS.server.gravity.Text = ' Gravity | ' .. workspace.Gravity
		end
	end)
	
	function UPDATE_ADMINS()
		HOLDERS.admins:ClearAllChildren()
		HOLDERS.admins.CanvasSize = UDim2.new(0, 0, 0, 0)
		local Y_ADMINS = 5
		for i,v in pairs(ADMINS) do
			NEW'TextLabel'{Name = v, BackgroundColor3 = C3(255, 255, 255), BackgroundTransparency = 1, Position = UDim2.new(0, 0, 0, Y_ADMINS), Size = UDim2.new(1, -30, 0, 25), Font = 'SourceSansBold', TextColor3 = C3(0, 0, 0), TextSize = 24, TextTransparency = 0.25, TextXAlignment = 'Left', Parent = HOLDERS.admins}
			NEW'TextButton'{Name = 'update', BackgroundColor3 = C3(255, 50, 50), BackgroundTransparency = 0.25, BorderSizePixel = 0, Position = UDim2.new(1, 0, 0, 0), Size = UDim2.new(0, 25, 0, 25), Text = '', Parent = HOLDERS.admins[v]}
			HOLDERS.admins[v].update.MouseButton1Down:connect(function()
				table.remove(ADMINS, i)
				UPDATE_ADMINS()
			end)
			HOLDERS.admins.CanvasSize = HOLDERS.admins.CanvasSize + UDim2.new(0, 0, 0, 30)
			Y_ADMINS = Y_ADMINS + 30
		end
		HOLDERS.admins.CanvasSize = HOLDERS.admins.CanvasSize + UDim2.new(0, 0, 0, 5)
		spawn(function()
			for i,v in pairs(HOLDERS.admins:GetChildren()) do
				v.Text = ' ' .. _PLAYERS:GetNameFromUserIdAsync(v.Name)
			end
		end)
	end
	UPDATE_ADMINS()
	
	function UPDATE_BANS()
		HOLDERS.bans:ClearAllChildren()
		HOLDERS.bans.CanvasSize = UDim2.new(0, 0, 0, 0)
		local Y_BANS = 5
		for i,v in pairs(BANS) do
			NEW'TextLabel'{Name = v, BackgroundColor3 = C3(255, 255, 255), BackgroundTransparency = 1, Position = UDim2.new(0, 0, 0, Y_BANS), Size = UDim2.new(1, -30, 0, 25), Font = 'SourceSansBold', Text = '', TextColor3 = C3(0, 0, 0), TextSize = 24, TextTransparency = 0.25, TextXAlignment = 'Left', Parent = HOLDERS.bans}
			NEW'TextButton'{Name = 'update', BackgroundColor3 = C3(255, 50, 50), BackgroundTransparency = 0.25, BorderSizePixel = 0, Position = UDim2.new(1, 0, 0, 0), Size = UDim2.new(0, 25, 0, 25), Text = '', Parent = HOLDERS.bans[v]}
			HOLDERS.bans[v].update.MouseButton1Down:connect(function()
				table.remove(BANS, i)
				UPDATE_BANS()
			end)
			HOLDERS.bans.CanvasSize = HOLDERS.bans.CanvasSize + UDim2.new(0, 0, 0, 30)
			Y_BANS = Y_BANS + 30
		end
		HOLDERS.bans.CanvasSize = HOLDERS.bans.CanvasSize + UDim2.new(0, 0, 0, 5)
		spawn(function()
			for i,v in pairs(HOLDERS.bans:GetChildren()) do
				v.Text = ' ' .. _PLAYERS:GetNameFromUserIdAsync(v.Name)
			end
		end)
	end
	UPDATE_BANS()
	
	local function DISPLAY_CMDS()
		local Y_COMMANDS = 0
		for i,v in pairs(COMMANDS) do
			NEW'TextLabel'{Name = '', BackgroundColor3 = C3(255, 255, 255), BackgroundTransparency = 1, Position = UDim2.new(0, 0, 0, Y_COMMANDS), Size = UDim2.new(1, 0, 0, 25), Font = 'SourceSansBold', Text = ' ' .. v.D, TextColor3 = C3(0, 0, 0), TextSize = 24, TextTransparency = 0.25, TextXAlignment = 'Left', Parent = HOLDERS.cmds}
			HOLDERS.cmds.CanvasSize = HOLDERS.cmds.CanvasSize + UDim2.new(0, 0, 0, 25)
			Y_COMMANDS = Y_COMMANDS + 25
		end
	end
	DISPLAY_CMDS()
	
	HOLDERS.search.Changed:connect(function()
		if SETH_MAIN:FindFirstChild('main') and SETH_MAIN.main.holder.holders:FindFirstChild('search') then
		if HOLDERS.search.Text ~= 'search commands' and HOLDERS.search.Focused then
			if HOLDERS.search.Text ~= '' then
				if not HOLDERS.search.Text:find(' ') then
					HOLDERS.cmds:ClearAllChildren()
					HOLDERS.cmds.CanvasSize = UDim2.new(0, 0, 0, 0)
					local Y_COMMANDS = 0
					for i,v in pairs(COMMANDS) do
						if v.N:find(HOLDERS.search.Text) then
							HOLDERS.cmds.CanvasSize = HOLDERS.cmds.CanvasSize + UDim2.new(0, 0, 0, 25)
							NEW'TextLabel'{Name = '', BackgroundColor3 = C3(255, 255, 255), BackgroundTransparency = 1, Position = UDim2.new(0, 0, 0, Y_COMMANDS), Size = UDim2.new(1, 0, 0, 25), Font = 'SourceSansBold', Text = ' ' .. v.D, TextColor3 = C3(0, 0, 0), TextSize = 24, TextTransparency = 0.25, TextXAlignment = 'Left', Parent = HOLDERS.cmds}
							HOLDERS.changelog.CanvasSize = HOLDERS.changelog.CanvasSize + UDim2.new(0, 0, 0, 25)
							Y_COMMANDS = Y_COMMANDS + 25
						end
					end
				end
			else
				HOLDERS.cmds:ClearAllChildren()
				HOLDERS.cmds.CanvasSize = UDim2.new(0, 0, 0, 0)
				DISPLAY_CMDS()
			end
		end
		end
	end)
	
	local FUN = {'balefire', 'swastika', 'trowel', 'path giver', 'orbital strike'}
	local Y_FUN = 5
	for i,v in pairs(FUN) do
		NEW'TextLabel'{Name = v, BackgroundColor3 = C3(255, 255, 255), BackgroundTransparency = 1, Position = UDim2.new(0, 0, 0, Y_FUN), Size = UDim2.new(1, -50, 0, 25), Font = 'SourceSansBold', Text = ' ' .. v, TextColor3 = C3(0, 0, 0), TextSize = 24, TextTransparency = 0.25, TextXAlignment = 'Left', Parent = HOLDERS.fun}
		HOLDERS.fun.CanvasSize = HOLDERS.fun.CanvasSize + UDim2.new(0, 0, 0, 30)
		Y_FUN = Y_FUN + 30
	end
	HOLDERS.fun.CanvasSize = HOLDERS.fun.CanvasSize + UDim2.new(0, 0, 0, 5)
	for i,v in pairs(HOLDERS.fun:GetChildren()) do
		NEW'TextButton'{Name = 'load', BackgroundColor3 = C3(50, 50, 255), BackgroundTransparency = 0.25, BorderSizePixel = 0, Position = UDim2.new(1, 0, 0, 0), Size = UDim2.new(0, 45, 0, 25), ClipsDescendants = true, Font = 'SourceSansBold', Text = 'load', TextColor3 = C3(255, 255, 255), TextSize = 20, Parent = v}
		v.load.MouseButton1Down:connect(function()
			if v.Name == 'balefire' then LOAD_BALEFIRE()
			elseif v.Name == 'swastika' then local S = OTHER.swastika:Clone() S.Parent = workspace S:MoveTo(LP.Character.Head.Position + Vector3.new(0, 10, 0))
			elseif v.Name == 'trowel' then LOAD_TROWEL()
			elseif v.Name == 'path giver' then LOAD_PATH()
			elseif v.Name == 'orbital strike' then LOAD_STRIKE()
			end
		end)
	end
	
	SETH_MAIN.main.close.MouseButton1Down:connect(function()
		SETH_MAIN:destroy()
	end)
	
	SETH_MAIN.Parent = _CORE
end

LOAD_DATA()

--/ TOOLS

function LOAD_BALEFIRE()
	local HB = Instance.new('HopperBin', LP.Backpack)
	HB.Name = 'balefire'
	
	local function BF(P)
		for i = 1, 50 do
			local E = Instance.new('Explosion', workspace)
			E.BlastRadius = 3
			E.BlastPressure = 999999
			E.Position = LP.Character.Torso.CFrame.p + ((P - LP.Character.Torso.CFrame.p).unit * 6 * i) + ((P - LP.Character.Torso.CFrame.p).unit * 7)
		end
	end
	
	FIRED = false
	local function FIRE(M)
		if not FIRED then
			FIRED = true
			BF(M.Hit.p)
			wait(0.25)
			FIRED = false
		end
	end
	
	HB.Selected:connect(function(M)
		M.Button1Down:connect(function()
			FIRE(M)
		end)
	end)
end

function LOAD_TROWEL()
	local T = Instance.new('Tool', LP.Backpack) T.Name = 'trowel'
	NEW'Part'{Name = 'Handle', Size = Vector3.new(1, 4.4, 1), Parent = T}
	NEW'SpecialMesh'{MeshId = 'rbxasset://fonts/trowel.mesh', MeshType = 'FileMesh', TextureId = 'rbxasset://textures/TrowelTexture.png', Parent = T.Handle}
	NEW'Sound'{Name = 'build', SoundId = 'rbxasset://sounds//bass.wav', Volume = 1, Parent = T.Handle}
	
	local HEIGHT = 5
	local SPEED = 0.05
	local WIDTH = 15
	
	function BRICK(CF, P, C)
		local B = Instance.new('Part')
		B.BrickColor = C
		B.CFrame = CF * CFrame.new(P + B.Size / 2)
		B.Parent = game.Workspace
		B:MakeJoints()
		B.Material = 'Neon'
		return  B, P + B.Size
	end
	
	function BW(CF)
		local BC = BrickColor.Random()
		local B = {}
		assert(WIDTH > 0)
		local Y = 0
		while Y < HEIGHT do
			local P
			local X = -WIDTH / 2
			while X < WIDTH / 2 do
				local brick
				brick, P = BRICK(CF, Vector3.new(X, Y, 0), BC)
				X = P.x
				table.insert(B, brick)
				wait(SPEED)
			end
			Y = P.y
		end
		return B
	end
	
	function S(A)
		if math.abs(A.x) > math.abs(A.z) then
			if A.x > 0 then
				return Vector3.new(1, 0, 0)
			else
				return Vector3.new(-1, 0, 0)
			end
		else
			if A.z > 0 then
				return Vector3.new(0, 0, 1)
			else
				return Vector3.new(0, 0, -1)
			end
		end
	end
	
	T.Enabled = true
	T.Activated:connect(function()
		if T.Enabled and LP.Character:FindFirstChild('Humanoid') then
			T.Enabled = false
			T.Handle.build:Play()
			BW(CFrame.new(LP.Character.Humanoid.TargetPoint, LP.Character.Humanoid.TargetPoint + S((LP.Character.Humanoid.TargetPoint - LP.Character.Head.Position).unit)))
			T.Enabled = true
		end
	end)
end

function LOAD_PATH()
	local HB = Instance.new('HopperBin', LP.Backpack) HB.Name = 'path giver'
	
	local function PATH(M, C)
		if ENABLED and LP.Character then
			if not workspace:FindFirstChild('paths_seth') then Instance.new('Folder', workspace).Name = 'paths_seth' end
			local hit = M.Target
			local point = M.Hit.p
			local P = Instance.new('Part', workspace.paths_seth)
			P.BrickColor = C
			P.Material = 'Neon'
			P.Transparency = 0.75
			P.Anchored = true
			P.Size = Vector3.new(20, 1, 20)
			P.Velocity = M.Hit.lookVector * 75
			P.BottomSurface = 'Smooth'
			P.TopSurface = 'Smooth'
			P.CFrame = CFrame.new(LP.Character.Head.Position)
			P.CFrame = CFrame.new(LP.Character.Torso.Position.x, LP.Character.Torso.Position.y - 4, LP.Character.Torso.Position.z)
			P.CFrame = CFrame.new(P.Position, point)
			wait()
			PATH(M, C)
		end
	end
	
	local function SELECTED(M)
		M.Button1Down:connect(function() ENABLED = true PATH(M, BrickColor.Random()) end)
		M.Button1Up:connect(function() ENABLED = false end)
		M.KeyDown:connect(function(K) if K == 'r' then if workspace:FindFirstChild('paths_seth') then workspace.paths_seth:destroy() end end end)
	end
	
	HB.Selected:connect(SELECTED)
end

function LOAD_STRIKE()
	local HB = Instance.new('HopperBin', LP.Backpack) HB.Name = 'orbital strike'
	
	local function SHOOT(T)
		if ENABLED then
			local P0 = CFrame.new(0, 1500, 0)
			P0 = P0 + ((P0 * CFrame.fromEulerAnglesXYZ(math.pi / 2, 0, 0)).lookVector * 0.5) + (P0 * CFrame.fromEulerAnglesXYZ(0, math.pi / 2, 0)).lookVector
			local P1 = P0 + ((P0.p - T.Hit.p).unit * -2)
			SATELITE.CFrame = CFrame.new((P0.p + P1.p) / 2, P0.p) * CFrame.fromEulerAnglesXYZ(-math.pi / 2, 0, 0)
			
			local M = Instance.new('Model', workspace)
			NEW'Part'{BrickColor = BrickColor.new('Pink'), Material = 'Neon', CFrame = CFrame.new((SATELITE.CFrame.p + T.Hit.p) / 2, SATELITE.CFrame.p), Anchored = true, CanCollide = false, Size = Vector3.new(1, 1, 1), Parent = M}
			NEW'BlockMesh'{Scale = Vector3.new(1, 1, (SATELITE.CFrame.p - T.Hit.p).magnitude), Parent = M.Part}
			NEW'Explosion'{Position = T.Hit.p, BlastRadius = 20, Parent = workspace}
			
			for i = 1,10 do M.Part.Transparency = 0.5 + (i * 0.05) wait(0.05) end
			M:destroy()
		end
	end
	
	HB.Selected:connect(function(M)
		if not workspace:FindFirstChild('orbital_seth') then
			SATELITE = Instance.new('Part', workspace)
			SATELITE.Name = 'orbital_seth'
			SATELITE.Position = Vector3.new(0, 1500, 0)
			SATELITE.Anchored = true
			SATELITE.CanCollide = false
			SATELITE.Size = Vector3.new(5, 16.8, 5)
			NEW'SpecialMesh'{MeshId = 'rbxassetid://1064328', Scale = Vector3.new(0.2, 0.2, 0.2), Parent = SATELITE}
		end
		M.Button1Down:connect(function() ENABLED = true SHOOT(M) end)
		M.Button1Up:connect(function() ENABLED = false end)
	end)
end

function FIND_IN_TABLE(TABLE, NAME)
	for i,v in pairs(TABLE) do
		if v == NAME then
			return true
		end
	end
	return false
end

function GET_IN_TABLE(TABLE, NAME)
	for i = 1, #TABLE do
		if TABLE[i] == NAME then
			return i
		end
	end
	return false
end

local NOTIFY_1 = false
local NOTIFY_2 = false

function NOTIFY(M, R, G, B)
	spawn(function()
		repeat wait() until not NOTIFY_1
		local NOTIFY_SETH = GUIS.notify_seth:Clone() NOTIFY_SETH.Parent = _CORE
		if NOTIFY_SETH then
			NOTIFY_SETH.notify[''].BackgroundColor3 = C3(R, G, B)
			NOTIFY_SETH.notify.text.Text = ' ' .. M
			repeat wait() until not NOTIFY_1
			NOTIFY_1 = true
			wait(0.5)
			NOTIFY_SETH.notify:TweenPosition(UDim2.new(0, 0, 0.6, 0), 'InOut', 'Quad', 0.4, false) wait(0.5)
			wait(0.5)
			repeat wait() until not NOTIFY_2
			NOTIFY_1 = false
			NOTIFY_SETH.notify:TweenPosition(UDim2.new(0, 0, 0.6, -40), 'InOut', 'Quad', 0.4, false) wait(0.5)
			wait(0.5)
			NOTIFY_2 = true
			wait(2.5)
			NOTIFY_SETH.notify:TweenPosition(UDim2.new(0, -225, 0.6, -40), 'InOut', 'Quad', 0.4, false) wait(0.5)
		end
		wait(1)
		NOTIFY_SETH:destroy()
		NOTIFY_2 = false
	end)
end

function KICK(P)
	spawn(function()
		for i = 1,5 do
			if P.Character and P.Character:FindFirstChild('HumanoidRootPart') and P.Character:FindFirstChild('Torso') then
				P.Character.HumanoidRootPart.CFrame = CFrame.new(math.random(999000, 1001000), 1000000, 1000000)
				local SP = Instance.new('SkateboardPlatform', P.Character) SP.Position = P.Character.HumanoidRootPart.Position SP.Transparency = 1
				spawn(function()
					repeat wait()
						if P.Character and P.Character:FindFirstChild('HumanoidRootPart') then SP.Position = P.Character.HumanoidRootPart.Position end
					until not _PLAYERS:FindFirstChild(P.Name)
				end)
				P.Character.Torso.Anchored = true
			end
		end
	end)
end

_PLAYERS.PlayerRemoving:connect(function(P)
	if FIND_IN_TABLE(KICKS, P) then
		for i,v in pairs(KICKS) do if v == P then table.remove(KICKS, i) end end
		NOTIFY('KICKED ' .. P.Name, 255, 255, 255)
	end
	if FIND_IN_TABLE(JAILED, P.Name) then
		for i,v in pairs(JAILED) do if v == P.Name then table.remove(KICKS, i) end end
	end
end)

function FIX_LIGHTING()
	_LIGHTING.Ambient = C3(0.5, 0.5, 0.5)
	_LIGHTING.Brightness = 1
	_LIGHTING.GlobalShadows = true
	_LIGHTING.Outlines = false
	_LIGHTING.TimeOfDay = 14
	_LIGHTING.FogEnd = 100000
end

function COLOR(PLAYER, BCOLOR)
	for i,v in pairs(PLAYER.Character:GetChildren()) do if v:IsA('Shirt') or v:IsA('Pants') then v:destroy() elseif v:IsA('ShirtGraphic') then v.Archivable = false v.Graphic = '' end end
	for i,v in pairs(PLAYER.Character.Head:GetChildren()) do if v:IsA('Decal') then v:destroy() end end
	for i,v in pairs(PLAYER.Character:GetChildren()) do
		if v:IsA('Part') and v.Name ~= 'HumanoidRootPart' then
			v.BrickColor = BrickColor.new(BCOLOR)
		elseif v:IsA('Accessory') then
			v.Handle.BrickColor = BrickColor.new(BCOLOR)
			for a,b in pairs(v.Handle:GetChildren()) do
				if b:IsA('SpecialMesh') then
					b.TextureId = ''
				end
			end
		end
	end
end

function LAG(PLAYER)
	local POS = CFrame.new(math.random(-100000, 100000), math.random(-100000, 100000), math.random(-100000, 100000))
	spawn(function()
		repeat wait()
			if PLAYER and PLAYER.Character then
				PLAYER.CameraMode = 'LockFirstPerson'
				PLAYER.Character.HumanoidRootPart.CFrame = POS
				PLAYER.Character.Torso.Anchored = true
				Instance.new('ForceField', PLAYER.Character)
				Instance.new('Smoke', PLAYER.Character.Head)
			end
		until not _PLAYERS:FindFirstChild(PLAYER.Name)
	end)
end

local FLYING = false

if LP.Character and LP.Character:FindFirstChild('Humanoid') then
	LP.Character.Humanoid.Died:connect(function() FLYING = false end)
end

function sFLY()
	repeat wait() until LP and LP.Character and LP.Character:FindFirstChild('Torso') and LP.Character:FindFirstChild('Humanoid')
	repeat wait() until MOUSE
	
	local T = LP.Character.Torso
	local CONTROL = {F = 0, B = 0, L = 0, R = 0}
	local lCONTROL = {F = 0, B = 0, L = 0, R = 0}
	local SPEED = 0
	
	local function FLY()
		FLYING = true
		local BG = Instance.new('BodyGyro', T)
		local BV = Instance.new('BodyVelocity', T)
		BG.P = 9e4
		BG.maxTorque = Vector3.new(9e9, 9e9, 9e9)
		BG.cframe = T.CFrame
		BV.velocity = Vector3.new(0, 0.1, 0)
		BV.maxForce = Vector3.new(9e9, 9e9, 9e9)
		spawn(function()
			repeat wait()
				LP.Character.Humanoid.PlatformStand = true
				if CONTROL.L + CONTROL.R ~= 0 or CONTROL.F + CONTROL.B ~= 0 then
					SPEED = 50
				elseif not (CONTROL.L + CONTROL.R ~= 0 or CONTROL.F + CONTROL.B ~= 0) and SPEED ~= 0 then
					SPEED = 0
				end
				if (CONTROL.L + CONTROL.R) ~= 0 or (CONTROL.F + CONTROL.B) ~= 0 then
					BV.velocity = ((workspace.CurrentCamera.CoordinateFrame.lookVector * (CONTROL.F + CONTROL.B)) + ((workspace.CurrentCamera.CoordinateFrame * CFrame.new(CONTROL.L + CONTROL.R, (CONTROL.F + CONTROL.B) * 0.2, 0).p) - workspace.CurrentCamera.CoordinateFrame.p)) * SPEED
					lCONTROL = {F = CONTROL.F, B = CONTROL.B, L = CONTROL.L, R = CONTROL.R}
				elseif (CONTROL.L + CONTROL.R) == 0 and (CONTROL.F + CONTROL.B) == 0 and SPEED ~= 0 then
					BV.velocity = ((workspace.CurrentCamera.CoordinateFrame.lookVector * (lCONTROL.F + lCONTROL.B)) + ((workspace.CurrentCamera.CoordinateFrame * CFrame.new(lCONTROL.L + lCONTROL.R, (lCONTROL.F + lCONTROL.B) * 0.2, 0).p) - workspace.CurrentCamera.CoordinateFrame.p)) * SPEED
				else
					BV.velocity = Vector3.new(0, 0.1, 0)
				end
				BG.cframe = workspace.CurrentCamera.CoordinateFrame
			until not FLYING
			CONTROL = {F = 0, B = 0, L = 0, R = 0}
			lCONTROL = {F = 0, B = 0, L = 0, R = 0}
			SPEED = 0
			BG:destroy()
			BV:destroy()
			LP.Character.Humanoid.PlatformStand = false
		end)
	end
	
	MOUSE.KeyDown:connect(function(KEY)
		if KEY:lower() == 'w' then
			CONTROL.F = 1
		elseif KEY:lower() == 's' then
			CONTROL.B = -1
		elseif KEY:lower() == 'a' then
			CONTROL.L = -1 
		elseif KEY:lower() == 'd' then 
			CONTROL.R = 1
		end
	end)
	
	MOUSE.KeyUp:connect(function(KEY)
		if KEY:lower() == 'w' then
			CONTROL.F = 0
		elseif KEY:lower() == 's' then
			CONTROL.B = 0
		elseif KEY:lower() == 'a' then
			CONTROL.L = 0
		elseif KEY:lower() == 'd' then
			CONTROL.R = 0
		end
	end)
	FLY()
end

function NOFLY()
	FLYING = false
	LP.Character.Humanoid.PlatformStand = false
end

function RESET_MODEL(MODEL)
	for i,v in pairs(MODEL:GetChildren()) do
		if v:IsA('Seat') and v.Name == 'FakeTorso' then
			v:destroy()
		elseif v:IsA('CharacterMesh') or v:IsA('Shirt') or v:IsA('Pants') or v:IsA('Accessory') then
			v:destroy()
		elseif v:IsA('Part') and v.Name ~= 'HumanoidRootPart' then
			v.Transparency = 0
		elseif v:IsA('ShirtGraphic') then
			v.Archivable = false
			v.Graphic = ''
		end
	end
	for i,v in pairs(MODEL.Torso:GetChildren()) do
		if v:IsA('SpecialMesh') then
			v:destroy()
		end
	end
	if MODEL.Head:FindFirstChild('Mesh') then
		MODEL.Head.Mesh:destroy()
	end
	if MODEL.Torso:FindFirstChild('Neck') then MODEL.Torso.Neck.C0 = CFrame.new(0, 1, 0) * CFrame.Angles(math.rad(90), math.rad(180), 0) end
	if MODEL.Torso:FindFirstChild('Left Shoulder') then MODEL.Torso['Left Shoulder'].C0 = CFrame.new(-1, 0.5, 0) * CFrame.Angles(0, math.rad(-90), 0) end
	if MODEL.Torso:FindFirstChild('Right Shoulder') then MODEL.Torso['Right Shoulder'].C0 = CFrame.new(1, 0.5, 0) * CFrame.Angles(0, math.rad(90), 0) end
	if MODEL.Torso:FindFirstChild('Left Hip') then MODEL.Torso['Left Hip'].C0 = CFrame.new(-1, -1, 0) * CFrame.Angles(0, math.rad(-90), 0) end
	if MODEL.Torso:FindFirstChild('Right Hip') then MODEL.Torso['Right Hip'].C0 = CFrame.new(1, -1, 0) * CFrame.Angles(0, math.rad(90), 0) end
end

function UPDATE_MODEL(MODEL, USERNAME)
	local AppModel = _PLAYERS:GetCharacterAppearanceAsync(_PLAYERS:GetUserIdFromNameAsync(USERNAME))
	MODEL.Name = USERNAME
	for i,v in pairs(AppModel:GetChildren()) do
		if v:IsA('SpecialMesh') or v:IsA('BlockMesh') or v:IsA('CylinderMesh') then
			v.Parent = MODEL.Head
		elseif v:IsA('Decal') then
			if MODEL.Head:FindFirstChild('face') then
				MODEL.Head.face.Texture = v.Texture
			else
				local FACE = Instance.new('Decal', MODEL.Head)
				FACE.Texture = v.Texture
			end
		elseif v:IsA('BodyColors') or v:IsA('CharacterMesh') or v:IsA('Shirt') or v:IsA('Pants') or v:IsA('ShirtGraphic') then
			if MODEL:FindFirstChild('Body Colors') then
				MODEL['Body Colors']:destroy()
			end
			v.Parent = MODEL
		elseif v:IsA('Accessory') then
			v.Parent = MODEL
			v.Handle.CFrame = MODEL.Head.CFrame * CFrame.new(0, MODEL.Head.Size.Y / 2, 0) * v.AttachmentPoint:inverse()
		end
	end
	if not MODEL.Head:FindFirstChild('Mesh') then
		local SM = Instance.new('SpecialMesh', MODEL.Head)
		SM.MeshType = Enum.MeshType.Head
		SM.Scale = Vector3.new(1.25, 1.25, 1.25)
	end
end

function CREEPER(PLAYER)
	for i,v in pairs(PLAYER.Character:GetChildren()) do
		if v:IsA('Shirt') or v:IsA('Pants') then
			v:destroy()
		elseif v:IsA('ShirtGraphic') then
			v.Archivable = false
			v.Graphic = ''
		end
	end
	for i,v in pairs(PLAYER.Character:GetChildren()) do
		if v:IsA('Accessory') then
			v:destroy()
		end
	end
	PLAYER.Character.Torso.Neck.C0 = CFrame.new(0,1,0) * CFrame.Angles(math.rad(90),math.rad(180),0)
	PLAYER.Character.Torso['Right Shoulder'].C0 = CFrame.new(0,-1.5,-.5) * CFrame.Angles(0,math.rad(90),0)
	PLAYER.Character.Torso['Left Shoulder'].C0 = CFrame.new(0,-1.5,-.5) * CFrame.Angles(0,math.rad(-90),0)
	PLAYER.Character.Torso['Right Hip'].C0 = CFrame.new(0,-1,.5) * CFrame.Angles(0,math.rad(90),0)
	PLAYER.Character.Torso['Left Hip'].C0 = CFrame.new(0,-1,.5) * CFrame.Angles(0,math.rad(-90),0)
	for i,v in pairs(PLAYER.Character:GetChildren()) do
		if v:IsA('Part') and v.Name ~= 'HumanoidRootPart' then
			v.BrickColor = BrickColor.new('Bright green')
		end
	end
end

function SHREK(PLAYER)
	COLOR(PLAYER, 'Bright green')
	for i,v in pairs(PLAYER.Character:GetChildren()) do
		if v:IsA('Shirt') or v:IsA('Pants') or v:IsA('Accessory') or v:IsA('CharacterMesh') then
			v:destroy()
		elseif v:IsA('ShirtGraphic') then
			v.Archivable = false
			v.Graphic = ''
		end
	end
	for i,v in pairs(PLAYER.Character.Head:GetChildren()) do
		if v:IsA('Decal') or v:IsA('SpecialMesh') then
			v:destroy()
		end
	end
	if PLAYER.Character:FindFirstChild('Shirt Graphic') then
		PLAYER.Character['Shirt Graphic'].Archivable = false
		PLAYER.Character['Shirt Graphic'].Graphic = ''
	end
	local M = Instance.new('SpecialMesh', PLAYER.Character.Head)
	local S = Instance.new('Shirt', PLAYER.Character)
	local P = Instance.new('Pants', PLAYER.Character)
	M.MeshType = 'FileMesh'
	M.MeshId = 'rbxassetid://19999257'
	M.Offset = Vector3.new(-0.1, 0.1, 0)
	M.TextureId = 'rbxassetid://156397869'
	S.ShirtTemplate = 'rbxassetid://133078194'
	P.PantsTemplate = 'rbxassetid://133078204'
end

function DUCK(PLAYER)
	for i,v in pairs(PLAYER.Character:GetChildren()) do
		if v:IsA('Part') and v.Name ~= 'Torso' and v.Name ~= 'HumanoidRootPart' then
			v.Transparency = 1
		elseif v:IsA('Shirt') or v:IsA('Pants') or v:IsA('Accessory') then
			v:destroy()
		elseif v:IsA('ShirtGraphic') then
			v.Archivable = false
			v.Graphic = ''
		end
	end
	local DUCK = Instance.new('SpecialMesh', PLAYER.Character.Torso)
	DUCK.MeshType = 'FileMesh'
	DUCK.MeshId = 'rbxassetid://9419831'
	DUCK.TextureId = 'rbxassetid://9419827'
	DUCK.Scale = Vector3.new(5, 5, 5)
	if PLAYER.Character.Head:FindFirstChild('face') then
		PLAYER.Character.Head.face.Transparency = 1
	end
end

function DOG(PLAYER)
	for i,v in pairs(PLAYER.Character:GetChildren()) do
		if v:IsA('Shirt') or v:IsA('Pants') then
			v:destroy()
		elseif v:IsA('ShirtGraphic') then
			v.Archivable = false
			v.Graphic = ''
		end
	end
	PLAYER.Character.Torso.Transparency = 1
	PLAYER.Character.Torso.Neck.C0 = CFrame.new(0, -0.5, -2) * CFrame.Angles(math.rad(90), math.rad(180), 0)
	PLAYER.Character.Torso['Right Shoulder'].C0 = CFrame.new(0.5, -1.5, -1.5) * CFrame.Angles(0, math.rad(90), 0)
	PLAYER.Character.Torso['Left Shoulder'].C0 = CFrame.new(-0.5, -1.5, -1.5) * CFrame.Angles(0, math.rad(-90), 0)
	PLAYER.Character.Torso['Right Hip'].C0 = CFrame.new(1.5, -1, 1.5) * CFrame.Angles(0, math.rad(90), 0)
	PLAYER.Character.Torso['Left Hip'].C0 = CFrame.new(-1.5, -1, 1.5) * CFrame.Angles(0, math.rad(-90), 0)
	local FakeTorso = Instance.new('Seat', PLAYER.Character)
	local BF = Instance.new('BodyForce', FakeTorso)
	local W = Instance.new('Weld', PLAYER.Character.Torso)
	FakeTorso.Name = 'FakeTorso'
	FakeTorso.TopSurface = 0
	FakeTorso.BottomSurface = 0
	FakeTorso.Size = Vector3.new(3,1,4)
	FakeTorso.BrickColor = BrickColor.new('Brown')
	FakeTorso.CFrame = PLAYER.Character.Torso.CFrame
	BF.Force = Vector3.new(0, FakeTorso:GetMass() * 196.25, 0)
	W.Part0 = PLAYER.Character.Torso
	W.Part1 = FakeTorso
	W.C0 = CFrame.new(0, -0.5, 0)
	for i,v in pairs(PLAYER.Character:GetChildren()) do
		if v:IsA('Part') and v.Name ~= 'HumanoidRootPart' then
			v.BrickColor = BrickColor.new('Brown')
		end
	end
end

function ALIEN(PLAYER)
	for i,v in pairs(PLAYER.Character:GetChildren()) do
		if v:IsA('Shirt') or v:IsA('Pants') or v:IsA('Accessory') then
			v:destroy()
		elseif v:IsA('ShirtGraphic') then
			v.Archivable = false
			v.Graphic = ''
		elseif v:IsA('Part') and v.Name ~= 'HumanoidRootPart' then
			v.BrickColor = BrickColor.new('Fossil')
		end
	end
	ALIEN_H:Clone().Parent = PLAYER.Character
end

function DECALSPAM(INSTANCE, ID)
	for i,v in pairs(INSTANCE:GetChildren()) do
		if v:IsA('BasePart') then
			spawn(function()
				local FACES = {'Back', 'Bottom', 'Front', 'Left', 'Right', 'Top'}
				local CURRENT_FACE = 1
				for i = 1, 6 do
					local DECAL = Instance.new('Decal', v)
					DECAL.Name = 'decal_seth'
					DECAL.Texture = 'rbxassetid://' .. ID - 1
					DECAL.Face = FACES[CURRENT_FACE]
					CURRENT_FACE = CURRENT_FACE + 1
				end
			end)
		end
		DECALSPAM(v, ID)
	end
end

function UNDECALSPAM(INSTANCE)
	for i,v in pairs(INSTANCE:GetChildren()) do
		if v:IsA('BasePart') then
			for a,b in pairs(v:GetChildren()) do
				if b:IsA('Decal') and b.Name == 'decal_seth' then
					b:destroy()
				end
			end
		end
		UNDECALSPAM(v)
	end
end

function CREATE_DONG(PLAYER, DONG_COLOR)
	if PLAYER.Character:FindFirstChild('DONG') then
		PLAYER.Character.DONG:destroy()
	end
	local D = Instance.new('Model', PLAYER.Character)
	D.Name = 'DONG'
	
	local BG = Instance.new('BodyGyro', PLAYER.Character.Torso)
	local MAIN = Instance.new('Part', PLAYER.Character['DONG'])
	local M1 = Instance.new('CylinderMesh', MAIN)
	local W1 = Instance.new('Weld', PLAYER.Character.Head)
	local P1 = Instance.new('Part', PLAYER.Character['DONG'])
	local M2 = Instance.new('SpecialMesh', P1)
	local W2 = Instance.new('Weld', P1)
	local B1 = Instance.new('Part', PLAYER.Character['DONG'])
	local M3 = Instance.new('SpecialMesh', B1)
	local W3 = Instance.new('Weld', B1)
	local B2 = Instance.new('Part', PLAYER.Character['DONG'])
	local M4 = Instance.new('SpecialMesh', B2)
	local W4 = Instance.new('Weld', B2)
	MAIN.TopSurface = 0 MAIN.BottomSurface = 0 MAIN.Name = 'Main' MAIN.Size = Vector3.new(0.6, 2.5, 0.6) MAIN.BrickColor = BrickColor.new(DONG_COLOR) MAIN.Position = PLAYER.Character.Head.Position MAIN.CanCollide = false
	W1.Part0 = MAIN W1.Part1 = PLAYER.Character.Head W1.C0 = CFrame.new(0, 0.25, 2.1) * CFrame.Angles(math.rad(45), 0, 0)
	P1.Name = 'Mush' P1.BottomSurface = 0 P1.TopSurface = 0 P1.Size = Vector3.new(0.6, 0.6, 0.6) P1.CFrame = CFrame.new(MAIN.Position) P1.BrickColor = BrickColor.new('Pink') P1.CanCollide = false
	M2.MeshType = 'Sphere'
	W2.Part0 = MAIN W2.Part1 = P1 W2.C0 = CFrame.new(0, 1.3, 0)
	B1.Name = 'Left Ball' B1.BottomSurface = 0 B1.TopSurface = 0 B1.CanCollide = false B1.Size = Vector3.new(1, 1, 1) B1.CFrame = CFrame.new(PLAYER.Character['Left Leg'].Position) B1.BrickColor = BrickColor.new(DONG_COLOR)
	M3.Parent = B1 M3.MeshType = 'Sphere'
	W3.Part0 = PLAYER.Character['Left Leg'] W3.Part1 = B1 W3.C0 = CFrame.new(0, 0.5, -0.5)
	B2.Name = 'Right Ball' B2.BottomSurface = 0 B2.CanCollide = false B2.TopSurface = 0 B2.Size = Vector3.new(1, 1, 1) B2.CFrame = CFrame.new(PLAYER.Character['Right Leg'].Position) B2.BrickColor = BrickColor.new(DONG_COLOR)
	M4.MeshType = 'Sphere'
	W4.Part0 = PLAYER.Character['Right Leg'] W4.Part1 = B2 W4.C0 = CFrame.new(0, 0.5, -0.5)
end

function SCALE(C, S)
	if tonumber(S) < 0.5 then S = 0.5 elseif tonumber(S) > 25 then S = 25 end
	
	local HAT_CLONE = {}
	
	for i,v in pairs(C:GetChildren()) do if v:IsA('Accessory') then local HC = v:Clone() table.insert(HAT_CLONE, HC) v:destroy() end end
	
	local HEAD = C.Head
	local TORSO = C.Torso
	local LA = C['Left Arm']
	local RA = C['Right Arm']
	local LL = C['Left Leg']
	local RL = C['Right Leg']
	local HRP = C.HumanoidRootPart
	
	HEAD.Size = Vector3.new(S * 2, S, S)
	TORSO.Size = Vector3.new(S * 2, S * 2, S)
	LA.Size = Vector3.new(S, S * 2, S)
	RA.Size = Vector3.new(S, S * 2, S)
	LL.Size = Vector3.new(S, S * 2, S)
	RL.Size = Vector3.new(S, S * 2, S)
	HRP.Size = Vector3.new(S * 2, S * 2, S)
	
	local M1 = Instance.new('Motor6D', TORSO)
	local M2 = Instance.new('Motor6D', TORSO)
	local M3 = Instance.new('Motor6D', TORSO)
	local M4 = Instance.new('Motor6D', TORSO)
	local M5 = Instance.new('Motor6D', TORSO)
	local M6 = Instance.new('Motor6D', HRP)
	
	M1.Name = 'Neck' M1.Part0 = TORSO M1.Part1 = HEAD M1.C0 = CFrame.new(0, 1 * S, 0) * CFrame.Angles(-1.6, 0, 3.1) M1.C1 = CFrame.new(0, -0.5 * S, 0) * CFrame.Angles(-1.6, 0, 3.1)
	M2.Name = 'Left Shoulder' M2.Part0 = TORSO M2.Part1 = LA M2.C0 = CFrame.new(-1 * S, 0.5 * S, 0) * CFrame.Angles(0, -1.6, 0) M2.C1 = CFrame.new(0.5 * S, 0.5 * S, 0) * CFrame.Angles(0, -1.6, 0)
	M3.Name = 'Right Shoulder' M3.Part0 = TORSO M3.Part1 = RA M3.C0 = CFrame.new(1 * S, 0.5 * S, 0) * CFrame.Angles(0, 1.6, 0) M3.C1 = CFrame.new(-0.5 * S, 0.5 * S, 0) * CFrame.Angles(0, 1.6, 0)
	M4.Name  = 'Left Hip' M4.Part0 = TORSO M4.Part1 = LL M4.C0 = CFrame.new(-1 * S, -1 * S, 0) * CFrame.Angles(0, -1.6, 0) M4.C1 = CFrame.new(-0.5 * S, 1 * S, 0) * CFrame.Angles(0, -1.6, 0)
	M5.Name = 'Right Hip' M5.Part0 = TORSO M5.Part1 = RL M5.C0 = CFrame.new(1 * S, -1 * S, 0) * CFrame.Angles(0, 1.6, 0) M5.C1 = CFrame.new(0.5 * S, 1 * S, 0) * CFrame.Angles(0, 1.6, 0)
	M6.Name = 'RootJoint' M6.Part0 = HRP M6.Part1 = TORSO M6.C0 = CFrame.new(0, 0, 0) * CFrame.Angles(-1.6, 0, -3.1) M6.C1 = CFrame.new(0, 0, 0) * CFrame.Angles(-1.6, 0, -3.1)
	
	for i,v in pairs(HAT_CLONE) do v.Parent = C end
end

function CAPE(COLOR)
	if LP.Character:FindFirstChild('Cape') then LP.Character.Cape:destroy() end
	
	repeat wait() until LP and LP.Character and LP.Character:FindFirstChild('Torso')
	
	local T = LP.Character.Torso
	
	local C = Instance.new('Part', T.Parent)
	C.Name = 'cape_seth'
	C.Anchored = false
	C.CanCollide = false
	C.TopSurface = 0
	C.BottomSurface = 0
	C.BrickColor = BrickColor.new(COLOR)
	C.Material = 'Neon'
	C.Size = Vector3.new(0.2, 0.2, 0.2)
	
	local M = Instance.new('BlockMesh', C)
	M.Scale = Vector3.new(9, 17.5, 0.5)
	
	local M1 = Instance.new('Motor', C)
	M1.Part0 = C
	M1.Part1 = T
	M1.MaxVelocity = 1
	M1.C0 = CFrame.new(0, 1.75, 0) * CFrame.Angles(0, math.rad(90), 0)
	M1.C1 = CFrame.new(0, 1, .45) * CFrame.Angles(0, math.rad(90), 0)
	
	local WAVE = false
	
	repeat wait(1 / 44)
		local ANG = 0.2
		local oldMag = T.Velocity.magnitude
		local MV = 0.1
		
		if WAVE then
			ANG = ANG + ((T.Velocity.magnitude / 10) * 0.05) + 1
			WAVE = false
		else
			WAVE = false
		end
		ANG = ANG + math.min(T.Velocity.magnitude / 30, 1)
		M1.MaxVelocity = math.min((T.Velocity.magnitude / 10), 0.04) + MV
		M1.DesiredAngle = -ANG
		if M1.CurrentAngle < -0.05 and M1.DesiredAngle > -.05 then
			M1.MaxVelocity = 0.04
		end
		repeat
			wait()
		until M1.CurrentAngle == M1.DesiredAngle or math.abs(T.Velocity.magnitude - oldMag)  >= (T.Velocity.magnitude / 10) + 1
		if T.Velocity.magnitude < 0.1 then
			wait(0.1)
		end
	until not C or C.Parent ~= T.Parent
end

function INFECT(PLAYER)
	for i,v in pairs(PLAYER.Character:GetChildren()) do
		Instance.new('Folder', PLAYER.Character).Name = 'infected_seth'
		if v:IsA('Accessory') or v:IsA('Shirt') or v:IsA('Pants') then
			v:destroy()
		elseif v:IsA('ShirtGraphic') then
			v.Archivable = false
			v.Graphic = ''
		end
	end
	
	if PLAYER.Character.Head:FindFirstChild('face') then
		PLAYER.Character.Head.face.Texture = 'rbxassetid://7074882'
	end
	
	for i,v in pairs (PLAYER.Character:GetChildren()) do
		if v:IsA('Part') and v.Name ~= 'HumanoidRootPart' then
			if v.Name == 'Head' or v.Name == 'Left Arm' or v.Name == 'Right Arm' then
				v.BrickColor = BrickColor.new('Medium green')
			elseif v.Name == 'Torso' or v.Name == 'Left Leg' or v.Name == 'Right Leg' then
				v.BrickColor = BrickColor.new('Brown')
			end
		end
	end
	
	local T = PLAYER.Character.Torso.Touched:connect(function(TC)
		if not TC.Parent:FindFirstChild('infected_seth') then
			local GPFC = _PLAYERS:GetPlayerFromCharacter(TC.Parent)
			if GPFC then
				INFECT(GPFC)
			end
		end
	end)
end

function fWeld(zName, zParent, zPart0, zPart1, zCoco, A, B, C, D, E, F)
	local funcw = Instance.new('Weld') funcw.Name = zName funcw.Parent = zParent funcw.Part0 = zPart0 funcw.Part1 = zPart1
	if (zCoco) then
		funcw.C0 = CFrame.new(A, B, C) * CFrame.fromEulerAnglesXYZ(D, E, F)
	else
		funcw.C1 = CFrame.new(A, B, C) * CFrame.fromEulerAnglesXYZ(D, E, F)
	end
	return funcw
end

function BANG(VICTIM)
	spawn(function()
		local P1 = _PLAYERS.LocalPlayer.Character.Torso
		local V1 = _PLAYERS[VICTIM].Character.Torso
		
		V1.Parent.Humanoid.PlatformStand = true
		
		P1['Left Shoulder']:destroy() local LA1 = Instance.new('Weld', P1) LA1.Part0 = P1 LA1.Part1 = P1.Parent['Left Arm'] LA1.C0 = CFrame.new(-1.5, 0, 0) LA1.Name = 'Left Shoulder'
		
		P1['Right Shoulder']:destroy() local RS1 = Instance.new('Weld', P1) RS1.Part0 = P1 RS1.Part1 = P1.Parent['Right Arm'] RS1.C0 = CFrame.new(1.5, 0, 0) RS1.Name = 'Right Shoulder'
		
		V1['Left Shoulder']:destroy() local LS2 = Instance.new('Weld', V1) LS2.Part0 = V1 LS2.Part1 = V1.Parent['Left Arm'] LS2.C0 = CFrame.new(-1.5, 0, 0) LS2.Name = 'Left Shoulder'
		
		V1['Right Shoulder']:destroy() local RS2 = Instance.new('Weld', V1) RS2.Part0 = V1 RS2.Part1 = V1.Parent['Right Arm'] RS2.C0 = CFrame.new(1.5, 0, 0) RS2.Name = 'Right Shoulder'
		
		V1['Left Hip']:destroy() local LH2 = Instance.new('Weld', V1) LH2.Part0 = V1 LH2.Part1 = V1.Parent['Left Leg'] LH2.C0 = CFrame.new(-0.5, -2, 0) LH2.Name = 'Left Hip'
		
		V1['Right Hip']:destroy() local RH2 = Instance.new('Weld', V1) RH2.Part0 = V1 RH2.Part1 = V1.Parent['Right Leg'] RH2.C0 = CFrame.new(0.5, -2, 0) RH2.Name = 'Right Hip'
		
		local D = Instance.new('Part', P1) D.TopSurface = 0 D.BottomSurface = 0 D.CanCollide = false D.BrickColor = BrickColor.new('Pastel brown') D.Shape = 'Ball' D.Size = Vector3.new(1, 1, 1)
		
		local DM1 = Instance.new('SpecialMesh', D) DM1.MeshType = 'Sphere' DM1.Scale = Vector3.new(0.4, 0.4, 0.4)
		
		fWeld('weld', P1, P1, D, true, -0.2, -1.3, -0.6, 0, 0, 0)
		
		local D2 = D:Clone() D2.Parent = P1
		
		fWeld('weld', P1, P1, D2, true, 0.2, -1.3, -0.6, 0, 0, 0)
		
		local C = Instance.new('Part', P1) C.TopSurface = 0 C.BottomSurface = 0 C.CanCollide = false C.BrickColor = BrickColor.new('Pastel brown') C.Size = Vector3.new(0.4, 1.3, 0.4)
		
		fWeld('weld', P1, P1, C, true, 0, -1, -0.52 + (-C.Size.y / 2), math.rad(-80), 0, 0)
		
		local C2 = D:Clone() C2.BrickColor = BrickColor.new('Pink') C2.Mesh.Scale = Vector3.new(0.4, 0.62, 0.4) C2.Parent = P1
		
		fWeld('weld', C, C, C2, true, 0, 0 + (C.Size.y / 2), 0, math.rad(-10), 0, 0)
		
		local CM = Instance.new('CylinderMesh', C)
		
		local BL = Instance.new('Part', V1) BL.TopSurface = 0 BL.BottomSurface = 0 BL.CanCollide = false BL.BrickColor = BrickColor.new('Pastel brown') BL.Shape = 'Ball' BL.Size = Vector3.new(1, 1, 1)
		
		local DM2 = Instance.new('SpecialMesh', BL) DM2.MeshType = 'Sphere' DM2.Scale = Vector3.new(1.2, 1.2, 1.2)
		
		fWeld('weld', V1, V1, BL, true, -0.5, 0.5, -0.6, 0, 0, 0)
		
		local BR = Instance.new('Part', V1) BR.TopSurface = 0 BR.BottomSurface = 0 BR.CanCollide = false BR.BrickColor = BrickColor.new('Pastel brown') BR.Shape = 'Ball' BR.Size = Vector3.new(1, 1, 1)
		
		local DM3 = Instance.new('SpecialMesh', BR) DM3.MeshType = 'Sphere' DM3.Scale = Vector3.new(1.2, 1.2, 1.2)
		
		fWeld('weld', V1, V1, BR, true, 0.5, 0.5, -0.6, 0, 0, 0)
		
		local BLN = Instance.new('Part', V1) BLN.TopSurface = 0 BLN.BottomSurface = 0 BLN.CanCollide = false BLN.BrickColor = BrickColor.new('Pink') BLN.Shape = 'Ball' BLN.Size = Vector3.new(1, 1, 1)
		
		local DM4 = Instance.new('SpecialMesh', BLN) DM4.MeshType = 'Sphere' DM4.Scale = Vector3.new(0.2, 0.2, 0.2)
		
		fWeld('weld', V1, V1, BLN, true, -0.5, 0.5, -1.2, 0, 0, 0)
		
		local BRN = Instance.new('Part', V1) BRN.TopSurface = 0 BRN.BottomSurface = 0 BRN.CanCollide = false BRN.BrickColor = BrickColor.new('Pink') BRN.Shape = 'Ball' BRN.Size = Vector3.new(1, 1, 1)
		
		local DM5 = Instance.new('SpecialMesh', BRN) DM5.MeshType = 'Sphere' DM5.Scale = Vector3.new(0.2, 0.2, 0.2)
		
		fWeld('weld', V1, V1, BRN, true, 0.5, 0.5, -1.2, 0, 0, 0)
		
		LH2.C1 = CFrame.new(0.2, 1.6, 0.4) * CFrame.Angles(3.9, -0.4, 0) RH2.C1 = CFrame.new(-0.2, 1.6, 0.4) * CFrame.Angles(3.9, 0.4, 0)
		LS2.C1 = CFrame.new(-0.2, 0.9, 0.6) * CFrame.Angles(3.9, -0.2, 0) RS2.C1 = CFrame.new(0.2, 0.9, 0.6) * CFrame.Angles(3.9, 0.2, 0)
		LA1.C1 = CFrame.new(-0.5, 0.7, 0) * CFrame.Angles(-0.9, -0.4, 0) RS1.C1 = CFrame.new(0.5, 0.7, 0) * CFrame.Angles(-0.9, 0.4, 0)
		
		if P1:FindFirstChild('weldx') then P1.weldx:destroy() end
		
		WE = fWeld('weldx', P1, P1, V1, true, 0, -0.9, -1.3, math.rad(-90), 0, 0)
		
		local N = V1.Neck N.C0 = CFrame.new(0, 1.5, 0) * CFrame.Angles(math.rad(-210), math.rad(180), 0)
	end)
	spawn(function() while wait() do for i = 1, 6 do WE.C1 = WE.C1 * CFrame.new(0, -0.3, 0) end for i = 1, 6 do WE.C1 = WE.C1 * CFrame.new(0, 0.3, 0) end end end)
end

function RESPAWN(PLAYER)
	local M = Instance.new('Model', workspace) M.Name = 'respawn_seth'
	local T = Instance.new('Part', M) T.Name = 'Torso' T.CanCollide = false T.Transparency = 1
	Instance.new('Humanoid', M)
	PLAYER.Character = M
end

function LOAD_MESSAGE(STRING)
	_PLAYERS.LocalPlayer.CharacterAppearanceId = 20018
	RESPAWN(LP)
	
	R = false
	LP.CharacterAdded:connect(function()
		if not R then
			wait(0.5)
			if LP.Character:FindFirstChild('Humanoid') then
				MAIN_HAT = LP.Character:FindFirstChild('BunnyEarsOfCaprice'):Clone()
			end
			R = true
		end
	end)
	repeat wait() until R
	RESPAWN(LP)
	LP.CharacterAppearanceId = 0
	
	if MAIN_HAT then
		MAIN_HAT.Handle.CanCollide = true
		local M = MAIN_HAT.Handle.BunnyTools.EggScript3:Clone()
		local P = Instance.new('Part')
		M.Disabled = false
		M.Parent = P
		MAIN_HAT.Handle.BunnyTools.EggMesh3:Clone().Parent = P
		MAIN_HAT:destroy()
		P.Parent = LP.Character
		repeat wait() until LP:FindFirstChild('ChessMsg')
		MG = LP:FindFirstChild('ChessMsg')
		MG.Name = 'message_seth'
		MG.Text = ''
		MG.Parent = workspace
		MESSAGE(STRING)
		P:destroy()
		for i,v in pairs(workspace:GetChildren()) do
			if v:IsA('Part') and v.BrickColor == BrickColor.new('Bright red') and v.Reflectance == 0 and v.Transparency == 0 and not v.Anchored and v.CanCollide and v.Locked and v:FindFirstChild('Decal') and v.Size == Vector3.new(8, 0.4, 8) then
				if v.Decal.Texture == 'http://www.roblox.com/asset/?id=1531000' and v.Transparency == 0 and v.Decal.Face == Enum.NormalId.Top then
					v:destroy()
				end
			end
		end
	end
end

function MESSAGE(STRING)
	if not SHOWING_MESSAGE then
		spawn(function()
			SHOWING_MESSAGE = true
			MG.Text = STRING
			wait(5)
			MG.Text = ''
			SHOWING_MESSAGE = false
		end)
	end
end

_G.CLICK_TP = false
local M_CTRL = false

MOUSE.KeyDown:connect(function(K) if K:byte() == 50 then M_CTRL = true end end)
MOUSE.KeyUp:connect(function(K) if K:byte() == 50 then M_CTRL = false end end)
MOUSE.Button1Down:connect(function() if _G.CLICK_TP and M_CTRL and MOUSE.Target and LP.Character and LP.Character:FindFirstChild('HumanoidRootPart') then LP.Character.HumanoidRootPart.CFrame = CFrame.new(MOUSE.Hit.p) + Vector3.new(0, 3, 0) end end)

_LIGHTING.Outlines = false -- / outlines are gross

if FIND_IN_TABLE(BANS, LP.userId) then LP:Kick() end

for i,v in pairs(_PLAYERS:GetPlayers()) do if FIND_IN_TABLE(BANS, v.userId) then table.insert(KICKS, v) else UPDATE_CHAT(v) end end

-- / commands

ADD_COMMAND('ff','ff [plr]', {},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		Instance.new('ForceField', _PLAYERS[v].Character)
	end
end)

ADD_COMMAND('unff','unff [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		for i,v in pairs(_PLAYERS[v].Character:GetChildren()) do
			if v:IsA('ForceField') then
				v:destroy()
			end
		end
	end
end)

ADD_COMMAND('fire','fire [plr] [r] [g] [b]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		for i,v in pairs(_PLAYERS[v].Character:GetChildren()) do
			if v:IsA('Part') and v.Name ~= 'HumanoidRootPart' then
				local F = Instance.new('Fire', v)
				if ARGS[2] and ARGS[3] and ARGS[4] then
					F.Color = C3(ARGS[2], ARGS[3], ARGS[4])
					F.SecondaryColor = C3(ARGS[2], ARGS[3], ARGS[4])
				end
			end
		end
	end
end)

ADD_COMMAND('unfire','unfire [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		for i,v in pairs(PCHAR:GetChildren()) do
			for i,v in pairs(v:GetChildren()) do
				if v:IsA('Fire') then
					v:destroy()
				end
			end
		end
	end
end)

ADD_COMMAND('sp','sp [plr] [r] [g] [b]',{'sparkles'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		for i,v in pairs(_PLAYERS[v].Character:GetChildren()) do
			if v:IsA('Part') and v.Name ~= 'HumanoidRootPart' then
				if ARGS[2] and ARGS[3] and ARGS[4] then
					Instance.new('Sparkles', v).Color = C3(ARGS[2], ARGS[3], ARGS[4])
				else
					Instance.new('Sparkles', v)
				end
			end
		end
	end
end)

ADD_COMMAND('unsp','unsp [plr]',{'unsparkles'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		for i,v in pairs(_PLAYERS[v].Character:GetChildren()) do
			for i,v in pairs(v:GetChildren()) do
				if v:IsA('Sparkles') then
					v:destroy()
				end
			end
		end
	end
end)

ADD_COMMAND('smoke','smoke [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		Instance.new('Smoke', _PLAYERS[v].Character.Torso)
	end
end)

ADD_COMMAND('unsmoke','unsmoke [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		for i,v in pairs(_PLAYERS[v].Character.Torso:GetChildren()) do
			if v:IsA('Smoke') then
				v:destroy()
			end
		end
	end
end)

ADD_COMMAND('btools','btools [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
if workspace:FindFirstChild'GiveSystem' then
if workspace.GiveSystem:FindFirstChild'GiveItem' then
maind = workspace.GiveSystem.GiveItem
end
end
if workspace:FindFirstChild'HandToCentre' then
if workspace.HandToCentre:FindFirstChild'SendItem' then
maind = workspace.HandToCentre.SendItem
end
end
if maind == nil then
print'could not find give event :('
return
end
tool = Instance.new'Tool'
me = game:GetService'Players'.LocalPlayer
tool.RequiresHandle = false
tool.TextureId = 'http://www.roblox.com/asset/?id=12223874'
tool.Name = 'ya like jazz?'
tool.Parent = me.Backpack
buttonf = nil
tool.Equipped:connect(function()
local m = game:GetService'Players'.LocalPlayer:GetMouse()
m.Icon = 'rbxasset://textures/HammerCursor.png'
buttonf = m.Button1Down:connect(function()
if m.Target == nil then return end
local ob = m.Target
if ob:IsA'BasePart' or ob:IsA'WedgePart' then
if ob:IsDescendantOf(me.Character) then return end
m.Icon = 'rbxasset://textures/HammerOverCursor.png'
local ex = Instance.new'Explosion'
ex.BlastRadius = 0
ex.Position = ob.Position
ex.Parent = workspace
maind:FireServer(workspace, ob)
wait(0.3)
m.Icon = 'rbxasset://textures/HammerCursor.png'
end
end)
end)
tool.Unequipped:connect(function()
if buttonf ~= nil then
buttonf:Disconnect()
buttonf = nil
end
local m = game:GetService'Players'.LocalPlayer:GetMouse()
m.Icon = ''
end) end end)


ADD_COMMAND('god','god [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if PCHAR:FindFirstChild('Humanoid') then
			PCHAR.Humanoid.MaxHealth = math.huge PCHAR.Humanoid.Health = PCHAR.Humanoid.MaxHealth
		end
	end
end)

ADD_COMMAND('sgod','sgod [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if PCHAR:FindFirstChild('Humanoid') then
			PCHAR.Humanoid.MaxHealth = 10000000 PCHAR.Humanoid.Health = PCHAR.Humanoid.MaxHealth
		end
	end
end)

ADD_COMMAND('ungod','ungod [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if PCHAR:FindFirstChild('Humanoid') then 
			PCHAR.Humanoid.MaxHealth = 100 
		end
	end
end)

ADD_COMMAND('heal','heal [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if PCHAR:FindFirstChild('Humanoid') then
			PCHAR.Humanoid.Health = PCHAR.Humanoid.MaxHealth
		end
	end
end)

ADD_COMMAND('freeze','freeze [plr]',{'frz'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		for i,v in pairs(PLAYERS) do
			local PCHAR = _PLAYERS[v].Character
			for i,v in pairs(PCHAR:GetChildren()) do
				if v:IsA('Part') and v.Name ~= 'HumanoidRootPart' then
					v.Anchored = true
				end
			end
		end
	end
end)

ADD_COMMAND('thaw','thaw [plr]',{'unfreeze','unfrz'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		for i,v in pairs(PLAYERS) do
			for i,v in pairs(_PLAYERS[v].Character:GetChildren()) do
				if v:IsA('Part') then
					v.Anchored = false
				end
			end
		end
	end
end)

ADD_COMMAND('kill','kill [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do


lo = _PLAYERS[v].Character.Torso.Neck
maind:FireServer(workspace,lo)

end end) 

ADD_COMMAND('sound','sound [id]',{},
function(ARGS, SPEAKER)
	for i,v in pairs(workspace:GetChildren()) do if v:IsA('Sound') then v:Stop() v:destroy() end end
	if ARGS[1]:lower() ~= 'off' then
		local S = Instance.new('Sound', workspace) S.Name = 'song_seth' S.Archivable = false S.Looped = true S.SoundId = 'rbxassetid://' .. ARGS[1] S.Volume = 1 S:Play()
	end
end)

ADD_COMMAND('volume','volume [int]',{},
function(ARGS, SPEAKER)
	for i,v in pairs(workspace:GetChildren()) do if v:IsA('Sound') then v.Volume = ARGS[1] end end
end)

ADD_COMMAND('pitch','pitch [int]',{},
function(ARGS, SPEAKER)
	for i,v in pairs(workspace:GetChildren()) do if v:IsA('Sound') then v.Pitch = ARGS[1] end end
end)

ADD_COMMAND('explode','explode [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if PCHAR:FindFirstChild('Torso') then
			Instance.new('Explosion', PCHAR).Position = PCHAR.Torso.Position					
		end
	end
end)

ADD_COMMAND('invis','invis [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		for i,v in pairs(PCHAR:GetChildren()) do
			if v:IsA('Part') and v.Name ~= 'HumanoidRootPart' then
				v.Transparency = 1
			end
			if v:IsA('Accessory') and v:FindFirstChild('Handle') then
				v.Handle.Transparency = 1
			end
		end
		if PCHAR.Head:FindFirstChild('face') then PCHAR.Head.face.Transparency = 1 end
	end
end)

ADD_COMMAND('vis','vis [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		for i,v in pairs(PCHAR:GetChildren()) do
			if v:IsA('Part') and v.Name ~= 'HumanoidRootPart' then
				v.Transparency = 0
			end
			if v:IsA('Accessory') and v:FindFirstChild('Handle') then
				v.Handle.Transparency = 0
			end
		end
		if PCHAR.Head:FindFirstChild('face') then PCHAR.Head.face.Transparency = 0 end
	end
end)

ADD_COMMAND('goto','goto [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if PCHAR then
			SPEAKER.Character.HumanoidRootPart.CFrame = PCHAR.Torso.CFrame
		end
	end
end)

ADD_COMMAND('bring','bring [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		_PLAYERS[v].Character.HumanoidRootPart.CFrame = SPEAKER.Character.Torso.CFrame
	end
end)

ADD_COMMAND('tp','tp [plr] [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS1, PLAYERS2 = GET_PLAYER(ARGS[1], SPEAKER), GET_PLAYER(ARGS[2], SPEAKER)
	for i,v in pairs(PLAYERS1) do for a,b in pairs(PLAYERS2) do
		if _PLAYERS[v].Character and _PLAYERS[b].Character then
			_PLAYERS[v].Character.HumanoidRootPart.CFrame = _PLAYERS[b].Character.Torso.CFrame
		end
	end end
end)

ADD_COMMAND('char','char [plr] [id]',{'charapp'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		_PLAYERS[v].CharacterAppearanceId = ARGS[2]
		_PLAYERS[v].Character:BreakJoints()
	end
end)

ADD_COMMAND('ws','ws [plr] [int]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if PCHAR:FindFirstChild('Humanoid') then
			PCHAR.Humanoid.WalkSpeed = tonumber(ARGS[2])
		end
	end
end)

ADD_COMMAND('time','time [int]',{},
function(ARGS, SPEAKER)
	_LIGHTING:SetMinutesAfterMidnight(tonumber(ARGS[1]) * 60)
end)

ADD_COMMAND('kick','kick [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		table.insert(KICKS, _PLAYERS[v])
	end
end)

ADD_COMMAND('ban','ban [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		table.insert(BANS, _PLAYERS[v].userId)
		table.insert(KICKS, _PLAYERS[v])
		UPDATE_BANS()
	end
end)

ADD_COMMAND('unban','unban [username]',{},
function(ARGS, SPEAKER)
	if FIND_IN_TABLE(BANS, game.Players:GetUserIdFromNameAsync(ARGS[1])) then
		table.remove(BANS, GET_IN_TABLE(BANS, game.Players:GetUserIdFromNameAsync(ARGS[1])))
		UPDATE_BANS()
	end
end)

ADD_COMMAND('unlockws','unlock',{'unlock'},
function(ARGS, SPEAKER)
	local function UNLOCK(INSTANCE) 
		for i,v in pairs(INSTANCE:GetChildren()) do
			if v:IsA('BasePart') then
				v.Locked = false
			end
			UNLOCK(v)
		end
	end
	UNLOCK(workspace)
end)

ADD_COMMAND('lockws','lock',{'lock'},
function(ARGS, SPEAKER)
	local function LOCK(INSTANCE) 
		for i,v in pairs(INSTANCE:GetChildren()) do
			if v:IsA('BasePart') then
				v.Locked = true
			end
			LOCK(v)
		end
	end
	LOCK(workspace)
end)

ADD_COMMAND('unanchorws','unanchor',{'unanchor'},
function(ARGS, SPEAKER)
   local function UNANCHOR(INSTANCE) 
		for i,v in pairs(INSTANCE:GetChildren()) do
			if v:IsA('BasePart') then
				v.Anchored = false
			end
			UNANCHOR(v)
		end
	end
	UNANCHOR(workspace)
end)

ADD_COMMAND('anchorws','anchor',{'anchor'},
function(ARGS, SPEAKER)
   local function ANCHOR(INSTANCE) 
		for i,v in pairs(INSTANCE:GetChildren()) do
			if v:IsA('BasePart') then
				v.Anchored = true
			end
			ANCHOR(v)
		end
	end
	ANCHOR(workspace)
end)

ADD_COMMAND('hsize','hsize [plr] [int]',{'hatsize'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		for i,v in pairs(_PLAYERS[v].Character:GetChildren()) do
			if v:IsA('Accessory') then
				for a,b in pairs(v.Handle:GetChildren()) do
					if b:IsA('SpecialMesh') then
						b.Scale = ARGS[2] * Vector3.new(1, 1, 1)
					end
				end
			end
		end
	end
end)

ADD_COMMAND('shats','shats [plr]',{'stealhats'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		for i,v in pairs(_PLAYERS[v].Character:GetChildren()) do
			if v:IsA('Accessory') then
				v.Parent = SPEAKER.Character
			end
		end
	end
end)

ADD_COMMAND('rhats','rhats [plr]',{'removehats'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if PCHAR:FindFirstChild('Humanoid') then
			PCHAR.Humanoid:RemoveAccessories()
		end
	end
end)

ADD_COMMAND('firstp','firstp [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		_PLAYERS[v].CameraMode = 'LockFirstPerson'
	end
end)

ADD_COMMAND('thirdp','thirdp [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		_PLAYERS[v].CameraMode = 'Classic'
	end
end)

ADD_COMMAND('chat','chat [plr] [string]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		game.Chat:Chat(_PLAYERS[v].Character.Head, GLS(false, 1))
	end
end)

ADD_COMMAND('name','name [plr] [string]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		_PLAYERS[v].Character.Name = GLS(false, 1)
	end
end)

ADD_COMMAND('unname','unname [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		_PLAYERS[v].Character.Name = _PLAYERS[v].Name
	end
end)

ADD_COMMAND('noname','noname [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		_PLAYERS[v].Character.Name = ''
	end
end)

ADD_COMMAND('stun','stun [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character.HumanoidRootPart
		maind:FireServer(workspace,PCHAR)
	end
end)

ADD_COMMAND('unstun','unstun [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		PCHAR.Humanoid.PlatformStand = false
	end
end)

ADD_COMMAND('guest','guest [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		_PLAYERS[v].CharacterAppearanceId = 1
		PCHAR:BreakJoints()
	end
end)

ADD_COMMAND('noob','noob [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		_PLAYERS[v].CharacterAppearanceId = 155902847
		PCHAR:BreakJoints()
	end
end)

ADD_COMMAND('damage','damage [plr] [int]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		_PLAYERS[v].Character.Humanoid:TakeDamage(ARGS[2])
	end
end)

ADD_COMMAND('view','view [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		workspace.CurrentCamera.CameraSubject = PCHAR
	end
end)

ADD_COMMAND('unview','unview',{},
function()
	workspace.CurrentCamera.CameraSubject = _PLAYERS.LocalPlayer.Character
end)

ADD_COMMAND('nolimbs','nolimbs [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		for i,v in pairs(PCHAR:GetChildren()) do
			local LIMB = PCHAR.Humanoid:GetLimb(v)
			if v:IsA('BasePart') and PCHAR:FindFirstChild('Humanoid') and LIMB ~= Enum.Limb.Unknown and LIMB ~= Enum.Limb.Head and LIMB ~= Enum.Limb.Torso then
			maind:FireServer(workspace,v)
			end
		end
	end	
end)

ADD_COMMAND('bald','bald [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		for i,v in pairs(PCHAR:GetChildren()) do
			local LIMB = PCHAR.Humanoid:GetLimb(v)
			if v:IsA('Accoutrement') then
			maind:FireServer(workspace,v)
			end
		end
	end	
end)

ADD_COMMAND('box','box [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		local SB = Instance.new('SelectionBox', PCHAR)
		SB.Adornee = SB.Parent
		SB.Color = BrickColor.new('' .. (ARGS[2]))
	end
end)

ADD_COMMAND('unbox','nobox [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		for i,v in pairs(_PLAYERS[v].Character:GetChildren()) do
			if v:IsA('SelectionBox') then
				v:destroy()
			end
		end
	end
end)

ADD_COMMAND('ghost','ghost [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		for i,v in pairs(PCHAR:GetChildren()) do
			if v:IsA('Part') and v.Name ~= 'HumanoidRootPart' then
				v.Transparency = 0.5
			elseif v:IsA('Accessory') and v:FindFirstChild('Handle') then
				v.Handle.Transparency = 0.5
			elseif PCHAR.Head:FindFirstChild('face') then
				PCHAR.Head.face.Transparency = 0.5
			end
		end
	end
end)

ADD_COMMAND('sphere','sphere [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR=_PLAYERS[v].Character
		local SS = Instance.new('SelectionSphere', PCHAR)
		SS.Adornee = SS.Parent
	end
end)

ADD_COMMAND('sky','sky [id]',{},
function(ARGS, SPEAKER)
	if ARGS[1] then
		for i,v in pairs(_LIGHTING:GetChildren()) do if v:IsA('Sky') then v:destroy() end end
		local SKIES = {'Bk', 'Dn', 'Ft', 'Lf', 'Rt', 'Up'}
		local SKY = Instance.new('Sky', _LIGHTING)
		for i,v in pairs(SKIES) do
			SKY['Skybox' .. v] = 'rbxassetid://' .. ARGS[1] - 1
		end
	end
end)

ADD_COMMAND('ambient','ambient [r] [g] [b]',{},
function(ARGS, SPEAKER)
	if ARGS[1] and ARGS[2] and ARGS[3] then
		_LIGHTING.Ambient = C3(ARGS[1], ARGS[2], ARGS[3])
	end
end)

ADD_COMMAND('jail','jail [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		if FIND_IN_TABLE(JAILED, _PLAYERS[v].Name) then return end
		table.insert(JAILED, _PLAYERS[v].Name)
		local PCHAR = _PLAYERS[v].Character
		local J = JAIL:Clone() J.Parent = workspace J:MoveTo(PCHAR.Torso.Position) J.Name = 'JAIL_' .. _PLAYERS[v].Name
		repeat wait()
			PCHAR = _PLAYERS[v].Character if PCHAR and PCHAR:FindFirstChild('HumanoidRootPart') and J:FindFirstChild('MAIN') then PCHAR.HumanoidRootPart.CFrame = J.MAIN.CFrame + Vector3.new(0, 1, 0) end
		until not FIND_IN_TABLE(JAILED, _PLAYERS[v].Name)
	end
end)

ADD_COMMAND('unjail','unjail [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		for a,b in pairs(JAILED) do if b == _PLAYERS[v].Name then table.remove(JAILED, a) end end
		if workspace:FindFirstChild('JAIL_' .. _PLAYERS[v].Name) then workspace['JAIL_' .. _PLAYERS[v].Name]:destroy() end
	end
end)

ADD_COMMAND('animation','animation [plr] [id]',{'anim'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local ID = ARGS[2]
		if ARGS[2] == 'climb' then ID = '180436334' end
		if ARGS[2] == 'fall' then ID = '180436148' end
		if ARGS[2] == 'jump' then ID = '125750702' end
		if ARGS[2] == 'sit' then ID = '178130996' end
		for a,b in pairs(_PLAYERS[v].Character.Animate:GetChildren()) do
			if b:IsA('StringValue') then
				for c,d in pairs(b:GetChildren()) do
					if d:IsA('Animation') then
						d.AnimationId = 'rbxassetid://' .. ID
					end
				end
			end
		end
	end
end)

ADD_COMMAND('fix','fix [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		RESET_MODEL(PCHAR)
		UPDATE_MODEL(PCHAR, _PLAYERS[v].Name)
	end
end)

ADD_COMMAND('creeper','creeper [plr]',{'crpr'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		CREEPER(_PLAYERS[v])
	end
end)

ADD_COMMAND('uncreeper','uncreeper [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		RESET_MODEL(PCHAR)
		UPDATE_MODEL(PCHAR, _PLAYERS[v].Name)
	end
end)

ADD_COMMAND('shrek','shrek [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		SHREK(_PLAYERS[v])
	end
end)

ADD_COMMAND('unshrek','unshrek [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		RESET_MODEL(PCHAR)
		UPDATE_MODEL(PCHAR, _PLAYERS[v].Name)
	end
end)

ADD_COMMAND('nuke','nuke [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		spawn(function()
			if _PLAYERS[v] and PCHAR and PCHAR:FindFirstChild('Torso')  then
				local N = Instance.new('Part', workspace)
				N.Name = 'nuke_seth'
				N.Anchored = true
				N.CanCollide = false
				N.Shape = 'Ball'
				N.Size = Vector3.new(1, 1, 1)
				N.BrickColor = BrickColor.new('New Yeller')
				N.Transparency = 0.5
				N.Reflectance = 0.2
				N.TopSurface = 0
				N.BottomSurface = 0
				N.Touched:connect(function(T)
					if T and T.Parent then
						local E = Instance.new('Explosion', workspace)
						E.Position = T.Position
						E.BlastRadius = 20
						E.BlastPressure = math.huge
					end
				end)
				local CF = PCHAR.Torso.CFrame
				N.CFrame = CF
				for i = 1,30 do
					N.Size = N.Size + Vector3.new(5, 5, 5)
					N.CFrame = CF
					wait(1 / 44)
				end
				N:destroy()
			end
		end)
	end
end)

ADD_COMMAND('unnuke','nonuke',{},
function(ARGS, SPEAKER)
	for i,v in pairs(workspace:GetChildren()) do
		if v:IsA('Part') and v.Name == 'nuke_seth' then
			v:destroy()
		end
	end
end)

ADD_COMMAND('infect','infect [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		INFECT(_PLAYERS[v])
	end
end)

ADD_COMMAND('uninfect','uninfect [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		RESET_MODEL(PCHAR)
		UPDATE_MODEL(PCHAR, _PLAYERS[v].Name)
	end
end)

ADD_COMMAND('duck','duck [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		DUCK(_PLAYERS[v])
	end
end)

ADD_COMMAND('unduck','unduck [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		RESET_MODEL(PCHAR)
		UPDATE_MODEL(PCHAR, _PLAYERS[v].Name)
	end
end)

ADD_COMMAND('disable','disable [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character.Humanoid
		maind:FireServer(workspace,PCHAR)
		end
end)

ADD_COMMAND('enable','enable [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if PCHAR:FindFirstChild('Humanoid') then
			return
		else
			if HUMANOIDS:FindFirstChild('HUMANOID_' .. _PLAYERS[v].Name) then
				local humanoid = HUMANOIDS['HUMANOID_' .. _PLAYERS[v].Name] humanoid.Parent = PCHAR humanoid.Name = 'Humanoid'
			end
		end
	end
end)

ADD_COMMAND('size','size [plr] [int]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		SCALE(_PLAYERS[v].Character, ARGS[2])
	end
end)

ADD_COMMAND('clone','clone [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character PCHAR.Archivable = true
		local C = PCHAR:Clone() C.Parent = workspace C:MoveTo(PCHAR:GetModelCFrame().p) C:MakeJoints()
		PCHAR.Archivable = false
	end
end)

ADD_COMMAND('spin','spin [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		for i,v in pairs(PCHAR.Torso:GetChildren()) do
			if v.Name == 'SPIN' then
				v:destroy()
			end
		end
		local T = PCHAR.Torso
		local BG = Instance.new('BodyGyro', T) BG.Name = 'SPIN' BG.maxTorque = Vector3.new(0, math.huge, 0) BG.P = 11111 BG.cframe = T.CFrame
		spawn(function()
			repeat wait(1/44)
				BG.CFrame = BG.CFrame * CFrame.Angles(0,math.rad(30),0)
			until not BG or BG.Parent ~= T
		end)
	end
end)

ADD_COMMAND('unspin','unspin [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		for i,v in pairs(PCHAR.Torso:GetChildren()) do
			if v.Name == 'SPIN' then
				v:destroy()
			end
		end
	end
end)

ADD_COMMAND('dog','dog [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		DOG(_PLAYERS[v])
	end
end)

ADD_COMMAND('undog','undog [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		RESET_MODEL(PCHAR)
		UPDATE_MODEL(PCHAR, _PLAYERS[v].Name)
	end
end)

ADD_COMMAND('loopheal','loopheal [plr]',{'lheal'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		if not FIND_IN_TABLE(LOOPED_H, _PLAYERS[v].Name) then
			table.insert(LOOPED_H, _PLAYERS[v].Name)
		end
	end
end)

ADD_COMMAND('unloopheal','unloopheal [plr]',{'unlheal'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		if FIND_IN_TABLE(LOOPED_H, _PLAYERS[v].Name) then
			table.remove(LOOPED_H, GET_IN_TABLE(LOOPED_H, _PLAYERS[v].Name))
		end
	end
end)

ADD_COMMAND('loopkill','loopheal [plr]',{'lheal'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		if not FIND_IN_TABLE(LOOPED_K, _PLAYERS[v].Name) then
			table.insert(LOOPED_K, _PLAYERS[v].Name)
		end
	end
end)

ADD_COMMAND('unloopkill','unloopkill [plr]',{'unlkill'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		if FIND_IN_TABLE(LOOPED_K, _PLAYERS[v].Name) then
			table.remove(LOOPED_K, GET_IN_TABLE(LOOPED_K, _PLAYERS[v].Name))
		end
	end
end)

ADD_COMMAND('fling','fling [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if PCHAR:FindFirstChild('Humanoid') then
			local X
			local Z
			repeat
				X = math.random(-9999, 9999)
			until math.abs(X) >= 5555
			repeat
				Z = math.random(-9999, 9999)
			until math.abs(Z) >= 5555
			PCHAR.Torso.Velocity = Vector3.new(0, 0, 0)
			local BF = Instance.new('BodyForce', PCHAR.Torso) BF.force = Vector3.new(X * 4, 9999 * 5, Z * 4)
		end
	end
end)

ADD_COMMAND('alien','alien [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		ALIEN(_PLAYERS[v])
	end
end)

ADD_COMMAND('nograv','nograv [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		if not _PLAYERS[v].Character.Torso:FindFirstChild('nograv_seth') then
			NEW'BodyForce'{Name = 'nograv_seth', Force = Vector3.new(0, GET_MASS(_PLAYERS[v].Character) * 196.2, 0), Parent = _PLAYERS[v].Character.Torso}
		end
	end
end)

ADD_COMMAND('grav','grav [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		if _PLAYERS[v].Character.Torso:FindFirstChild('nograv_seth') then
			_PLAYERS[v].Character.Torso.nograv_seth:destroy()
		end
	end
end)

ADD_COMMAND('cape','cape [brick color]',{},
function(ARGS, SPEAKER)
	spawn(function()
		if LP.Character:FindFirstChild('Cape') then
			LP.Character.Cape:destroy()
		end
		if not ARGS[1] then
			ARGS[1] = 'Deep blue'
		end
		CAPE(GLS(false, 1))
	end)
end)

ADD_COMMAND('uncape','uncape',{},
function(ARGS, SPEAKER)
	if LP.Character:FindFirstChild('cape_seth') then
		LP.Character.cape_seth:destroy()
	end
end)

ADD_COMMAND('paper','paper [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		for i,v in pairs(PCHAR:GetChildren()) do
			if v:IsA('Part') and v.Name ~= 'HumanoidRootPart' then
				PAPER_MESH:Clone().Parent = v
			end
		end
	end
end)

ADD_COMMAND('punish','punish [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
	local b =	_PLAYERS[v].Character
maind:FireServer(workspace,b)
	end
end)

ADD_COMMAND('unpunish','unpunish [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		_PLAYERS[v].Character.Parent = workspace
	end
end)

local DISCO = false

ADD_COMMAND('disco','disco',{},
function(ARGS, SPEAKER)
	DISCO = true
	if not DISCO then
		spawn(function()
			repeat wait(1) _LIGHTING.Ambient = C3(math.random(), math.random(), math.random()) until not DISCO
		end)
	end
end)

ADD_COMMAND('undisco','undisco',{},
function(ARGS, SPEAKER)
	DISCO = false
end)

ADD_COMMAND('team','team [plr] [team]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		for a,b in pairs(game.Teams:GetChildren()) do
			if string.lower(b.Name) == GLS(true, 1) then
				_PLAYERS[v].Team = b
			end
		end
	end
end)

ADD_COMMAND('jp','jp [plr] [int]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if PCHAR:FindFirstChild('Humanoid') then PCHAR.Humanoid.JumpPower = ARGS[2] end
	end
end)

ADD_COMMAND('smallhead','smallhead [plr]',{'shead'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		PCHAR.Head.Mesh.Scale = Vector3.new(0.5, 0.5, 0.5)
		PCHAR.Head.Mesh.Offset = Vector3.new(0, -0.25, 0)
	end
end)

ADD_COMMAND('bighead','bighead [plr]',{'bhead'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		PCHAR.Head.Mesh.Scale = Vector3.new(2.25, 2.25, 2.25)
		PCHAR.Head.Mesh.Offset = Vector3.new(0, 0.5, 0)
	end
end)

ADD_COMMAND('headsize','headsize [plr] [int]',{'hsize'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if ARGS[2] == 1 then
			PCHAR.Head.Mesh.Scale = Vector3.new(1.25, 1.25, 1.25)
			PCHAR.Head.Mesh.Offset = Vector3.new(0, 0, 0)
		else
			PCHAR.Head.Mesh.Scale = ARGS[2] * Vector3.new(1.25, 1.25, 1.25)
		end
	end
end)

ADD_COMMAND('fixhead','fixhead [plr]',{'fhead'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		PCHAR.Head.Mesh.Scale = Vector3.new(1.25, 1.25, 1.25)
		PCHAR.Head.Mesh.Offset = Vector3.new(0, 0, 0)
		PCHAR.Head.Transparency = 0
		if PCHAR.Head:FindFirstChild('face') then PCHAR.Head.face.Transparency = 0 end
	end
end)

ADD_COMMAND('removehead','removehead [plr]',{'rhead'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		PCHAR.Head.Transparency = 1
		if PCHAR.Head:FindFirstChild('face') then PCHAR.Head.face.Transparency = 1 end
	end
end)

ADD_COMMAND('stealtools','stealtools [plr]',{'stools'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		for i,v in pairs(_PLAYERS[v].Backpack:GetChildren()) do
			if v:IsA('Tool') or v:IsA('HopperBin') then
				v.Parent = LP.Backpack
			end
		end
	end
end)

ADD_COMMAND('removetools','removetools [plr]',{'rtools'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		for i,v in pairs(_PLAYERS[v].Backpack:GetChildren()) do
			if v:IsA('Tool') or v:IsA('HopperBin') then
				v:destroy()
			end
		end
	end
end)

ADD_COMMAND('clonetools','clonetools [plr]',{'ctools'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		for i,v in pairs(_PLAYERS[v].Backpack:GetChildren()) do
			if v:IsA('Tool') or v:IsA('HopperBin') then
				v:Clone().Parent = LP.Backpack
			end
		end
	end
end)

ADD_COMMAND('dong','dong [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if ARGS[2] == 'black' then
			CREATE_DONG(_PLAYERS[v], 'Brown')
		end
		if ARGS[2] == 'asian' then
			CREATE_DONG(_PLAYERS[v], 'Cool yellow')
		end
		if ARGS[2] == 'alien' then
			CREATE_DONG(_PLAYERS[v], 'Lime green')
		end
		if ARGS[2] == 'frozen' then
			CREATE_DONG(_PLAYERS[v], 1019)
		end
		if not ARGS[2] then
			CREATE_DONG(_PLAYERS[v], 'Pastel brown')
		end
	end
end)

ADD_COMMAND('particles','particles [plr] [id]',{'pts'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		for i,v in pairs(PCHAR.Torso:GetChildren()) do
			if v:IsA('ParticleEmitter') then
				v:destroy()
			end
		end
		Instance.new('ParticleEmitter', PCHAR.Torso).Texture = 'rbxassetid://' .. ARGS[2] - 1
	end
end)

ADD_COMMAND('rocket','rocket [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		spawn(function()
			local R = ROCKET:Clone()
			R.Parent = workspace
			local W = Instance.new('Weld', R)
			W.Part0 = W.Parent
			W.Part1 = PCHAR.Torso
			W.C1 = CFrame.new(0, 0.5, 1)
			R.force.Force = Vector3.new(0, 15000, 0)
			wait()
			PCHAR.HumanoidRootPart.CFrame = PCHAR.HumanoidRootPart.CFrame * CFrame.new(0, 5, 0)
			wait(5)
			Instance.new('Explosion', R).Position = R.Position
			wait(1)
			R:destroy()
		end)
	end
end)

ADD_COMMAND('blackify','blackify [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		COLOR(_PLAYERS[v], 'Really black')
	end
end)

ADD_COMMAND('whitify','whitify [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		COLOR(_PLAYERS[v], 'White')
	end
end)

ADD_COMMAND('color','color [plr] [brick color]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		COLOR(_PLAYERS[v], GLS(false, 1))
	end
end)

ADD_COMMAND('change','change [plr] [stat] [int/string]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		if _PLAYERS[v]:FindFirstChild('leaderstats') then
			for i,v in pairs(_PLAYERS[v].leaderstats:GetChildren()) do
				if string.lower(v.Name) == string.lower(ARGS[2]) and v:IsA('IntValue') or v:IsA('NumberValue') then
					if ARGS[3] then v.Value = tonumber(ARGS[3]) end
				elseif string.lower(v.Name) == string.lower(ARGS[2]) and v:IsA('StringValue') then
					v.Value = GLS(false, 2)
				end
			end
		end
	end
end)

ADD_COMMAND('bait','bait',{},
function(ARGS, SPEAKER)
	spawn(function()
		local M = Instance.new('Model', workspace) M.Name = 'Touch For Admin!'
		local P = Instance.new('Part', M) P.Name = 'Head' P.Position = SPEAKER.Character.Head.Position P.BrickColor = BrickColor.new('Pink') P.Material = 'Neon'
		local H = Instance.new('Humanoid', M)
		P.Touched:connect(function(RIP) if RIP.Parent.Name ~= SPEAKER.Name or RIP.Parent.Name ~= LP.Name then if RIP.Parent:FindFirstChild('Humanoid') then RIP.Parent.Humanoid:destroy() end end end)
	end)
end)

ADD_COMMAND('naked','naked [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		for i,v in pairs(PCHAR:GetChildren()) do
			if v:IsA('Shirt') or v:IsA('Pants') or v:IsA('ShirtGraphic') then
			maind:FireServer(workspace,v)
			end
			for i,v in pairs(PCHAR.Torso:GetChildren()) do
				if v:IsA('Decal') then
			maind:FireServer(workspace,v)
				end
			end
		end
	end
end)

ADD_COMMAND('clr','clr',{},
function(ARGS, SPEAKER)
for _,v in pairs(workspace:GetChildren()) do if v.Name ~= "GiveSystem" then workspace.GiveSystem.GiveItem:FireServer(workspace,v) 
end end end) 

ADD_COMMAND('decalspam','decalspam [decal]',{'dspam'},
function(ARGS, SPEAKER)
	if ARGS[1] then
		DECALSPAM(workspace, ARGS[1])
	end
end)

ADD_COMMAND('undecalspam','undecalspam',{'undspam'},
function(ARGS, SPEAKER)
	if ARGS[1] then
		UNDECALSPAM(workspace)
	end
end)

ADD_COMMAND('bang','bang [plr]',{'rape'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		BANG(_PLAYERS[v].Name)
	end
end)

ADD_COMMAND('lag','lag [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		LAG(_PLAYERS[v])
	end
end)

ADD_COMMAND('respawn','respawn [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		RESPAWN(_PLAYERS[v])
	end
end)

ADD_COMMAND('face','face [plr] [decal]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		for i,v in pairs(PCHAR.Head:GetChildren()) do if v:IsA('Decal') then v:destroy() end end
		local F = Instance.new('Decal', PCHAR.Head) F.Name = 'face' F.Texture = 'rbxassetid://' .. ARGS[2] - 1
	end
end)

ADD_COMMAND('shirt','shirt [plr] [decal]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		for i,v in pairs(PCHAR:GetChildren()) do if v:IsA('Shirt') then v:destroy() end end
		local S = Instance.new('Shirt', PCHAR) S.Name = 'Shirt' S.ShirtTemplate = 'rbxassetid://' .. ARGS[2] - 1
	end
end)

ADD_COMMAND('pants','pants [plr] [decal]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		for i,v in pairs(PCHAR:GetChildren()) do if v:IsA('Pants') then v:destroy() end end
		local P = Instance.new('Pants', PCHAR) P.Name = 'Shirt' P.PantsTemplate = 'rbxassetid://' .. ARGS[2] - 1
	end
end)

ADD_COMMAND('longneck','longneck [plr]',{'lneck', 'giraffe'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		RESET_MODEL(PCHAR)
		UPDATE_MODEL(PCHAR, _PLAYERS[v].Name)
		for i,v in pairs(PCHAR:GetChildren()) do if v:IsA('Accessory') then v.Handle.Mesh.Offset = Vector3.new(0, 5, 0) end end
		if PCHAR.Head:FindFirstChild('Mesh') then PCHAR.Head.Mesh.Offset = Vector3.new(0, 5, 0) end
		local G = Instance.new('Part', PCHAR) G.Name = 'giraffe_seth' G.BrickColor = PCHAR.Head.BrickColor G.Size = Vector3.new(2, 1, 1)
		local SM = Instance.new('SpecialMesh', G) SM.Scale = Vector3.new(1.25, 5, 1.25) SM.Offset = Vector3.new(0, 2, 0)
		local W = Instance.new('Weld', G) W.Part0 = PCHAR.Head W.Part1 = G
	end
end)

ADD_COMMAND('stealchar','stealchar [plr]',{'schar'},
function(ARGS, SPEAKER)
	local PLAYERS1, PLAYERS2 = GET_PLAYER(ARGS[1])
	for i,v in pairs(PLAYERS1) do
		RESET_MODEL(SPEAKER.Character) UPDATE_MODEL(SPEAKER.Character, _PLAYERS[v].Name)
	end
end)

ADD_COMMAND('baseplate','baseplate',{'bp'},
function(ARGS, SPEAKER)
	for i,v in pairs(workspace:GetChildren()) do if v:IsA('Model') and v.Name == 'baseplate_seth' then v:destroy() end end
	local BP = Instance.new('Part', workspace) BP.Name = 'baseplate_seth' BP.Anchored = true BP.BrickColor = BrickColor.new('Bright green') BP.Size = Vector3.new(2048, 5, 2048) BP.Position = Vector3.new(0, 0, 0)
end)

ADD_COMMAND('norotate','norotate [plr]',{'nrt'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if PCHAR:FindFirstChild('Humanoid') then PCHAR.Humanoid.AutoRotate = false end
	end
end)

ADD_COMMAND('rotate','rotate [plr]',{'rt'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if PCHAR:FindFirstChild('Humanoid') then PCHAR.Humanoid.AutoRotate = true end
	end
end)

ADD_COMMAND('admin','admin [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		if not CHECK_ADMIN(_PLAYERS[v]) then
			table.insert(ADMINS, _PLAYERS[v].userId)
			UPDATE_ADMINS()
			spawn(function()
				game.Chat:Chat(_PLAYERS[v].Character.Head, STUFF .. 'You\'re now an admin!')
				wait(3)
				game.Chat:Chat(_PLAYERS[v].Character.Head, STUFF .. 'Give me a try! | ' .. C_PREFIX .. 'ff me')
			end)
		end
	end
end)

ADD_COMMAND('unadmin','unadmin [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		if CHECK_ADMIN(_PLAYERS[v]) then
			if FIND_IN_TABLE(ADMINS, _PLAYERS[v].userId) then
				table.remove(ADMINS, GET_IN_TABLE(ADMINS, _PLAYERS[v].userId))
				UPDATE_ADMINS()
				game.Chat:Chat(_PLAYERS[v].Character.Head, STUFF .. 'You\'re no longer an admin.')
			end
		end
	end
end)

ADD_COMMAND('minzoom','minzoom [plr] [int]',{'minz'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		_PLAYERS[v].CameraMinZoomDistance = ARGS[2]
	end
end)

ADD_COMMAND('maxzoom','maxzoom [plr] [int]',{'maxz'},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		_PLAYERS[v].CameraMaxZoomDistance = ARGS[2]
	end
end)

ADD_COMMAND('age','age [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		NOTIFY(_PLAYERS[v].Name .. ' | ' .. _PLAYERS[v].AccountAge, 255, 255, 255)
	end
end)

ADD_COMMAND('hl','hl [plr] [r] [g] [b]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if PCHAR:FindFirstChild('Torso') then
			local HL = Instance.new('SpotLight', PCHAR.Torso) HL.Name = 'seth_hl' HL.Brightness = 5 HL.Range = 60
			if ARGS[2] and ARGS[3] and ARGS[4] then
				HL.Color = C3(ARGS[2], ARGS[3], ARGS[4])
			end
		end
	end
end)

ADD_COMMAND('unhl','unhl [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		if PCHAR:FindFirstChild('Torso') then
			for i,v in pairs(PCHAR.Torso:GetChildren()) do
				if v:IsA('SpotLight') and v.Name == 'seth_hl' then
					v:destroy()
				end
			end
		end
	end
end)

ADD_COMMAND('crash','crash [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		PCHAR.Torso.Anchored = true
		for i,v in pairs(PCHAR:GetChildren()) do
			if v:IsA('Humanoid') then
				for i = 1,10 do
					v.HipHeight = 1/0*0
				end
			end
		end
	end
end)

ADD_COMMAND('blockhead','blockhead [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
local boii = PCHAR.Head:FindFirstChildOfClass("SpecialMesh")
if boii then
maind:FireServer(workspace,boii)
end end end)


ADD_COMMAND('smite','smite [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		spawn(function()
			local function CastRay(A, B, C) local V = B - A return workspace:FindPartOnRayWithIgnoreList(Ray.new(A, V.unit * math.min(V.magnitude, 999)), C or {}, false, true) end
			
			local PP = PCHAR.PrimaryPart.Position - Vector3.new(0, 3, 0)
			local S = Instance.new('Sound', workspace) S.SoundId = 'rbxassetid://178090362' S.Volume = 1 S:Play() spawn(function() wait(7) S:destroy() end)
			local S,P2 = CastRay(PP, PP - Vector3.new(0, 9, 0), {PCHAR})
			
			local P1 = Instance.new('Part', game.Workspace)
			P1.BrickColor = BrickColor.new('Institutional white')
			P1.Material = 'Neon'
			P1.Transparency = 0.9
			P1.Anchored = true
			P1.CanCollide = false
			P1.Size = Vector3.new(0.2, 0.2, 0.2)
			P1.CFrame = CFrame.new((S and P2 or PP) + Vector3.new(0, 1e3, 0))
			Instance.new('BlockMesh', P1).Scale = Vector3.new(10, 10000, 10)
			
			local P2, P3, P4, P5 = P1:Clone(), P1:Clone(), P1:Clone(), P1:Clone()
			for i, v in next, {P2, P3, P4, P5} do i = i * 0.1 v.Parent, v.Size = P1, Vector3.new(0.2 + i, 0.2, 0.2 + i ) v.CFrame = P1.CFrame end wait(0.5) P1:destroy() PCHAR:BreakJoints()
		end)
	end
end)

ADD_COMMAND('skydive','skydive [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		spawn(function()
			for i = 0, 3 do
				if PCHAR then
					PCHAR.HumanoidRootPart.CFrame = PCHAR.HumanoidRootPart.CFrame + Vector3.new(0, 7500, 0)
				end
			end
		end)
	end
end)

ADD_COMMAND('message','message [string]',{'m'},
function(ARGS, SPEAKER)
	spawn(function()
		if MG then
			MESSAGE(GLS(false, 0))
		else
			LOAD_MESSAGE(GLS(false, 0))
		end
	end)
end)

ADD_COMMAND('control','control [plr]',{},
function(ARGS, SPEAKER)
	local PLAYERS = GET_PLAYER(ARGS[1], SPEAKER)
	for i,v in pairs(PLAYERS) do
		local PCHAR = _PLAYERS[v].Character
		local HB = Instance.new('HopperBin', LP.Backpack) HB.Name = _PLAYERS[v].Name
		local CONTROL_ENABLED = false
		local function CONTROL(P, V3)
			if CONTROL_ENABLED then
				if P.Character and P.Character:FindFirstChild('Humanoid') then
					P.Character.Humanoid:MoveTo(V3)
				end
			end
		end
		HB.Selected:connect(function(M)
			M.Button1Down:connect(function() CONTROL_ENABLED = true CONTROL(_PLAYERS:FindFirstChild(HB.Name), M.Hit.p) end)
			M.Button1Up:connect(function() CONTROL_ENABLED = false end)
		end)
	end
end)

-- / extra

ADD_COMMAND('gravity','gravity [int]',{},
function(ARGS, SPEAKER)
	workspace.Gravity = ARGS[1]
end)

ADD_COMMAND('fixlighting','fixlighting',{'fixl'},
function(ARGS, SPEAKER)
	FIX_LIGHTING()
end)

ADD_COMMAND('fixfog','fixfog',{'clrfog'},
function(ARGS, SPEAKER)
	_LIGHTING.FogColor = C3(191, 191, 191)
	_LIGHTING.FogEnd = 100000000
	_LIGHTING.FogStart = 0
end)

ADD_COMMAND('day','day',{},
function(ARGS, SPEAKER)
	_LIGHTING.TimeOfDay = 14
end)

ADD_COMMAND('night','night',{},
function(ARGS, SPEAKER)
	_LIGHTING.TimeOfDay = 24
end)

ADD_COMMAND('serverlock','serverlock',{'slock'},
function(ARGS, SPEAKER)
	SERVER_LOCKED = true
end)

ADD_COMMAND('unserverlock','unserverlock',{'unslock'},
function(ARGS, SPEAKER)
	SERVER_LOCKED = false
end)

ADD_COMMAND('fogend','fogend [int]',{},
function(ARGS, SPEAKER)
	_LIGHTING.FogEnd = ARGS[1]
end)

ADD_COMMAND('fogcolor','fogcolor [r] [g] [b]',{},
function(ARGS, SPEAKER)
	if ARGS[1] and ARGS[2] and ARGS[3] then
		_LIGHTING.FogColor = C3(ARGS[1], ARGS[2], ARGS[3])
	end
end)

ADD_COMMAND('noclip','noclip',{},
function(ARGS, SPEAKER)
	NOCLIP = true
	JESUSFLY = false
	SWIM = false
end)

ADD_COMMAND('clip','clip',{},
function(ARGS, SPEAKER)
	NOCLIP = false
end)

ADD_COMMAND('jesusfly','jesusfly',{},
function(ARGS, SPEAKER)
	NOCLIP = false
	JESUSFLY = true
	SWIM = false
end)

ADD_COMMAND('nojfly','nojfly',{},
function(ARGS, SPEAKER)
	JESUSFLY = false
end)

ADD_COMMAND('swim','swim',{},
function(ARGS, SPEAKER)
	NOCLIP = false
	JESUSFLY = false
	SWIM = true
end)

ADD_COMMAND('noswim','noswim',{},
function(ARGS, SPEAKER)
	SWIM = false
end)

ADD_COMMAND('fly','fly',{},
function(ARGS, SPEAKER)
	sFLY()
end)

ADD_COMMAND('unfly','unfly',{},
function(ARGS, SPEAKER)
	NOFLY()
end)

ADD_COMMAND('prefix','prefix [string]',{},
function(ARGS, SPEAKER)
	if ARGS[1] then
		C_PREFIX = ARGS[1]
		NOTIFY('Changed prefix to \'' .. ARGS[1] .. '\'', 255, 255, 255)
	end
end)

ADD_COMMAND('version','version',{},
function(ARGS, SPEAKER)
	NOTIFY('VERSION | ' .. VERSION, 255, 255, 255)
end)

ADD_COMMAND('fe','fe',{},
function(ARGS, SPEAKER)
	spawn(function()
		CHECK_FE()
	end)
end)

function OPEN_COMMANDS()
	SETH_MAIN.main.holder.Size = UDim2.new(1, 25, 12, 30)
	SETH_MAIN.main.holder.holders.search.Visible = true
end

function CLOSE_COMMANDS()
	SETH_MAIN.main.holder.holders.search.Visible = false
	SETH_MAIN.main.holder.Size = UDim2.new(1, 25, 12, 0)
end

function OPEN_TAB(TAB)
	if not _CORE:FindFirstChild('seth_main') then OPEN_MAIN() end
	for a,b in pairs(SETH_MAIN.main.holder.holders:GetChildren()) do
		if b.Name ~= TAB then
			b.Visible = false
		else
			b.Visible = true
		end
		if TAB ~= 'cmds' then
			CLOSE_COMMANDS()
		else
			OPEN_COMMANDS()
		end
	end
end

ADD_COMMAND('serverinfo','serverinfo',{'sinfo'},
function(ARGS, SPEAKER)
	OPEN_TAB('server')
end)

ADD_COMMAND('admins','admins',{},
function(ARGS, SPEAKER)
	OPEN_TAB('admins')
end)

ADD_COMMAND('cmds','cmds',{'commands'},
function(ARGS, SPEAKER)
	OPEN_TAB('cmds')
end)

ADD_COMMAND('bans','bans',{},
function(ARGS, SPEAKER)
	OPEN_TAB('bans')
end)

ADD_COMMAND('fun','fun',{},
function(ARGS, SPEAKER)
	OPEN_TAB('fun')
end)

ADD_COMMAND('changelog','changelog',{},
function(ARGS, SPEAKER)
	OPEN_TAB('changelog')
end)

ADD_COMMAND('credits','credits',{},
function(ARGS, SPEAKER)
	OPEN_TAB('credits')
end)

MOUSE.KeyDown:connect(function(key)
	if key:byte() == 29 then
		if not NOCLIP then
			ECOMMAND('noclip')
		elseif NOCLIP then
			ECOMMAND('clip')
		end
	elseif key:byte() == 30 then
		if not JESUSFLY then
			ECOMMAND('jesusfly')
		elseif JESUSFLY then
			ECOMMAND('nojfly')
		end
	end
end)

-- / after loaded

function CHECK_FE()
	if not workspace.FilteringEnabled then
		NOTIFY('bro lolo this is fd', 50, 255, 50)
	elseif workspace.FilteringEnabled then
		NOTIFY('Loaded successfully!', 255, 85, 0)
	end
end

CMD_BAR_H.bar:TweenPosition(UDim2.new(0, 0, 1, -50), 'InOut', 'Quad', 0.5, true)

local GOING_IN = true
CMD_BAR_H.bar.Changed:connect(function()
	if CMD_BAR_H.bar.Text ~= 'press ; to execute a command' and CMD_BAR_H.bar.Focused and not GOING_IN then
		if CMD_BAR_H.bar.Text ~= '' then
			if not CMD_BAR_H.bar.Text:find(' ') then
				CMD_BAR_H.bar.commands.Visible = true
				CMD_BAR_H.bar.commands:ClearAllChildren()
				CMD_BAR_H.bar.commands.CanvasSize = UDim2.new(0, 0, 0, 0)
				local Y_COMMANDS = 0
				for i,v in pairs(COMMANDS) do
					if v.N:find(CMD_BAR_H.bar.Text) then
						CMD_BAR_H.bar.commands:TweenSize(UDim2.new(1, 0, 1, -200), 'InOut', 'Quad', 0.2, true)
						CMD_BAR_H.bar.commands.CanvasSize = CMD_BAR_H.bar.commands.CanvasSize + UDim2.new(0, 0, 0, 20)
						local COMMANDS_C = CMD_BAR_H.bar.commands_ex:Clone()
						COMMANDS_C.Position = UDim2.new(0, 0, 0, Y_COMMANDS)
						COMMANDS_C.Visible = true
						COMMANDS_C.Text = ' ' .. v.D
						COMMANDS_C.Parent = CMD_BAR_H.bar.commands
						Y_COMMANDS = Y_COMMANDS + 20
					end
				end
			end
		else
			CMD_BAR_H.bar.commands:TweenSize(UDim2.new(1, 0, 0, 0), 'InOut', 'Quad', 0.2, true)
			CMD_BAR_H.bar.commands:ClearAllChildren()
			CMD_BAR_H.bar.commands.CanvasSize = UDim2.new(0, 0, 0, 0)
		end
	end
end)

CMD_BAR_H.bar.FocusLost:connect(function()
	GOING_IN = true
	if CMD_BAR_H.bar.Text ~= '' then
		spawn(function()
			ECOMMAND(CMD_BAR_H.bar.Text, LP)
		end)
	end
	CMD_BAR_H.bar.commands:ClearAllChildren()
	CMD_BAR_H.bar.commands.CanvasSize = UDim2.new(0, 0, 0, 0)
	CMD_BAR_H.bar.commands:TweenSize(UDim2.new(1, 0, 0, 0), 'InOut', 'Quad', 0.2, true)
	CMD_BAR_H.bar:TweenPosition(UDim2.new(0, -225, 1, -50), 'InOut', 'Quad', 0.5, true)
end)

MOUSE.KeyDown:connect(function(K)
	if K:byte() == 59 then
		GOING_IN = false
		CMD_BAR_H.bar:TweenPosition(UDim2.new(0, 0, 1, -50), 'InOut', 'Quad', 0.5, true)
		CMD_BAR_H.bar:CaptureFocus()
	end
end)

NOTIFY('Hello, ' .. _PLAYERS.LocalPlayer.Name, 255, 255, 255)
CHECK_FE()
end)

ClearWS.MouseButton1Click:connect(function()
	if workspace:FindFirstChild("GiveSystem") then
	e = workspace.GiveSystem.GiveItem
	elseif workspace:FindFirstChild("HandToCentre") then
	e = workspace.HandToCentre.GiveItem
	else
	warn("MODEL NOT FOUND")
	end
	
	local blacklist = {
	["HandToCentre"] = true;
	["GiveSystem"] = true;
	}
	
	
	for i,v in pairs(game.Workspace:children()) do
	if not blacklist[v.Name] then
		pcall(function() e:FireServer(workspace, v) end)
	end
	end
end)

Punish.MouseButton1Click:connect(function()
	if workspace:FindFirstChild("GiveSystem") then
	e = workspace.GiveSystem.GiveItem
	elseif workspace:FindFirstChild("HandToCentre") then
	e = workspace.HandToCentre.GiveItem
	else
	warn("MODEL NOT FOUND")
	end
	for i,plrname in pairs(GetPlayer(Username.Text))do
		pcall(function()e:FireServer(workspace, game:GetService("Players"):FindFirstChild(plrname).Character)end)
	end
end)
	


Character.MouseButton1Click:connect(function()
	if workspace:FindFirstChild("GiveSystem") then
e = workspace.GiveSystem.GiveItem
elseif workspace:FindFirstChild("HandToCentre") then
e = workspace.HandToCentre.GiveItem
else
warn("MODEL NOT FOUND")
end

local blacklist = {
["HandToCentre"] = true;
["GiveSystem"] = true;
}


for i,v in pairs(game:GetService"Players":GetPlayers()) do
 pcall(function() e:FireServer(workspace, v.Character.Humanoid) end)
end
end)

Thicc.MouseButton1Click:connect(function()
	local char = game:GetService'Players'.LocalPlayer.Character
	if workspace:FindFirstChild("GiveSystem") then
	e = workspace.GiveSystem.GiveItem
	elseif workspace:FindFirstChild("HandToCentre") then
	e = workspace.HandToCentre.GiveItem
	else
	warn("MODEL NOT FOUND")
	end
	for i,plrname in pairs(GetPlayer(Username.Text))do
		local blacklist = {
		["HandToCentre"] = true;
		["GiveSystem"] = true;
		}
		local randomperson = {}
		for i,obj in ipairs(plrname.Character:GetDescendants()) do
			if obj:IsA("CharacterMesh") then
				if obj.BodyPart ~= Enum.BodyPart.Head then
					pcall(function()e:FireServer(workspace,obj)end)
				end
			end
		end
	end
end)

Punish_All.MouseButton1Click:Connect(function()
	if workspace:FindFirstChild("GiveSystem") then
		e = workspace.GiveSystem.GiveItem
	elseif workspace:FindFirstChild("HandToCentre") then
		e = workspace.HandToCentre.GiveItem
	else
		warn("MODEL NOT FOUND")
	end
	for i,plr in ipairs(GetPlayer(Username.Text)) do
		pcall(function()e:FireServer(workspace,plr.Character.Humanoid)end)
	end
end)