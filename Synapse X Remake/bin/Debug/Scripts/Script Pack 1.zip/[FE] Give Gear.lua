--[[ GiveGear just clones the thing you want to give, and parents it to your backpack
so you can give yourself LocalScripts of the Vamp's abilities too. ]]--

local Amount = 2 --Amount of items you want
workspace.Events.GiveGear:FireServer(game.ReplicatedStorage.Store.Sabils.Morphine.Gear, Amount)