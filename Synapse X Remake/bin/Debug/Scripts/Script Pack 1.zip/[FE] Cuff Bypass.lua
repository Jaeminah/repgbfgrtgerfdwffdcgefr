game.Workspace.SECURITYGUARDNAME.Handcuffs.Parent = game.Workspace.YOURNAME

--How to use:
--Get cuffed by a security guard, make sure they have the handcuffs equipped.
--Replace "SECURITYGUARDNAME" and "YOURNAME" with the appropriate text
--Execute the script, you should get handcuffs in your hotbar.
--Equip the cuffs, and click the security guard, you should be free.
--If you get cuffed again, equip the cuffs again, and then click the security guard.
