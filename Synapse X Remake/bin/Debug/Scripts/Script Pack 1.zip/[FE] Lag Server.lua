while true do
game.Workspace.BasicCommand:FireServer(7, " ", 5.5, 1.5, true, "Pizza")
wait()