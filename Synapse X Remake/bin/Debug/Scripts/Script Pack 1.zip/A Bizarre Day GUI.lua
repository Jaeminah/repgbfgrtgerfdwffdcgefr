local DBAB = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")
local BlackBox = Instance.new("Frame")
local TextLabel_2 = Instance.new("TextLabel")
local TextLabel_3 = Instance.new("TextLabel")
local TextLabel_4 = Instance.new("TextLabel")
local TextButton = Instance.new("TextButton")
local TextButton_2 = Instance.new("TextButton")
local TextButton_3 = Instance.new("TextButton")
local TextBox2 = Instance.new("TextBox")
local TextButton_4 = Instance.new("TextButton")
local TutFrame2 = Instance.new("Frame")
local TextLabel_5 = Instance.new("TextLabel")
local TextLabel_6 = Instance.new("TextLabel")
local TextLabel_7 = Instance.new("TextLabel")
local TextLabel_8 = Instance.new("TextLabel")
local TextLabel_9 = Instance.new("TextLabel")
local TextLabel_10 = Instance.new("TextLabel")
local TextLabel_11 = Instance.new("TextLabel")
local TextLabel_12 = Instance.new("TextLabel")
local TextLabel_13 = Instance.new("TextLabel")
local TutFrame = Instance.new("Frame")
local TextLabel_14 = Instance.new("TextLabel")
local TextLabel_15 = Instance.new("TextLabel")
local TextLabel_16 = Instance.new("TextLabel")
local TextLabel_17 = Instance.new("TextLabel")
local TextLabel_18 = Instance.new("TextLabel")
local TextLabel_19 = Instance.new("TextLabel")
local TextLabel_20 = Instance.new("TextLabel")
local TextLabel_21 = Instance.new("TextLabel")
local TextLabel_22 = Instance.new("TextLabel")
local TextLabel_23 = Instance.new("TextLabel")
local TextLabel_24 = Instance.new("TextLabel")
local TextLabel_25 = Instance.new("TextLabel")
local TextButton_5 = Instance.new("TextButton")
local TextButton_6 = Instance.new("TextButton")
local TextButton_7 = Instance.new("TextButton")
local TextButton_8 = Instance.new("TextButton")
local TextButton_9 = Instance.new("TextButton")
local TextButton_10 = Instance.new("TextButton")
local TextButton_11 = Instance.new("TextButton")
local TextButton_12 = Instance.new("TextButton")
local TextBox = Instance.new("TextBox")
local TextButton_13 = Instance.new("TextButton")
--Properties:
DBAB.Name = "DBAB"
DBAB.Parent = game.CoreGui

Frame.Parent = DBAB
Frame.BackgroundColor3 = Color3.new(1, 1, 0.4)
Frame.BackgroundTransparency = 0.30000001192093
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0.400638342, 0, 0.278142214, 0)
Frame.Size = UDim2.new(0, 169, 0, 285)

TextLabel.Parent = Frame
TextLabel.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel.BackgroundTransparency = 1
TextLabel.Position = UDim2.new(0.183431938, 0, -0.196491227, 0)
TextLabel.Size = UDim2.new(0, 106, 0, 22)
TextLabel.Font = Enum.Font.Gotham
TextLabel.Text = "A Bizarre"
TextLabel.TextColor3 = Color3.new(0.952941, 0.27451, 1)
TextLabel.TextSize = 24

BlackBox.Name = "BlackBox"
BlackBox.Parent = Frame
BlackBox.BackgroundColor3 = Color3.new(1, 0.666667, 0)
BlackBox.BorderSizePixel = 0
BlackBox.Position = UDim2.new(-0.00394489337, 0, 0.731593072, 0)
BlackBox.Size = UDim2.new(0, 169, 0, 76)
BlackBox.Style = Enum.FrameStyle.DropShadow

TextLabel_2.Parent = Frame
TextLabel_2.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_2.BackgroundTransparency = 1
TextLabel_2.Position = UDim2.new(0.183431923, 0, -0.119298242, 0)
TextLabel_2.Size = UDim2.new(0, 106, 0, 22)
TextLabel_2.Font = Enum.Font.Gotham
TextLabel_2.Text = "Day"
TextLabel_2.TextColor3 = Color3.new(0, 1, 0.113725)
TextLabel_2.TextSize = 24

TextLabel_3.Parent = Frame
TextLabel_3.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_3.BackgroundTransparency = 1
TextLabel_3.Position = UDim2.new(0.183431953, 0, -0.196491227, 0)
TextLabel_3.Size = UDim2.new(0, 114, 0, 22)
TextLabel_3.Font = Enum.Font.Gotham
TextLabel_3.Text = "A Bizarre"
TextLabel_3.TextColor3 = Color3.new(0.952941, 0.27451, 1)
TextLabel_3.TextSize = 24
TextLabel_3.TextTransparency = 0.60000002384186

TextLabel_4.Parent = Frame
TextLabel_4.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_4.BackgroundTransparency = 1
TextLabel_4.Position = UDim2.new(0.20710057, 0, -0.119298242, 0)
TextLabel_4.Size = UDim2.new(0, 106, 0, 22)
TextLabel_4.Font = Enum.Font.Gotham
TextLabel_4.Text = "Day"
TextLabel_4.TextColor3 = Color3.new(0, 1, 0.113725)
TextLabel_4.TextSize = 24
TextLabel_4.TextTransparency = 0.60000002384186

TextButton.Parent = Frame
TextButton.BackgroundColor3 = Color3.new(1, 1, 1)
TextButton.BorderSizePixel = 0
TextButton.Position = UDim2.new(0.284023672, 0, 0, 0)
TextButton.Size = UDim2.new(0, 67, 0, 19)
TextButton.Style = Enum.ButtonStyle.RobloxRoundDropdownButton
TextButton.Font = Enum.Font.Fantasy
TextButton.Text = "Cash"
TextButton.TextColor3 = Color3.new(0.172549, 0.941177, 0)
TextButton.TextSize = 14

TextButton_2.Parent = Frame
TextButton_2.BackgroundColor3 = Color3.new(1, 1, 1)
TextButton_2.BackgroundTransparency = 1
TextButton_2.BorderSizePixel = 0
TextButton_2.Position = UDim2.new(0.177514732, 0, 0.884210527, 0)
TextButton_2.Size = UDim2.new(0, 106, 0, 19)
TextButton_2.Font = Enum.Font.Fantasy
TextButton_2.Text = "Close"
TextButton_2.TextColor3 = Color3.new(0.976471, 0, 0)
TextButton_2.TextSize = 20

TextButton_3.Parent = Frame
TextButton_3.BackgroundColor3 = Color3.new(1, 1, 1)
TextButton_3.BorderSizePixel = 0
TextButton_3.Position = UDim2.new(0.177514791, 0, 0.0982456133, 0)
TextButton_3.Size = UDim2.new(0, 54, 0, 19)
TextButton_3.Style = Enum.ButtonStyle.RobloxRoundDropdownButton
TextButton_3.Font = Enum.Font.Fantasy
TextButton_3.Text = "Change"
TextButton_3.TextColor3 = Color3.new(0.941177, 0.0235294, 0.423529)
TextButton_3.TextSize = 14

TextBox2.Name = "TextBox2"
TextBox2.Parent = Frame
TextBox2.BackgroundColor3 = Color3.new(1, 1, 1)
TextBox2.BackgroundTransparency = 1
TextBox2.Position = UDim2.new(0.514793098, 0, 0.638596475, 0)
TextBox2.Size = UDim2.new(0, 76, 0, 19)
TextBox2.Font = Enum.Font.SourceSans
TextBox2.PlaceholderColor3 = Color3.new(0.156863, 0.227451, 0.180392)
TextBox2.PlaceholderText = "Name Here"
TextBox2.Text = ""
TextBox2.TextColor3 = Color3.new(0, 0, 0)
TextBox2.TextSize = 14

TextButton_4.Parent = Frame
TextButton_4.BackgroundColor3 = Color3.new(1, 1, 1)
TextButton_4.BorderSizePixel = 0
TextButton_4.Position = UDim2.new(0.0118342843, 0, 0.0982456207, 0)
TextButton_4.Size = UDim2.new(0, 33, 0, 19)
TextButton_4.Style = Enum.ButtonStyle.RobloxRoundDropdownButton
TextButton_4.Font = Enum.Font.Fantasy
TextButton_4.Text = "List"
TextButton_4.TextColor3 = Color3.new(0.941177, 0.0235294, 0.423529)
TextButton_4.TextSize = 14

TutFrame2.Name = "TutFrame2"
TutFrame2.Parent = Frame
TutFrame2.BackgroundColor3 = Color3.new(1, 0.666667, 0)
TutFrame2.BorderSizePixel = 0
TutFrame2.Position = UDim2.new(-0.962524772, 0, -0.00174025155, 0)
TutFrame2.Size = UDim2.new(0, 162, 0, 278)
TutFrame2.Visible = false
TutFrame2.Style = Enum.FrameStyle.DropShadow

TextLabel_5.Parent = TutFrame2
TextLabel_5.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_5.BackgroundTransparency = 1
TextLabel_5.Position = UDim2.new(0.220885411, 0, -0.00696256757, 0)
TextLabel_5.Size = UDim2.new(0, 80, 0, 22)
TextLabel_5.Font = Enum.Font.Gotham
TextLabel_5.Text = "ID's"
TextLabel_5.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_5.TextSize = 15

TextLabel_6.Parent = TutFrame2
TextLabel_6.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_6.BackgroundTransparency = 1
TextLabel_6.Position = UDim2.new(0.220885411, 0, 0.0757712424, 0)
TextLabel_6.Size = UDim2.new(0, 80, 0, 22)
TextLabel_6.Font = Enum.Font.Gotham
TextLabel_6.Text = "12 - SPOH"
TextLabel_6.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_6.TextSize = 15

TextLabel_7.Parent = TutFrame2
TextLabel_7.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_7.BackgroundTransparency = 1
TextLabel_7.Position = UDim2.new(0.220885411, 0, 0.158505037, 0)
TextLabel_7.Size = UDim2.new(0, 80, 0, 22)
TextLabel_7.Font = Enum.Font.Gotham
TextLabel_7.Text = "13 - TWOH"
TextLabel_7.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_7.TextSize = 15

TextLabel_8.Parent = TutFrame2
TextLabel_8.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_8.BackgroundTransparency = 1
TextLabel_8.Position = UDim2.new(0.220885411, 0, 0.237641737, 0)
TextLabel_8.Size = UDim2.new(0, 80, 0, 22)
TextLabel_8.Font = Enum.Font.Gotham
TextLabel_8.Text = "14 - One More Time"
TextLabel_8.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_8.TextSize = 15

TextLabel_9.Parent = TutFrame2
TextLabel_9.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_9.BackgroundTransparency = 1
TextLabel_9.Position = UDim2.new(0.220885411, 0, 0.316778421, 0)
TextLabel_9.Size = UDim2.new(0, 80, 0, 22)
TextLabel_9.Font = Enum.Font.Gotham
TextLabel_9.Text = "15 - Sword"
TextLabel_9.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_9.TextSize = 15

TextLabel_10.Parent = TutFrame2
TextLabel_10.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_10.BackgroundTransparency = 1
TextLabel_10.Position = UDim2.new(0.220885411, 0, 0.403109372, 0)
TextLabel_10.Size = UDim2.new(0, 80, 0, 22)
TextLabel_10.Font = Enum.Font.Gotham
TextLabel_10.Text = "16 - Rice Farmer"
TextLabel_10.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_10.TextSize = 15

TextLabel_11.Parent = TutFrame2
TextLabel_11.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_11.BackgroundTransparency = 1
TextLabel_11.Position = UDim2.new(0.220885411, 0, 0.482246041, 0)
TextLabel_11.Size = UDim2.new(0, 80, 0, 22)
TextLabel_11.Font = Enum.Font.Gotham
TextLabel_11.Text = "17 - Samurai"
TextLabel_11.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_11.TextSize = 15

TextLabel_12.Parent = TutFrame2
TextLabel_12.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_12.BackgroundTransparency = 1
TextLabel_12.Position = UDim2.new(0.220885411, 0, 0.561382711, 0)
TextLabel_12.Size = UDim2.new(0, 80, 0, 22)
TextLabel_12.Font = Enum.Font.Gotham
TextLabel_12.Text = "1003 - TWAU (Buffed)"
TextLabel_12.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_12.TextSize = 15

TextLabel_13.Parent = TutFrame2
TextLabel_13.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_13.BackgroundTransparency = 1
TextLabel_13.Position = UDim2.new(0.220885411, 0, 0.640519381, 0)
TextLabel_13.Size = UDim2.new(0, 80, 0, 22)
TextLabel_13.Font = Enum.Font.Gotham
TextLabel_13.Text = "1004 - GER (Buffed)"
TextLabel_13.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_13.TextSize = 15

TutFrame.Name = "TutFrame"
TutFrame.Parent = Frame
TutFrame.BackgroundColor3 = Color3.new(1, 0.666667, 0)
TutFrame.BorderSizePixel = 0
TutFrame.Position = UDim2.new(-1.92110467, 0, -0.00174025155, 0)
TutFrame.Size = UDim2.new(0, 162, 0, 278)
TutFrame.Visible = false
TutFrame.Style = Enum.FrameStyle.DropShadow

TextLabel_14.Parent = TutFrame
TextLabel_14.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_14.BackgroundTransparency = 1
TextLabel_14.Position = UDim2.new(0.220885411, 0, -0.00696256757, 0)
TextLabel_14.Size = UDim2.new(0, 80, 0, 22)
TextLabel_14.Font = Enum.Font.Gotham
TextLabel_14.Text = "ID's"
TextLabel_14.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_14.TextSize = 15

TextLabel_15.Parent = TutFrame
TextLabel_15.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_15.BackgroundTransparency = 1
TextLabel_15.Position = UDim2.new(0.220885411, 0, 0.0613827556, 0)
TextLabel_15.Size = UDim2.new(0, 80, 0, 22)
TextLabel_15.Font = Enum.Font.Gotham
TextLabel_15.Text = "1 - N/A"
TextLabel_15.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_15.TextSize = 15

TextLabel_16.Parent = TutFrame
TextLabel_16.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_16.BackgroundTransparency = 1
TextLabel_16.Position = UDim2.new(0.220885411, 0, 0.14051944, 0)
TextLabel_16.Size = UDim2.new(0, 80, 0, 22)
TextLabel_16.Font = Enum.Font.Gotham
TextLabel_16.Text = "2  - Star Platinum"
TextLabel_16.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_16.TextSize = 15

TextLabel_17.Parent = TutFrame
TextLabel_17.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_17.BackgroundTransparency = 1
TextLabel_17.Position = UDim2.new(0.220885411, 0, 0.21965614, 0)
TextLabel_17.Size = UDim2.new(0, 80, 0, 22)
TextLabel_17.Font = Enum.Font.Gotham
TextLabel_17.Text = "3 - Star Platinum TW"
TextLabel_17.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_17.TextSize = 15

TextLabel_18.Parent = TutFrame
TextLabel_18.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_18.BackgroundTransparency = 1
TextLabel_18.Position = UDim2.new(0.220885411, 0, 0.298792839, 0)
TextLabel_18.Size = UDim2.new(0, 80, 0, 22)
TextLabel_18.Font = Enum.Font.Gotham
TextLabel_18.Text = "4 - The World"
TextLabel_18.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_18.TextSize = 15

TextLabel_19.Parent = TutFrame
TextLabel_19.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_19.BackgroundTransparency = 1
TextLabel_19.Position = UDim2.new(0.220885411, 0, 0.377929538, 0)
TextLabel_19.Size = UDim2.new(0, 80, 0, 22)
TextLabel_19.Font = Enum.Font.Gotham
TextLabel_19.Text = "5 - Crazy Diamond"
TextLabel_19.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_19.TextSize = 15

TextLabel_20.Parent = TutFrame
TextLabel_20.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_20.BackgroundTransparency = 1
TextLabel_20.Position = UDim2.new(0.220885411, 0, 0.47145474, 0)
TextLabel_20.Size = UDim2.new(0, 80, 0, 22)
TextLabel_20.Font = Enum.Font.Gotham
TextLabel_20.Text = "6 - Killer Queen"
TextLabel_20.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_20.TextSize = 15

TextLabel_21.Parent = TutFrame
TextLabel_21.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_21.BackgroundTransparency = 1
TextLabel_21.Position = UDim2.new(0.220885411, 0, 0.550591409, 0)
TextLabel_21.Size = UDim2.new(0, 80, 0, 22)
TextLabel_21.Font = Enum.Font.Gotham
TextLabel_21.Text = "7 - Gold Experience"
TextLabel_21.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_21.TextSize = 15

TextLabel_22.Parent = TutFrame
TextLabel_22.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_22.BackgroundTransparency = 1
TextLabel_22.Position = UDim2.new(0.220885411, 0, 0.629728079, 0)
TextLabel_22.Size = UDim2.new(0, 80, 0, 22)
TextLabel_22.Font = Enum.Font.Gotham
TextLabel_22.Text = "8 - GER"
TextLabel_22.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_22.TextSize = 15

TextLabel_23.Parent = TutFrame
TextLabel_23.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_23.BackgroundTransparency = 1
TextLabel_23.Position = UDim2.new(0.220885411, 0, 0.708864748, 0)
TextLabel_23.Size = UDim2.new(0, 80, 0, 22)
TextLabel_23.Font = Enum.Font.Gotham
TextLabel_23.Text = "9 - King Crimson"
TextLabel_23.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_23.TextSize = 15

TextLabel_24.Parent = TutFrame
TextLabel_24.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_24.BackgroundTransparency = 1
TextLabel_24.Position = UDim2.new(0.220885411, 0, 0.788001418, 0)
TextLabel_24.Size = UDim2.new(0, 80, 0, 22)
TextLabel_24.Font = Enum.Font.Gotham
TextLabel_24.Text = "10 - Doppio's KC"
TextLabel_24.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_24.TextSize = 15

TextLabel_25.Parent = TutFrame
TextLabel_25.BackgroundColor3 = Color3.new(1, 1, 1)
TextLabel_25.BackgroundTransparency = 1
TextLabel_25.Position = UDim2.new(0.220885411, 0, 0.867138088, 0)
TextLabel_25.Size = UDim2.new(0, 80, 0, 22)
TextLabel_25.Font = Enum.Font.Gotham
TextLabel_25.Text = "11 - The World (AU)"
TextLabel_25.TextColor3 = Color3.new(0.14902, 0.0392157, 1)
TextLabel_25.TextSize = 15

TextButton_5.Parent = Frame
TextButton_5.BackgroundColor3 = Color3.new(1, 1, 1)
TextButton_5.BorderSizePixel = 0
TextButton_5.Position = UDim2.new(0.177514791, 0, 0.19298245, 0)
TextButton_5.Size = UDim2.new(0, 106, 0, 19)
TextButton_5.Style = Enum.ButtonStyle.RobloxRoundDropdownButton
TextButton_5.Font = Enum.Font.Fantasy
TextButton_5.Text = "Select Menu"
TextButton_5.TextColor3 = Color3.new(0.866667, 0.0196078, 0.941177)
TextButton_5.TextSize = 14

TextButton_6.Parent = Frame
TextButton_6.BackgroundColor3 = Color3.new(1, 1, 1)
TextButton_6.BorderSizePixel = 0
TextButton_6.Position = UDim2.new(0.284023672, 0, 0.280701756, 0)
TextButton_6.Size = UDim2.new(0, 67, 0, 19)
TextButton_6.Style = Enum.ButtonStyle.RobloxRoundDropdownButton
TextButton_6.Font = Enum.Font.Fantasy
TextButton_6.Text = "Inf Block"
TextButton_6.TextColor3 = Color3.new(0.141176, 0.0823529, 0.941177)
TextButton_6.TextSize = 14

TextButton_7.Parent = Frame
TextButton_7.BackgroundColor3 = Color3.new(1, 1, 1)
TextButton_7.BorderSizePixel = 0
TextButton_7.Position = UDim2.new(0.284023672, 0, 0.368421048, 0)
TextButton_7.Size = UDim2.new(0, 67, 0, 19)
TextButton_7.Style = Enum.ButtonStyle.RobloxRoundDropdownButton
TextButton_7.Font = Enum.Font.Fantasy
TextButton_7.Text = "Inf Dodge"
TextButton_7.TextColor3 = Color3.new(0.941177, 0.843137, 0.0823529)
TextButton_7.TextSize = 14

TextButton_8.Parent = Frame
TextButton_8.BackgroundColor3 = Color3.new(1, 1, 1)
TextButton_8.BorderSizePixel = 0
TextButton_8.Position = UDim2.new(0.0118343234, 0, 0.44561404, 0)
TextButton_8.Size = UDim2.new(0, 67, 0, 19)
TextButton_8.Style = Enum.ButtonStyle.RobloxRoundDropdownButton
TextButton_8.Font = Enum.Font.Fantasy
TextButton_8.Text = "Arrow"
TextButton_8.TextColor3 = Color3.new(0.941177, 0.843137, 0.0823529)
TextButton_8.TextSize = 14

TextButton_9.Parent = Frame
TextButton_9.BackgroundColor3 = Color3.new(1, 1, 1)
TextButton_9.BorderSizePixel = 0
TextButton_9.Position = UDim2.new(0.544378698, 0, 0.44561404, 0)
TextButton_9.Size = UDim2.new(0, 67, 0, 19)
TextButton_9.Style = Enum.ButtonStyle.RobloxRoundDropdownButton
TextButton_9.Font = Enum.Font.Fantasy
TextButton_9.Text = "Rokakaka"
TextButton_9.TextColor3 = Color3.new(0.941177, 0.00392157, 0.0196078)
TextButton_9.TextSize = 14

TextButton_10.Parent = Frame
TextButton_10.BackgroundColor3 = Color3.new(1, 1, 1)
TextButton_10.BorderSizePixel = 0
TextButton_10.Position = UDim2.new(0.0059171319, 0, 0.533333361, 0)
TextButton_10.Size = UDim2.new(0, 67, 0, 19)
TextButton_10.Style = Enum.ButtonStyle.RobloxRoundDropdownButton
TextButton_10.Font = Enum.Font.Fantasy
TextButton_10.Text = "Req. Arrow"
TextButton_10.TextColor3 = Color3.new(0.0392157, 0.941177, 0.32549)
TextButton_10.TextSize = 14

TextButton_11.Parent = Frame
TextButton_11.BackgroundColor3 = Color3.new(1, 1, 1)
TextButton_11.BorderSizePixel = 0
TextButton_11.Position = UDim2.new(0.544378698, 0, 0.533333361, 0)
TextButton_11.Size = UDim2.new(0, 67, 0, 19)
TextButton_11.Style = Enum.ButtonStyle.RobloxRoundDropdownButton
TextButton_11.Font = Enum.Font.Fantasy
TextButton_11.Text = "Dio's Diary"
TextButton_11.TextColor3 = Color3.new(0.941177, 0.745098, 0.027451)
TextButton_11.TextSize = 14

TextButton_12.Parent = Frame
TextButton_12.BackgroundColor3 = Color3.new(1, 1, 1)
TextButton_12.BorderSizePixel = 0
TextButton_12.Position = UDim2.new(0.408284009, 0, 0.487719327, 0)
TextButton_12.Size = UDim2.new(0, 24, 0, 19)
TextButton_12.Style = Enum.ButtonStyle.RobloxRoundDropdownButton
TextButton_12.Font = Enum.Font.Fantasy
TextButton_12.Text = "H"
TextButton_12.TextColor3 = Color3.new(0.941177, 0.745098, 0.027451)
TextButton_12.TextSize = 14

TextBox.Parent = Frame
TextBox.BackgroundColor3 = Color3.new(1, 1, 1)
TextBox.BackgroundTransparency = 1
TextBox.Position = UDim2.new(0.497041613, 0, 0.0982456133, 0)
TextBox.Size = UDim2.new(0, 76, 0, 19)
TextBox.Font = Enum.Font.SourceSans
TextBox.PlaceholderColor3 = Color3.new(0.698039, 0.0352941, 0.247059)
TextBox.PlaceholderText = "ID Here"
TextBox.Text = ""
TextBox.TextColor3 = Color3.new(0, 0, 0)
TextBox.TextSize = 14

TextButton_13.Parent = Frame
TextButton_13.BackgroundColor3 = Color3.new(1, 1, 1)
TextButton_13.BorderSizePixel = 0
TextButton_13.Position = UDim2.new(0.0118343197, 0, 0.638596475, 0)
TextButton_13.Size = UDim2.new(0, 73, 0, 19)
TextButton_13.Style = Enum.ButtonStyle.RobloxRoundDropdownButton
TextButton_13.Font = Enum.Font.Fantasy
TextButton_13.Text = "Kill User"
TextButton_13.TextColor3 = Color3.new(0.941177, 0, 0.0156863)
TextButton_13.TextSize = 14
-- Scripts:
function SCRIPT_WLTS73_FAKESCRIPT() -- Frame.DragProperties 
	local script = Instance.new('LocalScript')
	script.Parent = Frame
	local UserInputService = game:GetService("UserInputService")
	
	
	--stop scrounging through me guis fatt
	local gui = script.Parent
	
	local dragging
	local dragInput
	local dragStart
	local startPos
	
	local function update(input)
		local delta = input.Position - dragStart
		gui.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
	end
	
	gui.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			dragging = true
			dragStart = input.Position
			startPos = gui.Position
			
			input.Changed:Connect(function()
				if input.UserInputState == Enum.UserInputState.End then
					dragging = false
				end
			end)
		end
	end)
	
	gui.InputChanged:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
			dragInput = input
		end
	end)
	
	UserInputService.InputChanged:Connect(function(input)
		if input == dragInput and dragging then
			update(input)
		end
	end)

end
coroutine.resume(coroutine.create(SCRIPT_WLTS73_FAKESCRIPT))
function SCRIPT_PLXV80_FAKESCRIPT() -- TextButton.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = TextButton
	script.Parent.MouseButton1Click:Connect(function()
	 
		local A_1 = "10000000"
		local Event = game:GetService("ReplicatedStorage").Money
		Event:FireServer(A_1)
	
	end)

end
coroutine.resume(coroutine.create(SCRIPT_PLXV80_FAKESCRIPT))
function SCRIPT_JBZW76_FAKESCRIPT() -- TextButton_2.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = TextButton_2
	script.Parent.MouseButton1Click:Connect(function()
	_G.On = false
	script.Parent.Parent.Parent:Destroy()
	end)
	

end
coroutine.resume(coroutine.create(SCRIPT_JBZW76_FAKESCRIPT))
function SCRIPT_QNYF65_FAKESCRIPT() -- TextButton_3.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = TextButton_3
	script.Parent.MouseButton1Click:Connect(function()
		game.Players.LocalPlayer.Data.Stand.Value = script.Parent.Parent.TextBox.Text
	end)

end
coroutine.resume(coroutine.create(SCRIPT_QNYF65_FAKESCRIPT))
function SCRIPT_RMRI71_FAKESCRIPT() -- TextButton_4.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = TextButton_4
	script.Parent.MouseButton1Click:Connect(function()
		if script.Parent:FindFirstChild("yes") then
		else
			local toggle = Instance.new("BoolValue")
			toggle.Parent = script.Parent
			toggle.Name = "yes"
		end
		local tut1 = script.Parent.Parent.TutFrame
		local tut2 = script.Parent.Parent.TutFrame2
		local toggle = script.Parent.yes
		if toggle.Value == true then
			toggle.Value = false
			tut1.Visible = false
			tut2.Visible = false
		elseif toggle.Value == false then
			toggle.Value = true
			tut1.Visible = true
			tut2.Visible = true
		end
	end)

end
coroutine.resume(coroutine.create(SCRIPT_RMRI71_FAKESCRIPT))
function SCRIPT_PTMT73_FAKESCRIPT() -- TextButton_5.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = TextButton_5
	script.Parent.MouseButton1Click:Connect(function()
		game.Players.LocalPlayer.PlayerGui.Select.Enabled = true
	end)

end
coroutine.resume(coroutine.create(SCRIPT_PTMT73_FAKESCRIPT))
function SCRIPT_CXNU77_FAKESCRIPT() -- TextButton_6.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = TextButton_6
	script.Parent.MouseButton1Click:Connect(function()
		local yes = true
		game.ReplicatedStorage.Block:FireServer(yes)
	end)

end
coroutine.resume(coroutine.create(SCRIPT_CXNU77_FAKESCRIPT))
function SCRIPT_UXPC86_FAKESCRIPT() -- TextButton_7.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = TextButton_7
	script.Parent.MouseButton1Click:Connect(function()
		game.ReplicatedStorage.Epitaph:FireServer()
	end)

end
coroutine.resume(coroutine.create(SCRIPT_UXPC86_FAKESCRIPT))
function SCRIPT_CFJS70_FAKESCRIPT() -- TextButton_8.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = TextButton_8
	script.Parent.MouseButton1Click:Connect(function()
		local boyy = game.Lighting.Arrow:Clone()
		boyy.Parent = game.Players.LocalPlayer.Backpack
		boyy.Handle.Anchored = false
	end)

end
coroutine.resume(coroutine.create(SCRIPT_CFJS70_FAKESCRIPT))
function SCRIPT_BWFA81_FAKESCRIPT() -- TextButton_9.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = TextButton_9
	script.Parent.MouseButton1Click:Connect(function()
		local boyy = game.Lighting["Rokakaka Fruit"]:Clone()
		boyy.Parent = game.Players.LocalPlayer.Backpack
		boyy.Handle.Anchored = false
	end)

end
coroutine.resume(coroutine.create(SCRIPT_BWFA81_FAKESCRIPT))
function SCRIPT_QGXD76_FAKESCRIPT() -- TextButton_10.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = TextButton_10
	script.Parent.MouseButton1Click:Connect(function()
		local boyy = game.Lighting["Requiem Arrow"]:Clone()
		boyy.Parent = game.Players.LocalPlayer.Backpack
		boyy.Handle.Anchored = false
	end)

end
coroutine.resume(coroutine.create(SCRIPT_QGXD76_FAKESCRIPT))
function SCRIPT_XADM69_FAKESCRIPT() -- TextButton_11.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = TextButton_11
	script.Parent.MouseButton1Click:Connect(function()
		local boyy = game.Lighting["DIO's Diary"]:Clone()
		boyy.Parent = game.Players.LocalPlayer.Backpack
		boyy.Handle.Anchored = false
	end)

end
coroutine.resume(coroutine.create(SCRIPT_XADM69_FAKESCRIPT))
function SCRIPT_SPUE77_FAKESCRIPT() -- TextButton_12.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = TextButton_12
	script.Parent.MouseButton1Click:Connect(function()
		game.ReplicatedStorage.TWAUKnife:FireServer()
	end)

end
coroutine.resume(coroutine.create(SCRIPT_SPUE77_FAKESCRIPT))
function SCRIPT_BCFM79_FAKESCRIPT() -- TextButton_13.LocalScript 
	local script = Instance.new('LocalScript')
	script.Parent = TextButton_13
	script.Parent.MouseButton1Click:Connect(function()
		local targetuser = script.Parent.Parent.TextBox2.Text
		if game.Workspace:FindFirstChild(targetuser) then
			local A_1 = game:GetService("Workspace"):FindFirstChild(targetuser).Humanoid
			local A_2 = game.Workspace:FindFirstChild(targetuser).Torso.CFrame
			local A_3 = 1000000000000000
			local A_4 = 0.25
			local A_5 = Vector3.new(9.97749424, 8.83126745e-07, -0.670526147)
			local A_6 = "rbxassetid://241837157"
			local A_7 = 0.075
			local A_8 = Color3.new(255, 255, 255)
			local A_9 = "rbxassetid://260430079"
			local A_10 = 1
			local A_11 = 2
			local Event = game:GetService("ReplicatedStorage").Damage
			Event:FireServer(A_1, A_2, A_3, A_4, A_5, A_6, A_7, A_8, A_9, A_10, A_11)
		end
	end)

end
coroutine.resume(coroutine.create(SCRIPT_BCFM79_FAKESCRIPT))