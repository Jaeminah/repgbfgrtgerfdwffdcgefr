-- Farewell Infortality.
-- Version: 2.82
-- Instances:
local ScreenGui = Instance.new("ScreenGui")
local LoginFrame = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")
local PirateOn = Instance.new("TextButton")
local Frame = Instance.new("Frame")
local PirateOff = Instance.new("TextButton")
local BruteOn = Instance.new("TextButton")
local TpSpamOff = Instance.new("TextButton")
local BruteOff = Instance.new("TextButton")
local SnowBanditsOff = Instance.new("TextButton")
local SnowBanditsOn = Instance.new("TextButton")
local SnowManOn = Instance.new("TextButton")
local SnowManOff = Instance.new("TextButton")
local YetiOn = Instance.new("TextButton")
local YetiOff = Instance.new("TextButton")
local SkyBanditsOn = Instance.new("TextButton")
local SkyBanditsOff = Instance.new("TextButton")
local DarkMasterOn = Instance.new("TextButton")
local DarkMasterOff = Instance.new("TextButton")
local DesertBanditOn = Instance.new("TextButton")
local DesertBanditOff = Instance.new("TextButton")
local DesertOfficerOn = Instance.new("TextButton")
local DesertOfficerOn_2 = Instance.new("TextButton")
local WardenOn = Instance.new("TextButton")
local WardenOff = Instance.new("TextButton")
local ChiefWardenOn = Instance.new("TextButton")
local ChiefWardenOff = Instance.new("TextButton")
local FlamingoOn = Instance.new("TextButton")
local FlamingoOff = Instance.new("TextButton")
local ScrollingFrame = Instance.new("ScrollingFrame")
local Frame_2 = Instance.new("Frame")
local Frame_3 = Instance.new("Frame")
local TextButton = Instance.new("TextButton")
local TextButton_2 = Instance.new("TextButton")
local TextButton_3 = Instance.new("TextButton")
local TextButton_4 = Instance.new("TextButton")
local TextButton_5 = Instance.new("TextButton")
local TextButton_6 = Instance.new("TextButton")
local TextButton_7 = Instance.new("TextButton")
local TextButton_8 = Instance.new("TextButton")
local TextButton_9 = Instance.new("TextButton")
local TextButton_10 = Instance.new("TextButton")
local AutoDFTpOn = Instance.new("TextButton")
local AutoDFTpOff = Instance.new("TextButton")
local ChestTpOn = Instance.new("TextButton")
local ChestTpOff = Instance.new("TextButton")
local Safe = Instance.new("TextButton")
local Anti = Instance.new("TextButton")
local TpSpamOn = Instance.new("TextButton")
local Tp = Instance.new("TextButton")
local name = Instance.new("TextBox")
local GorillaOff = Instance.new("TextButton")
local BanditsOn = Instance.new("TextButton")
local BanditsOff = Instance.new("TextButton")
local MonkeysOn = Instance.new("TextButton")
local MonkeysOff = Instance.new("TextButton")
local GorillaOn = Instance.new("TextButton")
local MarineCaptainOn = Instance.new("TextButton")
local MarineCaptainOff = Instance.new("TextButton")
local ViceAdmiralOn = Instance.new("TextButton")
local ViceAdmiralOff = Instance.new("TextButton")
--Properties:
ScreenGui.Parent = game.CoreGui
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

LoginFrame.Name = "LoginFrame"
LoginFrame.Parent = ScreenGui
LoginFrame.Active = true
LoginFrame.BackgroundColor3 = Color3.new(0.117647, 0.117647, 0.117647)
LoginFrame.BorderColor3 = Color3.new(0.117647, 0.117647, 0.117647)
LoginFrame.Position = UDim2.new(0.42592594, 0, 0.0677290857, 0)
LoginFrame.Size = UDim2.new(0, 361, 0, 357)
LoginFrame.Draggable = true

TextLabel.Parent = LoginFrame
TextLabel.BackgroundColor3 = Color3.new(0.117647, 0.117647, 0.117647)
TextLabel.BorderColor3 = Color3.new(0.117647, 0.117647, 0.117647)
TextLabel.Size = UDim2.new(0, 361, 0, 52)
TextLabel.Font = Enum.Font.SourceSans
TextLabel.Text = "Made By V3rm Arda"
TextLabel.TextColor3 = Color3.new(0, 0, 0)
TextLabel.TextScaled = true
TextLabel.TextSize = 14
TextLabel.TextWrapped = true

PirateOn.Name = "PirateOn"
PirateOn.Parent = LoginFrame
PirateOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
PirateOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
PirateOn.Position = UDim2.new(0, 0, 0.19914636, 0)
PirateOn.Size = UDim2.new(0, 56, 0, 28)
PirateOn.Font = Enum.Font.SourceSans
PirateOn.Text = "Pirate On"
PirateOn.TextColor3 = Color3.new(0, 0, 0)
PirateOn.TextScaled = true
PirateOn.TextSize = 14
PirateOn.TextWrapped = true

Frame.Parent = LoginFrame
Frame.BackgroundColor3 = Color3.new(0.156863, 0.156863, 0.156863)
Frame.BorderColor3 = Color3.new(0.156863, 0.156863, 0.156863)
Frame.Position = UDim2.new(0, 0, 0.148788929, 0)
Frame.Size = UDim2.new(0, 361, 0, 6)

PirateOff.Name = "PirateOff"
PirateOff.Parent = LoginFrame
PirateOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
PirateOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
PirateOff.Position = UDim2.new(0.177285314, 0, 0.19914636, 0)
PirateOff.Size = UDim2.new(0, 56, 0, 28)
PirateOff.Font = Enum.Font.SourceSans
PirateOff.Text = "Pirate Off"
PirateOff.TextColor3 = Color3.new(0, 0, 0)
PirateOff.TextScaled = true
PirateOff.TextSize = 14
PirateOff.TextWrapped = true

BruteOn.Name = "BruteOn"
BruteOn.Parent = LoginFrame
BruteOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
BruteOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
BruteOn.Position = UDim2.new(0.349030495, 0, 0.19914636, 0)
BruteOn.Size = UDim2.new(0, 56, 0, 28)
BruteOn.Font = Enum.Font.SourceSans
BruteOn.Text = "Brute On"
BruteOn.TextColor3 = Color3.new(0, 0, 0)
BruteOn.TextScaled = true
BruteOn.TextSize = 14
BruteOn.TextWrapped = true

TpSpamOff.Name = "TpSpamOff"
TpSpamOff.Parent = LoginFrame
TpSpamOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TpSpamOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TpSpamOff.Position = UDim2.new(0.349030554, 0, 0.920349181, 0)
TpSpamOff.Size = UDim2.new(0, 56, 0, 28)
TpSpamOff.Font = Enum.Font.SourceSans
TpSpamOff.Text = "Teleport Spam Off"
TpSpamOff.TextColor3 = Color3.new(0, 0, 0)
TpSpamOff.TextScaled = true
TpSpamOff.TextSize = 14
TpSpamOff.TextWrapped = true

BruteOff.Name = "BruteOff"
BruteOff.Parent = LoginFrame
BruteOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
BruteOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
BruteOff.Position = UDim2.new(0.520775676, 0, 0.19914636, 0)
BruteOff.Size = UDim2.new(0, 56, 0, 28)
BruteOff.Font = Enum.Font.SourceSans
BruteOff.Text = "Brute Off"
BruteOff.TextColor3 = Color3.new(0, 0, 0)
BruteOff.TextScaled = true
BruteOff.TextSize = 14
BruteOff.TextWrapped = true

SnowBanditsOff.Name = "SnowBanditsOff"
SnowBanditsOff.Parent = LoginFrame
SnowBanditsOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
SnowBanditsOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
SnowBanditsOff.Position = UDim2.new(0.867035985, 0, 0.19914636, 0)
SnowBanditsOff.Size = UDim2.new(0, 48, 0, 28)
SnowBanditsOff.Font = Enum.Font.SourceSans
SnowBanditsOff.Text = "Snow Bandits Off"
SnowBanditsOff.TextColor3 = Color3.new(0, 0, 0)
SnowBanditsOff.TextScaled = true
SnowBanditsOff.TextSize = 14
SnowBanditsOff.TextWrapped = true

SnowBanditsOn.Name = "SnowBanditsOn"
SnowBanditsOn.Parent = LoginFrame
SnowBanditsOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
SnowBanditsOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
SnowBanditsOn.Position = UDim2.new(0.706371188, 0, 0.19914636, 0)
SnowBanditsOn.Size = UDim2.new(0, 50, 0, 28)
SnowBanditsOn.Font = Enum.Font.SourceSans
SnowBanditsOn.Text = "Snow Bandits On"
SnowBanditsOn.TextColor3 = Color3.new(0, 0, 0)
SnowBanditsOn.TextScaled = true
SnowBanditsOn.TextSize = 14
SnowBanditsOn.TextWrapped = true

SnowManOn.Name = "SnowManOn"
SnowManOn.Parent = LoginFrame
SnowManOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
SnowManOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
SnowManOn.Position = UDim2.new(0, 0, 0.304882556, 0)
SnowManOn.Size = UDim2.new(0, 56, 0, 28)
SnowManOn.Font = Enum.Font.SourceSans
SnowManOn.Text = "Snow Man On"
SnowManOn.TextColor3 = Color3.new(0, 0, 0)
SnowManOn.TextScaled = true
SnowManOn.TextSize = 14
SnowManOn.TextWrapped = true

SnowManOff.Name = "SnowManOff"
SnowManOff.Parent = LoginFrame
SnowManOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
SnowManOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
SnowManOff.Position = UDim2.new(0.177285314, 0, 0.304882556, 0)
SnowManOff.Size = UDim2.new(0, 56, 0, 28)
SnowManOff.Font = Enum.Font.SourceSans
SnowManOff.Text = "Snow Man Off"
SnowManOff.TextColor3 = Color3.new(0, 0, 0)
SnowManOff.TextScaled = true
SnowManOff.TextSize = 14
SnowManOff.TextWrapped = true

YetiOn.Name = "YetiOn"
YetiOn.Parent = LoginFrame
YetiOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
YetiOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
YetiOn.Position = UDim2.new(0.349030495, 0, 0.304882556, 0)
YetiOn.Size = UDim2.new(0, 56, 0, 28)
YetiOn.Font = Enum.Font.SourceSans
YetiOn.Text = "Yeti On"
YetiOn.TextColor3 = Color3.new(0, 0, 0)
YetiOn.TextScaled = true
YetiOn.TextSize = 14
YetiOn.TextWrapped = true

YetiOff.Name = "YetiOff"
YetiOff.Parent = LoginFrame
YetiOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
YetiOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
YetiOff.Position = UDim2.new(0.520775676, 0, 0.304882556, 0)
YetiOff.Size = UDim2.new(0, 56, 0, 28)
YetiOff.Font = Enum.Font.SourceSans
YetiOff.Text = "Yeti Off"
YetiOff.TextColor3 = Color3.new(0, 0, 0)
YetiOff.TextScaled = true
YetiOff.TextSize = 14
YetiOff.TextWrapped = true

SkyBanditsOn.Name = "SkyBanditsOn"
SkyBanditsOn.Parent = LoginFrame
SkyBanditsOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
SkyBanditsOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
SkyBanditsOn.Position = UDim2.new(0.706371188, 0, 0.304882556, 0)
SkyBanditsOn.Size = UDim2.new(0, 50, 0, 28)
SkyBanditsOn.Font = Enum.Font.SourceSans
SkyBanditsOn.Text = "Sky Bandits On"
SkyBanditsOn.TextColor3 = Color3.new(0, 0, 0)
SkyBanditsOn.TextScaled = true
SkyBanditsOn.TextSize = 14
SkyBanditsOn.TextWrapped = true

SkyBanditsOff.Name = "SkyBanditsOff"
SkyBanditsOff.Parent = LoginFrame
SkyBanditsOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
SkyBanditsOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
SkyBanditsOff.Position = UDim2.new(0.867035985, 0, 0.304882556, 0)
SkyBanditsOff.Size = UDim2.new(0, 48, 0, 28)
SkyBanditsOff.Font = Enum.Font.SourceSans
SkyBanditsOff.Text = "Sky Bandits Off"
SkyBanditsOff.TextColor3 = Color3.new(0, 0, 0)
SkyBanditsOff.TextScaled = true
SkyBanditsOff.TextSize = 14
SkyBanditsOff.TextWrapped = true

DarkMasterOn.Name = "DarkMasterOn"
DarkMasterOn.Parent = LoginFrame
DarkMasterOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
DarkMasterOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
DarkMasterOn.Position = UDim2.new(0, 0, 0.413125992, 0)
DarkMasterOn.Size = UDim2.new(0, 56, 0, 28)
DarkMasterOn.Font = Enum.Font.SourceSans
DarkMasterOn.Text = "Dark Master On"
DarkMasterOn.TextColor3 = Color3.new(0, 0, 0)
DarkMasterOn.TextScaled = true
DarkMasterOn.TextSize = 14
DarkMasterOn.TextWrapped = true

DarkMasterOff.Name = "DarkMasterOff"
DarkMasterOff.Parent = LoginFrame
DarkMasterOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
DarkMasterOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
DarkMasterOff.Position = UDim2.new(0.177285314, 0, 0.413125992, 0)
DarkMasterOff.Size = UDim2.new(0, 56, 0, 28)
DarkMasterOff.Font = Enum.Font.SourceSans
DarkMasterOff.Text = "Dark Master Off"
DarkMasterOff.TextColor3 = Color3.new(0, 0, 0)
DarkMasterOff.TextScaled = true
DarkMasterOff.TextSize = 14
DarkMasterOff.TextWrapped = true

DesertBanditOn.Name = "DesertBanditOn"
DesertBanditOn.Parent = LoginFrame
DesertBanditOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
DesertBanditOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
DesertBanditOn.Position = UDim2.new(0.349030495, 0, 0.413125992, 0)
DesertBanditOn.Size = UDim2.new(0, 56, 0, 28)
DesertBanditOn.Font = Enum.Font.SourceSans
DesertBanditOn.Text = "Desert Bandit On"
DesertBanditOn.TextColor3 = Color3.new(0, 0, 0)
DesertBanditOn.TextScaled = true
DesertBanditOn.TextSize = 14
DesertBanditOn.TextWrapped = true

DesertBanditOff.Name = "DesertBanditOff"
DesertBanditOff.Parent = LoginFrame
DesertBanditOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
DesertBanditOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
DesertBanditOff.Position = UDim2.new(0.520775676, 0, 0.413125992, 0)
DesertBanditOff.Size = UDim2.new(0, 56, 0, 28)
DesertBanditOff.Font = Enum.Font.SourceSans
DesertBanditOff.Text = "Desert Bandit Off"
DesertBanditOff.TextColor3 = Color3.new(0, 0, 0)
DesertBanditOff.TextScaled = true
DesertBanditOff.TextSize = 14
DesertBanditOff.TextWrapped = true

DesertOfficerOn.Name = "DesertOfficerOn"
DesertOfficerOn.Parent = LoginFrame
DesertOfficerOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
DesertOfficerOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
DesertOfficerOn.Position = UDim2.new(0.706371188, 0, 0.413125992, 0)
DesertOfficerOn.Size = UDim2.new(0, 50, 0, 28)
DesertOfficerOn.Font = Enum.Font.SourceSans
DesertOfficerOn.Text = "Desert Officer On"
DesertOfficerOn.TextColor3 = Color3.new(0, 0, 0)
DesertOfficerOn.TextScaled = true
DesertOfficerOn.TextSize = 14
DesertOfficerOn.TextWrapped = true

DesertOfficerOn_2.Name = "DesertOfficerOn"
DesertOfficerOn_2.Parent = LoginFrame
DesertOfficerOn_2.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
DesertOfficerOn_2.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
DesertOfficerOn_2.Position = UDim2.new(0.867035985, 0, 0.413125992, 0)
DesertOfficerOn_2.Size = UDim2.new(0, 48, 0, 28)
DesertOfficerOn_2.Font = Enum.Font.SourceSans
DesertOfficerOn_2.Text = "Desert Officer Off"
DesertOfficerOn_2.TextColor3 = Color3.new(0, 0, 0)
DesertOfficerOn_2.TextScaled = true
DesertOfficerOn_2.TextSize = 14
DesertOfficerOn_2.TextWrapped = true

WardenOn.Name = "WardenOn"
WardenOn.Parent = LoginFrame
WardenOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
WardenOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
WardenOn.Position = UDim2.new(0, 0, 0.526911795, 0)
WardenOn.Size = UDim2.new(0, 56, 0, 28)
WardenOn.Font = Enum.Font.SourceSans
WardenOn.Text = "Warden On"
WardenOn.TextColor3 = Color3.new(0, 0, 0)
WardenOn.TextScaled = true
WardenOn.TextSize = 14
WardenOn.TextWrapped = true

WardenOff.Name = "WardenOff"
WardenOff.Parent = LoginFrame
WardenOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
WardenOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
WardenOff.Position = UDim2.new(0.174515232, 0, 0.526911795, 0)
WardenOff.Size = UDim2.new(0, 56, 0, 28)
WardenOff.Font = Enum.Font.SourceSans
WardenOff.Text = "Warden Off"
WardenOff.TextColor3 = Color3.new(0, 0, 0)
WardenOff.TextScaled = true
WardenOff.TextSize = 14
WardenOff.TextWrapped = true

ChiefWardenOn.Name = "ChiefWardenOn"
ChiefWardenOn.Parent = LoginFrame
ChiefWardenOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
ChiefWardenOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
ChiefWardenOn.Position = UDim2.new(0.349030554, 0, 0.526911736, 0)
ChiefWardenOn.Size = UDim2.new(0, 56, 0, 28)
ChiefWardenOn.Font = Enum.Font.SourceSans
ChiefWardenOn.Text = "Chief Warden On"
ChiefWardenOn.TextColor3 = Color3.new(0, 0, 0)
ChiefWardenOn.TextScaled = true
ChiefWardenOn.TextSize = 14
ChiefWardenOn.TextWrapped = true

ChiefWardenOff.Name = "ChiefWardenOff"
ChiefWardenOff.Parent = LoginFrame
ChiefWardenOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
ChiefWardenOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
ChiefWardenOff.Position = UDim2.new(0.520775676, 0, 0.526911676, 0)
ChiefWardenOff.Size = UDim2.new(0, 56, 0, 28)
ChiefWardenOff.Font = Enum.Font.SourceSans
ChiefWardenOff.Text = "Chief Warden Off"
ChiefWardenOff.TextColor3 = Color3.new(0, 0, 0)
ChiefWardenOff.TextScaled = true
ChiefWardenOff.TextSize = 14
ChiefWardenOff.TextWrapped = true

FlamingoOn.Name = "FlamingoOn"
FlamingoOn.Parent = LoginFrame
FlamingoOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
FlamingoOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
FlamingoOn.Position = UDim2.new(0.706371188, 0, 0.526911795, 0)
FlamingoOn.Size = UDim2.new(0, 50, 0, 28)
FlamingoOn.Font = Enum.Font.SourceSans
FlamingoOn.Text = "Flamingo On"
FlamingoOn.TextColor3 = Color3.new(0, 0, 0)
FlamingoOn.TextScaled = true
FlamingoOn.TextSize = 14
FlamingoOn.TextWrapped = true

FlamingoOff.Name = "FlamingoOff"
FlamingoOff.Parent = LoginFrame
FlamingoOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
FlamingoOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
FlamingoOff.Position = UDim2.new(0.867035985, 0, 0.526911795, 0)
FlamingoOff.Size = UDim2.new(0, 48, 0, 28)
FlamingoOff.Font = Enum.Font.SourceSans
FlamingoOff.Text = "Flamingo Off"
FlamingoOff.TextColor3 = Color3.new(0, 0, 0)
FlamingoOff.TextScaled = true
FlamingoOff.TextSize = 14
FlamingoOff.TextWrapped = true

ScrollingFrame.Parent = LoginFrame
ScrollingFrame.BackgroundColor3 = Color3.new(0.117647, 0.117647, 0.117647)
ScrollingFrame.BorderColor3 = Color3.new(0.117647, 0.117647, 0.117647)
ScrollingFrame.Position = UDim2.new(1, 0, 0, 0)
ScrollingFrame.Size = UDim2.new(0, 109, 0, 357)

Frame_2.Parent = ScrollingFrame
Frame_2.BackgroundColor3 = Color3.new(0.156863, 0.156863, 0.156863)
Frame_2.BorderColor3 = Color3.new(0.156863, 0.156863, 0.156863)
Frame_2.Position = UDim2.new(0, 0, 1.49011612e-08, 0)
Frame_2.Size = UDim2.new(0, 12, 0, 578)

Frame_3.Parent = ScrollingFrame
Frame_3.BackgroundColor3 = Color3.new(0.156863, 0.156863, 0.156863)
Frame_3.BorderColor3 = Color3.new(0.156863, 0.156863, 0.156863)
Frame_3.Position = UDim2.new(0.110091746, 0, 0.0743944794, 0)
Frame_3.Size = UDim2.new(0, 97, 0, 6)

TextButton.Parent = ScrollingFrame
TextButton.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton.Position = UDim2.new(0.110091746, 0, 0.0872114301, 0)
TextButton.Size = UDim2.new(0, 84, 0, 28)
TextButton.Font = Enum.Font.SourceSans
TextButton.Text = "Ice Island"
TextButton.TextColor3 = Color3.new(0, 0, 0)
TextButton.TextScaled = true
TextButton.TextSize = 14
TextButton.TextWrapped = true

TextButton_2.Parent = ScrollingFrame
TextButton_2.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_2.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_2.Position = UDim2.new(0.110091746, 0, 0.13565433, 0)
TextButton_2.Size = UDim2.new(0, 84, 0, 28)
TextButton_2.Font = Enum.Font.SourceSans
TextButton_2.Text = "Sand Island"
TextButton_2.TextColor3 = Color3.new(0, 0, 0)
TextButton_2.TextScaled = true
TextButton_2.TextSize = 14
TextButton_2.TextWrapped = true

TextButton_3.Parent = ScrollingFrame
TextButton_3.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_3.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_3.Position = UDim2.new(0.110091746, 0, 0.18409723, 0)
TextButton_3.Size = UDim2.new(0, 84, 0, 28)
TextButton_3.Font = Enum.Font.SourceSans
TextButton_3.Text = "Sky Island"
TextButton_3.TextColor3 = Color3.new(0, 0, 0)
TextButton_3.TextScaled = true
TextButton_3.TextSize = 14
TextButton_3.TextWrapped = true

TextButton_4.Parent = ScrollingFrame
TextButton_4.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_4.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_4.Position = UDim2.new(0.110091746, 0, 0.232540131, 0)
TextButton_4.Size = UDim2.new(0, 84, 0, 28)
TextButton_4.Font = Enum.Font.SourceSans
TextButton_4.Text = "Pirate Main"
TextButton_4.TextColor3 = Color3.new(0, 0, 0)
TextButton_4.TextScaled = true
TextButton_4.TextSize = 14
TextButton_4.TextWrapped = true

TextButton_5.Parent = ScrollingFrame
TextButton_5.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_5.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_5.Position = UDim2.new(0.110091746, 0, 0.280983031, 0)
TextButton_5.Size = UDim2.new(0, 84, 0, 28)
TextButton_5.Font = Enum.Font.SourceSans
TextButton_5.Text = "Monkey Island"
TextButton_5.TextColor3 = Color3.new(0, 0, 0)
TextButton_5.TextScaled = true
TextButton_5.TextSize = 14
TextButton_5.TextWrapped = true

TextButton_6.Parent = ScrollingFrame
TextButton_6.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_6.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_6.Position = UDim2.new(0.110091746, 0, 0.329425931, 0)
TextButton_6.Size = UDim2.new(0, 84, 0, 28)
TextButton_6.Font = Enum.Font.SourceSans
TextButton_6.Text = "Buggy Island"
TextButton_6.TextColor3 = Color3.new(0, 0, 0)
TextButton_6.TextScaled = true
TextButton_6.TextSize = 14
TextButton_6.TextWrapped = true

TextButton_7.Parent = ScrollingFrame
TextButton_7.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_7.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_7.Position = UDim2.new(0.110091746, 0, 0.377868831, 0)
TextButton_7.Size = UDim2.new(0, 84, 0, 28)
TextButton_7.Font = Enum.Font.SourceSans
TextButton_7.Text = "Marineford"
TextButton_7.TextColor3 = Color3.new(0, 0, 0)
TextButton_7.TextScaled = true
TextButton_7.TextSize = 14
TextButton_7.TextWrapped = true

TextButton_8.Parent = ScrollingFrame
TextButton_8.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_8.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_8.Position = UDim2.new(0.110091746, 0, 0.426311731, 0)
TextButton_8.Size = UDim2.new(0, 84, 0, 28)
TextButton_8.Font = Enum.Font.SourceSans
TextButton_8.Text = "Marine Main Spawn"
TextButton_8.TextColor3 = Color3.new(0, 0, 0)
TextButton_8.TextScaled = true
TextButton_8.TextSize = 14
TextButton_8.TextWrapped = true

TextButton_9.Parent = ScrollingFrame
TextButton_9.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_9.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_9.Position = UDim2.new(0.110091746, 0, 0.474754632, 0)
TextButton_9.Size = UDim2.new(0, 84, 0, 28)
TextButton_9.Font = Enum.Font.SourceSans
TextButton_9.Text = "Logue Town"
TextButton_9.TextColor3 = Color3.new(0, 0, 0)
TextButton_9.TextScaled = true
TextButton_9.TextSize = 14
TextButton_9.TextWrapped = true

TextButton_10.Parent = ScrollingFrame
TextButton_10.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_10.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TextButton_10.Position = UDim2.new(0.110091746, 0, 0.52665776, 0)
TextButton_10.Size = UDim2.new(0, 84, 0, 28)
TextButton_10.Font = Enum.Font.SourceSans
TextButton_10.Text = "Impel Down"
TextButton_10.TextColor3 = Color3.new(0, 0, 0)
TextButton_10.TextScaled = true
TextButton_10.TextSize = 14
TextButton_10.TextWrapped = true

AutoDFTpOn.Name = "AutoDFTpOn"
AutoDFTpOn.Parent = LoginFrame
AutoDFTpOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
AutoDFTpOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
AutoDFTpOn.Position = UDim2.new(1.04308128e-07, 0, 0.833164692, 0)
AutoDFTpOn.Size = UDim2.new(0, 56, 0, 28)
AutoDFTpOn.Font = Enum.Font.SourceSans
AutoDFTpOn.Text = "Auto DF Tp On"
AutoDFTpOn.TextColor3 = Color3.new(0, 0, 0)
AutoDFTpOn.TextScaled = true
AutoDFTpOn.TextSize = 14
AutoDFTpOn.TextWrapped = true

AutoDFTpOff.Name = "AutoDFTpOff"
AutoDFTpOff.Parent = LoginFrame
AutoDFTpOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
AutoDFTpOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
AutoDFTpOff.Position = UDim2.new(0.171745256, 0, 0.833164692, 0)
AutoDFTpOff.Size = UDim2.new(0, 56, 0, 28)
AutoDFTpOff.Font = Enum.Font.SourceSans
AutoDFTpOff.Text = "Auto DF Tp Off"
AutoDFTpOff.TextColor3 = Color3.new(0, 0, 0)
AutoDFTpOff.TextScaled = true
AutoDFTpOff.TextSize = 14
AutoDFTpOff.TextWrapped = true

ChestTpOn.Name = "ChestTpOn"
ChestTpOn.Parent = LoginFrame
ChestTpOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
ChestTpOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
ChestTpOn.Position = UDim2.new(0.349030554, 0, 0.833164692, 0)
ChestTpOn.Size = UDim2.new(0, 56, 0, 28)
ChestTpOn.Font = Enum.Font.SourceSans
ChestTpOn.Text = "Chest Tp On"
ChestTpOn.TextColor3 = Color3.new(0, 0, 0)
ChestTpOn.TextScaled = true
ChestTpOn.TextSize = 14
ChestTpOn.TextWrapped = true

ChestTpOff.Name = "ChestTpOff"
ChestTpOff.Parent = LoginFrame
ChestTpOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
ChestTpOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
ChestTpOff.Position = UDim2.new(0.520775676, 0, 0.830363631, 0)
ChestTpOff.Size = UDim2.new(0, 56, 0, 28)
ChestTpOff.Font = Enum.Font.SourceSans
ChestTpOff.Text = "Chest Tp Off"
ChestTpOff.TextColor3 = Color3.new(0, 0, 0)
ChestTpOff.TextScaled = true
ChestTpOff.TextSize = 14
ChestTpOff.TextWrapped = true

Safe.Name = "Safe"
Safe.Parent = LoginFrame
Safe.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
Safe.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
Safe.Position = UDim2.new(0.706371188, 0, 0.833164692, 0)
Safe.Size = UDim2.new(0, 50, 0, 28)
Safe.Font = Enum.Font.SourceSans
Safe.Text = "Safe Place"
Safe.TextColor3 = Color3.new(0, 0, 0)
Safe.TextScaled = true
Safe.TextSize = 14
Safe.TextWrapped = true

Anti.Name = "Anti"
Anti.Parent = LoginFrame
Anti.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
Anti.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
Anti.Position = UDim2.new(0.867035985, 0, 0.832971811, 0)
Anti.Size = UDim2.new(0, 48, 0, 28)
Anti.Font = Enum.Font.SourceSans
Anti.Text = "Anti Afk"
Anti.TextColor3 = Color3.new(0, 0, 0)
Anti.TextScaled = true
Anti.TextSize = 14
Anti.TextWrapped = true

TpSpamOn.Name = "TpSpamOn"
TpSpamOn.Parent = LoginFrame
TpSpamOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TpSpamOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
TpSpamOn.Position = UDim2.new(0.174515307, 0, 0.920349181, 0)
TpSpamOn.Size = UDim2.new(0, 56, 0, 28)
TpSpamOn.Font = Enum.Font.SourceSans
TpSpamOn.Text = "Teleport Spam On"
TpSpamOn.TextColor3 = Color3.new(0, 0, 0)
TpSpamOn.TextScaled = true
TpSpamOn.TextSize = 14
TpSpamOn.TextWrapped = true

Tp.Name = "Tp"
Tp.Parent = LoginFrame
Tp.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
Tp.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
Tp.Position = UDim2.new(8.19563866e-08, 0, 0.920349181, 0)
Tp.Size = UDim2.new(0, 56, 0, 28)
Tp.Font = Enum.Font.SourceSans
Tp.Text = "Teleport"
Tp.TextColor3 = Color3.new(0, 0, 0)
Tp.TextScaled = true
Tp.TextSize = 14
Tp.TextWrapped = true

name.Name = "name"
name.Parent = LoginFrame
name.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
name.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
name.Position = UDim2.new(0.520775676, 0, 0.920349181, 0)
name.Size = UDim2.new(0, 56, 0, 28)
name.Font = Enum.Font.SourceSans
name.Text = "Player Name Here"
name.TextColor3 = Color3.new(0, 0, 0)
name.TextScaled = true
name.TextSize = 14
name.TextWrapped = true

GorillaOff.Name = "GorillaOff"
GorillaOff.Parent = LoginFrame
GorillaOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
GorillaOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
GorillaOff.Position = UDim2.new(0.867035985, 0, 0.645254195, 0)
GorillaOff.Size = UDim2.new(0, 48, 0, 28)
GorillaOff.Font = Enum.Font.SourceSans
GorillaOff.Text = "Gorillas Off"
GorillaOff.TextColor3 = Color3.new(0, 0, 0)
GorillaOff.TextScaled = true
GorillaOff.TextSize = 14
GorillaOff.TextWrapped = true

BanditsOn.Name = "BanditsOn"
BanditsOn.Parent = LoginFrame
BanditsOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
BanditsOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
BanditsOn.Position = UDim2.new(0, 0, 0.645254135, 0)
BanditsOn.Size = UDim2.new(0, 56, 0, 28)
BanditsOn.Font = Enum.Font.SourceSans
BanditsOn.Text = "Bandits On"
BanditsOn.TextColor3 = Color3.new(0, 0, 0)
BanditsOn.TextScaled = true
BanditsOn.TextSize = 14
BanditsOn.TextWrapped = true

BanditsOff.Name = "BanditsOff"
BanditsOff.Parent = LoginFrame
BanditsOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
BanditsOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
BanditsOff.Position = UDim2.new(0.177285314, 0, 0.645254135, 0)
BanditsOff.Size = UDim2.new(0, 56, 0, 28)
BanditsOff.Font = Enum.Font.SourceSans
BanditsOff.Text = "Bandits Off"
BanditsOff.TextColor3 = Color3.new(0, 0, 0)
BanditsOff.TextScaled = true
BanditsOff.TextSize = 14
BanditsOff.TextWrapped = true

MonkeysOn.Name = "MonkeysOn"
MonkeysOn.Parent = LoginFrame
MonkeysOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
MonkeysOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
MonkeysOn.Position = UDim2.new(0.349030465, 0, 0.645254135, 0)
MonkeysOn.Size = UDim2.new(0, 56, 0, 28)
MonkeysOn.Font = Enum.Font.SourceSans
MonkeysOn.Text = "Monkeys On"
MonkeysOn.TextColor3 = Color3.new(0, 0, 0)
MonkeysOn.TextScaled = true
MonkeysOn.TextSize = 14
MonkeysOn.TextWrapped = true

MonkeysOff.Name = "MonkeysOff"
MonkeysOff.Parent = LoginFrame
MonkeysOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
MonkeysOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
MonkeysOff.Position = UDim2.new(0.520775616, 0, 0.645254135, 0)
MonkeysOff.Size = UDim2.new(0, 56, 0, 28)
MonkeysOff.Font = Enum.Font.SourceSans
MonkeysOff.Text = "Monkeys Off"
MonkeysOff.TextColor3 = Color3.new(0, 0, 0)
MonkeysOff.TextScaled = true
MonkeysOff.TextSize = 14
MonkeysOff.TextWrapped = true

GorillaOn.Name = "GorillaOn"
GorillaOn.Parent = LoginFrame
GorillaOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
GorillaOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
GorillaOn.Position = UDim2.new(0.706371188, 0, 0.645254195, 0)
GorillaOn.Size = UDim2.new(0, 50, 0, 28)
GorillaOn.Font = Enum.Font.SourceSans
GorillaOn.Text = "Gorillas On"
GorillaOn.TextColor3 = Color3.new(0, 0, 0)
GorillaOn.TextScaled = true
GorillaOn.TextSize = 14
GorillaOn.TextWrapped = true

MarineCaptainOn.Name = "MarineCaptainOn"
MarineCaptainOn.Parent = LoginFrame
MarineCaptainOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
MarineCaptainOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
MarineCaptainOn.Position = UDim2.new(0, 0, 0.73728323, 0)
MarineCaptainOn.Size = UDim2.new(0, 120, 0, 27)
MarineCaptainOn.Font = Enum.Font.SourceSans
MarineCaptainOn.Text = "Marine Captain On "
MarineCaptainOn.TextColor3 = Color3.new(0, 0, 0)
MarineCaptainOn.TextScaled = true
MarineCaptainOn.TextSize = 14
MarineCaptainOn.TextWrapped = true

MarineCaptainOff.Name = "MarineCaptainOff"
MarineCaptainOff.Parent = LoginFrame
MarineCaptainOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
MarineCaptainOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
MarineCaptainOff.Position = UDim2.new(0.349030465, 0, 0.73728323, 0)
MarineCaptainOff.Size = UDim2.new(0, 118, 0, 27)
MarineCaptainOff.Font = Enum.Font.SourceSans
MarineCaptainOff.Text = "Marine Captain Off "
MarineCaptainOff.TextColor3 = Color3.new(0, 0, 0)
MarineCaptainOff.TextScaled = true
MarineCaptainOff.TextSize = 14
MarineCaptainOff.TextWrapped = true

ViceAdmiralOn.Name = "ViceAdmiralOn"
ViceAdmiralOn.Parent = LoginFrame
ViceAdmiralOn.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
ViceAdmiralOn.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
ViceAdmiralOn.Position = UDim2.new(0.706371188, 0, 0.73728323, 0)
ViceAdmiralOn.Size = UDim2.new(0, 50, 0, 27)
ViceAdmiralOn.Font = Enum.Font.SourceSans
ViceAdmiralOn.Text = "Vice Admiral On"
ViceAdmiralOn.TextColor3 = Color3.new(0, 0, 0)
ViceAdmiralOn.TextScaled = true
ViceAdmiralOn.TextSize = 14
ViceAdmiralOn.TextWrapped = true

ViceAdmiralOff.Name = "ViceAdmiralOff"
ViceAdmiralOff.Parent = LoginFrame
ViceAdmiralOff.BackgroundColor3 = Color3.new(0.137255, 0.137255, 0.137255)
ViceAdmiralOff.BorderColor3 = Color3.new(0.137255, 0.137255, 0.137255)
ViceAdmiralOff.Position = UDim2.new(0.867035985, 0, 0.73728323, 0)
ViceAdmiralOff.Size = UDim2.new(0, 48, 0, 27)
ViceAdmiralOff.Font = Enum.Font.SourceSans
ViceAdmiralOff.Text = "Vice Admiral Off"
ViceAdmiralOff.TextColor3 = Color3.new(0, 0, 0)
ViceAdmiralOff.TextScaled = true
ViceAdmiralOff.TextSize = 14
ViceAdmiralOff.TextWrapped = true
-- Scripts:
PirateOn.MouseButton1Click:connect(function()
	_G.farm = true
	while _G.farm do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Pirate [Lv. 35]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm == false
	end
	end
	end
	end

end)

PirateOff.MouseButton1Click:connect(function()
	_G.farm = false

end)

BruteOn.MouseButton1Click:connect(function()
	_G.farm2 = true
	while _G.farm2 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Brute [Lv. 45]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm2 == false
	end
	end
	end
	end

end)

TpSpamOff.MouseButton1Click:connect(function()
	_G.spam = false

end)

BruteOff.MouseButton1Click:connect(function()
	_G.farm2 = false

end)

SnowBanditsOff.MouseButton1Click:connect(function()
	_G.farm3 = false

end)

SnowBanditsOn.MouseButton1Click:connect(function()
	_G.farm3 = true
	while _G.farm3 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Snow Bandit [Lv. 90]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm3 == false
	end
	end
	end
	end

end)

SnowManOn.MouseButton1Click:connect(function()
	_G.farm4 = true
	while _G.farm4 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Snowman [Lv. 100]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm4 == false
	end
	end
	end
	end

end)

SnowManOff.MouseButton1Click:connect(function()
	_G.farm4 = false

end)

YetiOn.MouseButton1Click:connect(function()
	_G.farm5 = true
	while _G.farm5 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Yeti [Lv. 100] [Boss]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm5 == false
	end
	end
	end
	end

end)

YetiOff.MouseButton1Click:connect(function()
	_G.farm5 = false

end)

SkyBanditsOn.MouseButton1Click:connect(function()
	_G.farm6 = true
	while _G.farm6 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Sky Bandit [Lv. 150]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm6 == false
	end
	end
	end
	end

end)

SkyBanditsOff.MouseButton1Click:connect(function()
	_G.farm6 = false

end)

DarkMasterOn.MouseButton1Click:connect(function()
	_G.farm7 = true
	while _G.farm7 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Dark Master [Lv. 160]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm7 == false
	end
	end
	end
	end

end)

DarkMasterOff.MouseButton1Click:connect(function()
	_G.farm7 = false

end)

DesertBanditOn.MouseButton1Click:connect(function()
	_G.farm8 = true
	while _G.farm8 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Desert Bandit [Lv. 60]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm8 == false
	end
	end
	end
	end

end)

DesertBanditOff.MouseButton1Click:connect(function()
	_G.farm8 = false

end)

DesertOfficerOn.MouseButton1Click:connect(function()
	_G.farm9 = true
	while _G.farm9 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Desert Officer [Lv. 70]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm9 == false
	end
	end
	end
	end

end)

DesertOfficerOn_2.MouseButton1Click:connect(function()
	_G.farm9 = false

end)

WardenOn.MouseButton1Click:connect(function()
	_G.farm10 = true
	while _G.farm10 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Warden [Lv. 175]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm10 == false
	end
	end
	end
	end

end)

WardenOff.MouseButton1Click:connect(function()
	_G.farm10 = false

end)

ChiefWardenOn.MouseButton1Click:connect(function()
	_G.farm11 = true
	while _G.farm11 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Chief Warden [Lv. 200] [Boss]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm11 == false
	end
	end
	end
	end

end)

ChiefWardenOff.MouseButton1Click:connect(function()
	_G.farm11 = false

end)

FlamingoOn.MouseButton1Click:connect(function()
	_G.farm12 = true
	while _G.farm12 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Flamingo [Lv. 225] [Boss]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm12 == false
	end
	end
	end
	end

end)

FlamingoOff.MouseButton1Click:connect(function()
	_G.farm12 = false
	

end)

TextButton.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(1389, 93, -1337)

end)

TextButton_2.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(901, 10, 4382)

end)

TextButton_3.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-4800, 722, -2561)

end)

TextButton_4.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(1056, 23, 1439)

end)

TextButton_5.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-2448, 977, 389)

end)

TextButton_6.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-1277, 16, 4290)

end)

TextButton_7.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-4962, 25, 4245)

end)

TextButton_8.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-2651, 12, 2069)

end)

TextButton_9.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-628, 8, 1662)

end)

TextButton_10.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(5302, 91, 750)

end)

AutoDFTpOn.MouseButton1Click:connect(function()
	_G.df = true
	while _G.df do
		wait(5)
	
	local a = game.Players.LocalPlayer.Character.HumanoidRootPart
	local b = a.CFrame
	for i,v in pairs(game.Workspace["_WorldOrigin"]:GetDescendants()) do
	if v.Name == "Fruit" and v.Parent:IsA("Model") and v.Parent.Name == "Model" then
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.CFrame
	end
	end
	end

end)

AutoDFTpOff.MouseButton1Click:connect(function()
	_G.df = false

end)

ChestTpOn.MouseButton1Click:connect(function()
	_G.chest = true
	while _G.chest do
		wait(5)
	
	local OriginalPos = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
	local a = game.Workspace:GetChildren()
	for i=1,#a do
	    if a[i].Name:lower():match("chest") then
	        b = false
	        repeat wait()
	            if a[i].Parent~=game.Workspace then
	                b = true
	            else
	                game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = a[i].CFrame
	            end
	        until b == true
	    end
	end
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = OriginalPos
	end

end)

ChestTpOff.MouseButton1Click:connect(function()
	_G.chest = false

end)

Safe.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(4000, 50000, 8000)
					    baseplatee = Instance.new("Part", workspace)
					    baseplatee.Size = Vector3.new(1000, 1, 1000)
					    baseplatee.CFrame = game.workspace[game.Players.LocalPlayer.Name].HumanoidRootPart.CFrame + Vector3.new(0,-2, 0)
					    baseplatee.Anchored = true

end)

Anti.MouseButton1Click:connect(function()
	local vu = game:GetService("VirtualUser")
			game:GetService("Players").LocalPlayer.Idled:connect(function()
			   vu:Button2Down(Vector2.new(0,0),workspace.CurrentCamera.CFrame)
			   wait(1)
			   vu:Button2Up(Vector2.new(0,0),workspace.CurrentCamera.CFrame)
			end)

end)

TpSpamOn.MouseButton1Click:connect(function()
	_G.spam = true
	while _G.spam do
	wait(0)
	
	for i,v in pairs(game.workspace.Characters:GetChildren()) do
	if v.Name == name.Text then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.spam == false
	end
	end
	end
	end

end)

Tp.MouseButton1Click:connect(function()
	
	for i,v in pairs(game.workspace.Characters:GetChildren()) do
	if v.Name == name.Text then
	if v.Humanoid.Health > 0 then
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 0)
	end
	end
	end
	

end)

GorillaOff.MouseButton1Click:connect(function()
	_G.farm15 = false
	

end)

BanditsOn.MouseButton1Click:connect(function()
	_G.farm13 = true
	while _G.farm13 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Bandit [Lv. 5]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm13 == false
	end
	end
	end
	end

end)

BanditsOff.MouseButton1Click:connect(function()
	_G.farm13 = false
	

end)

MonkeysOn.MouseButton1Click:connect(function()
	_G.farm14 = true
	while _G.farm14 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Monkey [Lv. 14]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm14 == false
	end
	end
	end
	end

end)

MonkeysOff.MouseButton1Click:connect(function()
	_G.farm14 = false
	

end)

GorillaOn.MouseButton1Click:connect(function()
	_G.farm15 = true
	while _G.farm15 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Gorilla [Lv. 20]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm15 == false
	end
	end
	end
	end

end)

MarineCaptainOn.MouseButton1Click:connect(function()
	_G.farm16 = true
	while _G.farm16 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Marine Captain [Lv. 120]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm16 == false
	end
	end
	end
	end

end)

MarineCaptainOff.MouseButton1Click:connect(function()
	_G.farm16 = false
	

end)

ViceAdmiralOn.MouseButton1Click:connect(function()
	_G.farm17 = true
	while _G.farm17 do
	wait(0)
	
	for i,v in pairs(game.workspace.Enemies:GetChildren()) do
	if v.Name == "Vice Admiral [Lv. 130] [Boss]" then
	if v.Humanoid.Health > 0 then
		repeat wait()
	game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.HumanoidRootPart.CFrame * CFrame.new(0, 0, 20)
	until v.Humanoid.Health == 0 or _G.farm17 == false
	end
	end
	end
	end

end)

ViceAdmiralOff.MouseButton1Click:connect(function()
	_G.farm17 = false
	

end)