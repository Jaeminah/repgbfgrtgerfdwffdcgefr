local blob = "Radioactive Blobimus Infernus" -- Blob Name

game.ReplicatedStorage.Events.EquipBlob:FireServer(game.ReplicatedStorage.Blobs[blob])

---------------------------------------------------------------------------------------------

local blob = "Radioactive Blobimus Fire" -- Blob Name

game.ReplicatedStorage.Events.EquipBlob:FireServer(game.ReplicatedStorage.Blobs[blob])