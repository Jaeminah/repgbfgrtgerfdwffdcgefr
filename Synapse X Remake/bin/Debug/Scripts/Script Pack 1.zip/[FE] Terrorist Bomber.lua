--Made by N3xul.
--Face
local face = "LoadAvatarAsset"
local faceid = 255827175 --MAD AF YO
local Event = game:GetService("ReplicatedStorage").Channels.PlayerChannel
Event:FireServer(face, faceid)
--Hats
local hatload1 = "LoadAvatarAsset"
local hat1 = 1527622 --Explode :D
local Event = game:GetService("ReplicatedStorage").Channels.PlayerChannel
Event:FireServer(hatload1, hat1)
local hatload2 = "LoadAvatarAsset"
local hat2 = 15133491 --Battalion Red Devils Beret
local Event = game:GetService("ReplicatedStorage").Channels.PlayerChannel
Event:FireServer(hatload2, hat2)
local hatload3 = "LoadAvatarAsset"
local hat3 = 461493477 --Gandalf
local Event = game:GetService("ReplicatedStorage").Channels.PlayerChannel
Event:FireServer(hatload3, hat3)
--Clothes
local loadshirt = "LoadAvatarAsset"
local shirt = 1001556819
local Event = game:GetService("ReplicatedStorage").Channels.PlayerChannel
Event:FireServer(loadshirt, shirt)
local loadpant = "LoadAvatarAsset"
local pant = 1026348684
local Event = game:GetService("ReplicatedStorage").Channels.PlayerChannel
Event:FireServer(loadpant, pant)