loadstring(game:GetObjects("rbxassetid://1545252996")[1].Source)()
